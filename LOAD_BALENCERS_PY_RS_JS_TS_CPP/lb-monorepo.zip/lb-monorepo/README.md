# lb-monorepo — Production Load Balancer & Sharding System

A production-grade TypeScript monorepo implementing a full load balancing and database sharding system.

## Architecture

```
Internet
   │
   ▼
┌─────────────────┐
│   API Gateway   │  :3000  — Rate limiting, security headers, correlation IDs, TLS termination point
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Load Balancer  │  :8080  — Algorithm selection, circuit breakers, health awareness, proxy
└────────┬────────┘
         │
   ┌─────┴──────┐
   ▼            ▼
backend-1  backend-2  backend-3  ...  :9000
         │
         ▼
┌─────────────────┐
│  Shard Manager  │  :8081  — Consistent hash ring, range sharding, modulo sharding
└─────────────────┘
```

## Load Balancing Algorithms

| Algorithm | Use Case |
|-----------|----------|
| `round-robin` | Even distribution, stateless backends |
| `weighted-round-robin` | Heterogeneous capacity backends |
| `least-connections` | Long-lived connections (WebSocket, gRPC) |
| `weighted-least-connections` | Mixed capacity + connection pressure |
| `ip-hash` | Session affinity without sticky cookies |
| `random` | Simple random selection |
| `power-of-two` | Random + least-connections hybrid (best for high throughput) |
| `least-response-time` | Latency-sensitive workloads |

## Sharding Strategies

| Strategy | Use Case |
|----------|----------|
| Consistent Hash Ring | Minimal remapping on node changes, cache sharding |
| Range Partitioning | Ordered key spaces (dates, alphabetical IDs) |
| Modulo | Simple numeric key distribution |

## Packages

| Package | Purpose |
|---------|---------|
| `@lb/logger` | Structured JSON logger with correlation ID propagation |
| `@lb/metrics` | Prometheus-compatible counters, histograms, gauges |
| `@lb/circuit-breaker` | CLOSED/OPEN/HALF_OPEN state machine with configurable thresholds |
| `@lb/health-client` | Active health checking with liveness/readiness tracking |
| `@lb/errors` | Typed error hierarchy for all failure modes |

## Quick Start

### Docker Compose (Recommended)

```bash
cd infra/docker
docker compose up --build
```

Services:
- API Gateway: http://localhost:3000
- Load Balancer: http://localhost:8080
- Shard Manager: http://localhost:8081
- Backend nodes: internal only

### Local Development

```bash
npm install

# Start backend nodes (in separate terminals)
NODE_ID=backend-1 PORT=9001 node -r ts-node/register services/backend-node/src/server.ts
NODE_ID=backend-2 PORT=9002 node -r ts-node/register services/backend-node/src/server.ts
NODE_ID=backend-3 PORT=9003 node -r ts-node/register services/backend-node/src/server.ts

# Start load balancer
BACKENDS="http://localhost:9001|1,http://localhost:9002|2,http://localhost:9003|1" \
ALGORITHM="round-robin" \
PORT=8080 \
node -r ts-node/register services/load-balancer/src/server.ts

# Start shard manager
PORT=8081 node -r ts-node/register services/shard-manager/src/server.ts

# Start API gateway
LOAD_BALANCER_URL="http://localhost:8080" \
PORT=3000 \
node -r ts-node/register services/api-gateway/src/server.ts
```

## Configuration

### Load Balancer Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `8080` | HTTP listen port |
| `BACKENDS` | required | Comma-separated `url\|weight` pairs |
| `ALGORITHM` | `round-robin` | Load balancing algorithm name |
| `HEALTH_INTERVAL_MS` | `10000` | Health check interval |
| `HEALTH_TIMEOUT_MS` | `5000` | Health check timeout |
| `CB_FAILURE_THRESHOLD` | `5` | Failures before circuit opens |
| `CB_SUCCESS_THRESHOLD` | `2` | Successes in HALF_OPEN to close |
| `CB_TIMEOUT_MS` | `60000` | Time before OPEN → HALF_OPEN |
| `CB_HALF_OPEN_CALLS` | `1` | Max calls allowed in HALF_OPEN |

### API Gateway Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | HTTP listen port |
| `LOAD_BALANCER_URL` | required | Upstream load balancer URL |
| `RATE_LIMIT_WINDOW_MS` | `60000` | Rate limit window |
| `RATE_LIMIT_MAX_REQUESTS` | `200` | Max requests per window per IP |

### Shard Manager Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `8081` | HTTP listen port |

## API Reference

### Load Balancer

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Liveness + readiness with backend counts |
| `/metrics` | GET | Prometheus text format metrics |
| `/stats` | GET | Per-backend stats (connections, latency, circuit state) |
| `/*` | ANY | Proxied to selected backend |

### Shard Manager

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Service health |
| `/metrics` | GET | Prometheus metrics |
| `/nodes` | GET | List all nodes across all strategies |
| `/nodes/consistent` | POST | Add node to consistent hash ring |
| `/nodes/consistent/:id` | DELETE | Remove node from ring |
| `/nodes/modulo` | POST | Add node to modulo strategy |
| `/partitions/range` | POST | Define a range partition |
| `/resolve/consistent?key=&replicas=` | GET | Resolve key via consistent hash |
| `/resolve/range?key=` | GET | Resolve key via range partition |
| `/resolve/modulo?key=` | GET | Resolve key via modulo |

### Shard Manager Examples

```bash
# Register consistent hash nodes
curl -X POST http://localhost:8081/nodes/consistent \
  -H 'Content-Type: application/json' \
  -d '{"id":"shard-1","url":"http://db-1:5432","virtualNodes":150}'

# Resolve a key
curl "http://localhost:8081/resolve/consistent?key=user-12345"

# Resolve with replication
curl "http://localhost:8081/resolve/consistent?key=user-12345&replicas=3"

# Define a range partition
curl -X POST http://localhost:8081/partitions/range \
  -H 'Content-Type: application/json' \
  -d '{"nodeId":"shard-a","url":"http://db-a:5432","minKey":"a","maxKey":"m"}'
```

## Running Tests

```bash
npm test --workspaces --if-present
```

## Observability

All services expose `/metrics` in Prometheus text format. Key metrics:

- `lb_selections_total` — backend selection count by algorithm and backend
- `lb_request_duration_ms` — request latency histogram per backend
- `lb_active_connections` — live connection gauge per backend
- `lb_errors_total` — error count per backend
- `lb_no_healthy_backend_total` — count of no-healthy-backend events
- `health_check_latency_ms` — health probe latency
- `health_status_transitions_total` — backend up/down transitions
- `shard_resolves_total` — shard resolution count by strategy
- `shard_node_count` — current node count per strategy
- `gateway_requests_total` — gateway request count by status
- `gateway_rate_limited_total` — rate-limited request count
- `gateway_request_duration_ms` — gateway end-to-end latency

## Security

- All services run as non-root (`appuser`) in Docker
- Security headers enforced on every response (HSTS, nosniff, DENY framing, etc.)
- Token bucket rate limiting at the gateway layer
- Circuit breakers prevent cascade failures
- Correlation IDs propagated for full request tracing
- No secrets in environment — use secret managers in production (AWS Secrets Manager, Vault, etc.)
- CVE scanning via Trivy in CI on every image build

## License

MIT
