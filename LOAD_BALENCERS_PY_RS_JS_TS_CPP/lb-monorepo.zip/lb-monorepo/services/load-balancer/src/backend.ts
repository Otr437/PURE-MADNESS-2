export interface Backend {
  id: string;
  url: string;
  weight: number;
  activeConnections: number;
  totalRequests: number;
  totalErrors: number;
  totalLatencyMs: number;
}

export function makeBackend(id: string, url: string, weight = 1): Backend {
  return {
    id,
    url,
    weight,
    activeConnections: 0,
    totalRequests: 0,
    totalErrors: 0,
    totalLatencyMs: 0,
  };
}
