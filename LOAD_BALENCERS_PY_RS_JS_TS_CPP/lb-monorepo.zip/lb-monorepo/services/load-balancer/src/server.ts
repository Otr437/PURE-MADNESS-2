import http from 'http';
import { HealthChecker } from '@lb/health-client';
import { Logger } from '@lb/logger';
import { globalMetrics } from '@lb/metrics';
import { ConfigError } from '@lb/errors';
import { LoadBalancerRegistry, Algorithm } from './registry.js';

function requireEnv(key: string): string {
  const val = process.env[key];
  if (!val) throw new ConfigError(key);
  return val;
}

function getEnv(key: string, fallback: string): string {
  return process.env[key] ?? fallback;
}

function parseBackends(raw: string): Array<{ id: string; url: string; weight: number }> {
  return raw.split(',').map((entry, i) => {
    const parts = entry.trim().split('|');
    const url = parts[0];
    const weight = parts[1] ? parseInt(parts[1], 10) : 1;
    if (!url) throw new Error(`Invalid BACKENDS entry at index ${i}: "${entry}"`);
    return { id: `backend-${i}`, url, weight };
  });
}

const log = new Logger('load-balancer-server', 'info');

let server: http.Server;
let registry: LoadBalancerRegistry;
let healthChecker: HealthChecker;
let isShuttingDown = false;

function extractClientIp(req: http.IncomingMessage): string {
  const forwarded = req.headers['x-forwarded-for'];
  if (typeof forwarded === 'string') return forwarded.split(',')[0].trim();
  return req.socket.remoteAddress ?? '0.0.0.0';
}

function generateCorrelationId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

async function handleRequest(
  req: http.IncomingMessage,
  res: http.ServerResponse,
): Promise<void> {
  if (isShuttingDown) {
    res.writeHead(503, { 'Content-Type': 'application/json', Connection: 'close' });
    res.end(JSON.stringify({ error: 'Service shutting down' }));
    return;
  }

  const correlationId =
    (req.headers['x-correlation-id'] as string) ?? generateCorrelationId();
  const clog = log.child(correlationId);

  res.setHeader('X-Correlation-ID', correlationId);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');

  if (req.url === '/health') {
    const healthyCount = healthChecker.getAllHealthy().length;
    const allCount = healthChecker.getAll().length;
    const ready = healthyCount > 0;
    res.writeHead(ready ? 200 : 503, { 'Content-Type': 'application/json' });
    res.end(
      JSON.stringify({
        status: ready ? 'ready' : 'degraded',
        live: true,
        backends: { healthy: healthyCount, total: allCount },
      }),
    );
    return;
  }

  if (req.url === '/metrics') {
    const body = globalMetrics.renderPrometheus();
    res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4' });
    res.end(body);
    return;
  }

  if (req.url === '/stats') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ backends: registry.getStats() }));
    return;
  }

  const clientIp = extractClientIp(req);
  clog.debug('Proxying request', { method: req.method, url: req.url, clientIp });

  const chunks: Buffer[] = [];
  req.on('data', (chunk: Buffer) => chunks.push(chunk));
  await new Promise<void>(resolve => req.on('end', resolve));
  const body = chunks.length > 0 ? Buffer.concat(chunks) : undefined;

  const headers: Record<string, string> = {};
  for (const [k, v] of Object.entries(req.headers)) {
    if (v !== undefined) headers[k] = Array.isArray(v) ? v.join(', ') : v;
  }
  headers['x-correlation-id'] = correlationId;
  headers['x-forwarded-for'] = clientIp;

  const targetUrl = `http://placeholder${req.url ?? '/'}`;
  const fetchReq = new Request(targetUrl, {
    method: req.method ?? 'GET',
    headers,
    body:
      req.method !== 'GET' && req.method !== 'HEAD' && body?.length
        ? body
        : undefined,
  });

  try {
    const { response, backendId } = await registry.proxy({ clientIp, correlationId }, fetchReq);
    res.setHeader('X-Selected-Backend', backendId);
    res.writeHead(response.status, Object.fromEntries(response.headers.entries()));
    const responseBody = await response.arrayBuffer();
    res.end(Buffer.from(responseBody));
    clog.info('Request proxied', { backend: backendId, status: response.status });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    clog.error('Proxy error', { error: message });
    res.writeHead(502, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Bad Gateway' }));
  }
}

function main(): void {
  const port = parseInt(getEnv('PORT', '8080'), 10);
  const backendsRaw = requireEnv('BACKENDS');
  const algorithm = getEnv('ALGORITHM', 'round-robin') as Algorithm;
  const healthIntervalMs = parseInt(getEnv('HEALTH_INTERVAL_MS', '10000'), 10);
  const healthTimeoutMs = parseInt(getEnv('HEALTH_TIMEOUT_MS', '5000'), 10);

  const backends = parseBackends(backendsRaw);
  if (backends.length === 0) throw new ConfigError('BACKENDS (empty list)');

  healthChecker = new HealthChecker(
    { intervalMs: healthIntervalMs, timeoutMs: healthTimeoutMs },
    log,
  );

  registry = new LoadBalancerRegistry(
    {
      algorithm,
      healthChecker,
      circuitBreakerOptions: {
        failureThreshold: parseInt(getEnv('CB_FAILURE_THRESHOLD', '5'), 10),
        successThreshold: parseInt(getEnv('CB_SUCCESS_THRESHOLD', '2'), 10),
        timeout: parseInt(getEnv('CB_TIMEOUT_MS', '60000'), 10),
        halfOpenMaxCalls: parseInt(getEnv('CB_HALF_OPEN_CALLS', '1'), 10),
      },
    },
    log,
  );

  for (const b of backends) {
    registry.addBackend(b.id, b.url, b.weight);
  }

  log.info('Load balancer starting', { port, algorithm, backendCount: backends.length });

  server = http.createServer((req, res) => {
    handleRequest(req, res).catch(err => {
      log.error('Unhandled error in request handler', {
        error: err instanceof Error ? err.message : String(err),
      });
      if (!res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Internal Server Error' }));
      }
    });
  });

  server.listen(port, () => {
    log.info('Load balancer listening', { port });
  });

  function gracefulShutdown(signal: string): void {
    log.info('Graceful shutdown initiated', { signal });
    isShuttingDown = true;
    healthChecker.stopAll();

    server.close(err => {
      if (err) {
        log.error('Error closing server', { error: err.message });
        process.exit(1);
      }
      log.info('Server closed cleanly');
      process.exit(0);
    });

    setTimeout(() => {
      log.error('Forced shutdown after timeout');
      process.exit(1);
    }, 30_000).unref();
  }

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  process.on('uncaughtException', err => {
    log.error('Uncaught exception', { error: err.message, stack: err.stack });
    gracefulShutdown('uncaughtException');
  });
  process.on('unhandledRejection', reason => {
    log.error('Unhandled rejection', { reason: String(reason) });
  });
}

main();
