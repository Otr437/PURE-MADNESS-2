import { NoHealthyBackendError } from '@lb/errors';
import { Backend } from '../backend.js';

export class RandomBalancer {
  next(backends: Backend[]): Backend {
    if (backends.length === 0) throw new NoHealthyBackendError();
    const index = Math.floor(Math.random() * backends.length);
    return backends[index];
  }

  // Power of Two Choices — pick 2 at random, return the one with fewer connections
  powerOfTwoChoices(backends: Backend[]): Backend {
    if (backends.length === 0) throw new NoHealthyBackendError();
    if (backends.length === 1) return backends[0];

    const idxA = Math.floor(Math.random() * backends.length);
    let idxB = Math.floor(Math.random() * (backends.length - 1));
    if (idxB >= idxA) idxB += 1;

    const a = backends[idxA];
    const b = backends[idxB];
    return a.activeConnections <= b.activeConnections ? a : b;
  }
}
