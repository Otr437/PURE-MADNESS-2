import { NoHealthyBackendError } from '@lb/errors';
import { Backend } from '../backend.js';

export class LeastConnectionsBalancer {
  next(backends: Backend[]): Backend {
    if (backends.length === 0) throw new NoHealthyBackendError();

    let best = backends[0];
    for (let i = 1; i < backends.length; i++) {
      if (backends[i].activeConnections < best.activeConnections) {
        best = backends[i];
      }
    }
    return best;
  }
}
