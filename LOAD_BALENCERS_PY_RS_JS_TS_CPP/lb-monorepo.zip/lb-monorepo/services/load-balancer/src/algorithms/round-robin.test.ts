import { describe, it, expect, beforeEach } from 'vitest';
import { RoundRobinBalancer } from '../src/algorithms/round-robin.js';
import { makeBackend } from '../src/backend.js';
import { NoHealthyBackendError } from '@lb/errors';

describe('RoundRobinBalancer', () => {
  let balancer: RoundRobinBalancer;

  beforeEach(() => {
    balancer = new RoundRobinBalancer();
  });

  it('throws NoHealthyBackendError when no backends', () => {
    expect(() => balancer.next([])).toThrow(NoHealthyBackendError);
  });

  it('cycles through backends in order', () => {
    const backends = [
      makeBackend('a', 'http://a'),
      makeBackend('b', 'http://b'),
      makeBackend('c', 'http://c'),
    ];
    expect(balancer.next(backends).id).toBe('a');
    expect(balancer.next(backends).id).toBe('b');
    expect(balancer.next(backends).id).toBe('c');
    expect(balancer.next(backends).id).toBe('a');
  });

  it('handles single backend', () => {
    const backends = [makeBackend('only', 'http://only')];
    expect(balancer.next(backends).id).toBe('only');
    expect(balancer.next(backends).id).toBe('only');
  });

  it('resets index on reset()', () => {
    const backends = [makeBackend('a', 'http://a'), makeBackend('b', 'http://b')];
    balancer.next(backends);
    balancer.next(backends);
    balancer.reset();
    expect(balancer.next(backends).id).toBe('a');
  });
});
