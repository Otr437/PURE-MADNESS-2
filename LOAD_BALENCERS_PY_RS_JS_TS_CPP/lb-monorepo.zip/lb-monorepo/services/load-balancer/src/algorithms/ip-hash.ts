import { NoHealthyBackendError } from '@lb/errors';
import { Backend } from '../backend.js';

export class IpHashBalancer {
  private fnv1a32(input: string): number {
    let hash = 2166136261;
    for (let i = 0; i < input.length; i++) {
      hash ^= input.charCodeAt(i);
      hash = (hash * 16777619) >>> 0;
    }
    return hash;
  }

  next(backends: Backend[], clientIp: string): Backend {
    if (backends.length === 0) throw new NoHealthyBackendError();
    const hash = this.fnv1a32(clientIp);
    const index = hash % backends.length;
    return backends[index];
  }
}
