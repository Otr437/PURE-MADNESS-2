import { NoHealthyBackendError } from '@lb/errors';
import { Backend } from './backend.js';

export class RoundRobinBalancer {
  private index = 0;

  next(backends: Backend[]): Backend {
    if (backends.length === 0) throw new NoHealthyBackendError();
    const selected = backends[this.index % backends.length];
    this.index = (this.index + 1) % backends.length;
    return selected;
  }

  reset(): void {
    this.index = 0;
  }
}
