import { NoHealthyBackendError } from '@lb/errors';
import { Backend } from '../backend.js';

export class LeastResponseTimeBalancer {
  next(backends: Backend[]): Backend {
    if (backends.length === 0) throw new NoHealthyBackendError();

    let best = backends[0];
    let bestScore = this.score(backends[0]);

    for (let i = 1; i < backends.length; i++) {
      const s = this.score(backends[i]);
      if (s < bestScore) {
        bestScore = s;
        best = backends[i];
      }
    }
    return best;
  }

  private score(b: Backend): number {
    const avgLatency =
      b.totalRequests > 0 ? b.totalLatencyMs / b.totalRequests : 0;
    // Combine avg latency with active connections pressure
    return avgLatency * (1 + b.activeConnections);
  }
}
