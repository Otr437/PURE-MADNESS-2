import { describe, it, expect } from 'vitest';
import { LeastConnectionsBalancer } from '../src/algorithms/least-connections.js';
import { makeBackend } from '../src/backend.js';
import { NoHealthyBackendError } from '@lb/errors';

describe('LeastConnectionsBalancer', () => {
  const balancer = new LeastConnectionsBalancer();

  it('throws NoHealthyBackendError when no backends', () => {
    expect(() => balancer.next([])).toThrow(NoHealthyBackendError);
  });

  it('picks backend with fewest active connections', () => {
    const a = { ...makeBackend('a', 'http://a'), activeConnections: 5 };
    const b = { ...makeBackend('b', 'http://b'), activeConnections: 2 };
    const c = { ...makeBackend('c', 'http://c'), activeConnections: 8 };
    expect(balancer.next([a, b, c]).id).toBe('b');
  });

  it('picks first when all connections are equal', () => {
    const backends = [
      { ...makeBackend('a', 'http://a'), activeConnections: 3 },
      { ...makeBackend('b', 'http://b'), activeConnections: 3 },
    ];
    expect(balancer.next(backends).id).toBe('a');
  });
});
