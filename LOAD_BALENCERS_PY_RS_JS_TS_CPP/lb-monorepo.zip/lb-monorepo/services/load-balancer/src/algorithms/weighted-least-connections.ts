import { NoHealthyBackendError } from '@lb/errors';
import { Backend } from '../backend.js';

export class WeightedLeastConnectionsBalancer {
  next(backends: Backend[]): Backend {
    if (backends.length === 0) throw new NoHealthyBackendError();

    // Score = activeConnections / weight — lowest score wins
    let best = backends[0];
    let bestScore = backends[0].activeConnections / (backends[0].weight || 1);

    for (let i = 1; i < backends.length; i++) {
      const score = backends[i].activeConnections / (backends[i].weight || 1);
      if (score < bestScore) {
        bestScore = score;
        best = backends[i];
      }
    }
    return best;
  }
}
