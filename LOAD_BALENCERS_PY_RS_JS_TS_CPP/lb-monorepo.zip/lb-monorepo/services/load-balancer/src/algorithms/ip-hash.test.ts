import { describe, it, expect } from 'vitest';
import { IpHashBalancer } from '../src/algorithms/ip-hash.js';
import { makeBackend } from '../src/backend.js';
import { NoHealthyBackendError } from '@lb/errors';

describe('IpHashBalancer', () => {
  const balancer = new IpHashBalancer();

  it('throws NoHealthyBackendError when no backends', () => {
    expect(() => balancer.next([], '1.2.3.4')).toThrow(NoHealthyBackendError);
  });

  it('returns the same backend for the same IP consistently', () => {
    const backends = [
      makeBackend('a', 'http://a'),
      makeBackend('b', 'http://b'),
      makeBackend('c', 'http://c'),
    ];
    const ip = '192.168.1.100';
    const first = balancer.next(backends, ip);
    for (let i = 0; i < 20; i++) {
      expect(balancer.next(backends, ip).id).toBe(first.id);
    }
  });

  it('distributes different IPs across backends', () => {
    const backends = [
      makeBackend('a', 'http://a'),
      makeBackend('b', 'http://b'),
      makeBackend('c', 'http://c'),
    ];
    const seen = new Set<string>();
    const ips = ['10.0.0.1', '10.0.0.2', '10.0.0.3', '172.16.0.1', '192.168.100.1',
                 '8.8.8.8', '1.1.1.1', '203.0.113.5', '198.51.100.1', '100.64.0.1'];
    for (const ip of ips) {
      seen.add(balancer.next(backends, ip).id);
    }
    expect(seen.size).toBeGreaterThan(1);
  });
});
