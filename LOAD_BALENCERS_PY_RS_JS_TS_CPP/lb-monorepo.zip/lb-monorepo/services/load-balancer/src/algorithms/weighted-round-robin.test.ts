import { describe, it, expect, beforeEach } from 'vitest';
import { WeightedRoundRobinBalancer } from '../src/algorithms/weighted-round-robin.js';
import { makeBackend } from '../src/backend.js';
import { NoHealthyBackendError } from '@lb/errors';

describe('WeightedRoundRobinBalancer', () => {
  let balancer: WeightedRoundRobinBalancer;

  beforeEach(() => {
    balancer = new WeightedRoundRobinBalancer();
  });

  it('throws NoHealthyBackendError when no backends', () => {
    expect(() => balancer.next([])).toThrow(NoHealthyBackendError);
  });

  it('distributes proportionally by weight', () => {
    const backends = [
      { ...makeBackend('heavy', 'http://heavy'), weight: 3 },
      { ...makeBackend('light', 'http://light'), weight: 1 },
    ];
    const counts: Record<string, number> = { heavy: 0, light: 0 };
    for (let i = 0; i < 40; i++) {
      counts[balancer.next(backends).id]++;
    }
    // heavy should get ~3x as many requests
    expect(counts['heavy']).toBeGreaterThan(counts['light'] * 2);
  });

  it('handles single backend', () => {
    const backends = [makeBackend('solo', 'http://solo')];
    expect(balancer.next(backends).id).toBe('solo');
  });
});
