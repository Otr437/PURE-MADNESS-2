import { NoHealthyBackendError } from '@lb/errors';
import { Backend } from '../backend.js';

export class WeightedRoundRobinBalancer {
  private currentIndex = -1;
  private currentWeight = 0;
  private maxWeight = 0;
  private gcd = 0;

  private computeGcd(a: number, b: number): number {
    while (b !== 0) {
      const t = b;
      b = a % b;
      a = t;
    }
    return a;
  }

  private computeGcdAll(backends: Backend[]): number {
    let g = backends[0].weight;
    for (let i = 1; i < backends.length; i++) {
      g = this.computeGcd(g, backends[i].weight);
    }
    return g;
  }

  next(backends: Backend[]): Backend {
    if (backends.length === 0) throw new NoHealthyBackendError();
    if (backends.length === 1) return backends[0];

    this.maxWeight = Math.max(...backends.map(b => b.weight));
    this.gcd = this.computeGcdAll(backends);
    const n = backends.length;

    for (let attempts = 0; attempts < n * this.maxWeight; attempts++) {
      this.currentIndex = (this.currentIndex + 1) % n;
      if (this.currentIndex === 0) {
        this.currentWeight = this.currentWeight - this.gcd;
        if (this.currentWeight <= 0) {
          this.currentWeight = this.maxWeight;
        }
      }
      if (backends[this.currentIndex].weight >= this.currentWeight) {
        return backends[this.currentIndex];
      }
    }

    throw new NoHealthyBackendError('Weighted round-robin selection failed');
  }

  reset(): void {
    this.currentIndex = -1;
    this.currentWeight = 0;
    this.maxWeight = 0;
    this.gcd = 0;
  }
}
