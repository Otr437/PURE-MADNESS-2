import { CircuitBreaker } from '@lb/circuit-breaker';
import { NoHealthyBackendError } from '@lb/errors';
import { HealthChecker } from '@lb/health-client';
import { Logger } from '@lb/logger';
import { globalMetrics } from '@lb/metrics';
import { Backend, makeBackend } from './backend.js';
import { IpHashBalancer } from './algorithms/ip-hash.js';
import { LeastConnectionsBalancer } from './algorithms/least-connections.js';
import { LeastResponseTimeBalancer } from './algorithms/least-response-time.js';
import { RandomBalancer } from './algorithms/random.js';
import { RoundRobinBalancer } from './algorithms/round-robin.js';
import { WeightedLeastConnectionsBalancer } from './algorithms/weighted-least-connections.js';
import { WeightedRoundRobinBalancer } from './algorithms/weighted-round-robin.js';

export type Algorithm =
  | 'round-robin'
  | 'weighted-round-robin'
  | 'least-connections'
  | 'weighted-least-connections'
  | 'ip-hash'
  | 'random'
  | 'power-of-two'
  | 'least-response-time';

export interface LoadBalancerConfig {
  algorithm: Algorithm;
  healthChecker: HealthChecker;
  circuitBreakerOptions?: {
    failureThreshold: number;
    successThreshold: number;
    timeout: number;
    halfOpenMaxCalls: number;
  };
}

export interface SelectionContext {
  clientIp?: string;
  correlationId?: string;
}

export class LoadBalancerRegistry {
  private backends: Map<string, Backend> = new Map();
  private circuits: Map<string, CircuitBreaker> = new Map();
  private algorithm: Algorithm;
  private readonly healthChecker: HealthChecker;
  private readonly log: Logger;

  private readonly roundRobin = new RoundRobinBalancer();
  private readonly weightedRoundRobin = new WeightedRoundRobinBalancer();
  private readonly leastConn = new LeastConnectionsBalancer();
  private readonly weightedLeastConn = new WeightedLeastConnectionsBalancer();
  private readonly ipHash = new IpHashBalancer();
  private readonly random = new RandomBalancer();
  private readonly leastResponseTime = new LeastResponseTimeBalancer();
  private readonly cbOptions: LoadBalancerConfig['circuitBreakerOptions'];

  constructor(config: LoadBalancerConfig, log?: Logger) {
    this.algorithm = config.algorithm;
    this.healthChecker = config.healthChecker;
    this.cbOptions = config.circuitBreakerOptions;
    this.log = log ?? new Logger('load-balancer');
  }

  addBackend(id: string, url: string, weight = 1): void {
    this.backends.set(id, makeBackend(id, url, weight));
    this.circuits.set(
      id,
      new CircuitBreaker(id, this.cbOptions ?? {}, this.log),
    );
    this.healthChecker.register(id, url);
    this.log.info('Backend registered', { id, url, weight });
  }

  removeBackend(id: string): void {
    this.backends.delete(id);
    this.circuits.delete(id);
    this.healthChecker.deregister(id);
    this.log.info('Backend deregistered', { id });
  }

  setAlgorithm(algorithm: Algorithm): void {
    this.algorithm = algorithm;
    this.roundRobin.reset();
    this.weightedRoundRobin.reset();
    this.log.info('Algorithm changed', { algorithm });
  }

  select(ctx: SelectionContext = {}): Backend {
    const healthy = this.getHealthyBackends();
    if (healthy.length === 0) {
      globalMetrics.incrementCounter('lb_no_healthy_backend_total');
      throw new NoHealthyBackendError();
    }

    let selected: Backend;

    switch (this.algorithm) {
      case 'round-robin':
        selected = this.roundRobin.next(healthy);
        break;
      case 'weighted-round-robin':
        selected = this.weightedRoundRobin.next(healthy);
        break;
      case 'least-connections':
        selected = this.leastConn.next(healthy);
        break;
      case 'weighted-least-connections':
        selected = this.weightedLeastConn.next(healthy);
        break;
      case 'ip-hash':
        selected = this.ipHash.next(healthy, ctx.clientIp ?? '0.0.0.0');
        break;
      case 'random':
        selected = this.random.next(healthy);
        break;
      case 'power-of-two':
        selected = this.random.powerOfTwoChoices(healthy);
        break;
      case 'least-response-time':
        selected = this.leastResponseTime.next(healthy);
        break;
      default: {
        const exhaustive: never = this.algorithm;
        throw new Error(`Unknown algorithm: ${exhaustive}`);
      }
    }

    globalMetrics.incrementCounter('lb_selections_total', {
      backend: selected.id,
      algorithm: this.algorithm,
    });
    this.log.debug('Backend selected', {
      backend: selected.id,
      algorithm: this.algorithm,
      correlationId: ctx.correlationId,
    });
    return selected;
  }

  async proxy(
    ctx: SelectionContext,
    req: Request,
  ): Promise<{ response: Response; backendId: string }> {
    const backend = this.select(ctx);
    const circuit = this.circuits.get(backend.id)!;

    backend.activeConnections += 1;
    backend.totalRequests += 1;
    const start = Date.now();

    try {
      const response = await circuit.execute(async () => {
        const targetUrl = new URL(req.url);
        const backendUrl = new URL(backend.url);
        targetUrl.hostname = backendUrl.hostname;
        targetUrl.port = backendUrl.port;
        targetUrl.protocol = backendUrl.protocol;

        const proxyReq = new Request(targetUrl.toString(), {
          method: req.method,
          headers: req.headers,
          body: req.method !== 'GET' && req.method !== 'HEAD' ? req.body : null,
        });

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 30_000);
        try {
          return await fetch(proxyReq, { signal: controller.signal });
        } finally {
          clearTimeout(timeout);
        }
      });

      const latencyMs = Date.now() - start;
      backend.totalLatencyMs += latencyMs;

      globalMetrics.recordHistogram('lb_request_duration_ms', latencyMs, {
        backend: backend.id,
      });
      globalMetrics.incrementCounter('lb_requests_total', {
        backend: backend.id,
        status: String(response.status),
      });

      return { response, backendId: backend.id };
    } catch (err) {
      backend.totalErrors += 1;
      globalMetrics.incrementCounter('lb_errors_total', { backend: backend.id });
      throw err;
    } finally {
      backend.activeConnections -= 1;
      globalMetrics.setGauge('lb_active_connections', backend.activeConnections, {
        backend: backend.id,
      });
    }
  }

  getStats(): Record<string, unknown>[] {
    return Array.from(this.backends.values()).map(b => ({
      id: b.id,
      url: b.url,
      weight: b.weight,
      activeConnections: b.activeConnections,
      totalRequests: b.totalRequests,
      totalErrors: b.totalErrors,
      avgLatencyMs:
        b.totalRequests > 0
          ? Math.round(b.totalLatencyMs / b.totalRequests)
          : 0,
      circuitState: this.circuits.get(b.id)?.getState() ?? 'UNKNOWN',
      healthy: this.healthChecker.isHealthy(b.id),
    }));
  }

  private getHealthyBackends(): Backend[] {
    return Array.from(this.backends.values()).filter(b => {
      const isHealthy = this.healthChecker.isHealthy(b.id);
      const circuit = this.circuits.get(b.id);
      const circuitAllow =
        circuit?.getState() === 'CLOSED' || circuit?.getState() === 'HALF_OPEN';
      return isHealthy && circuitAllow;
    });
  }
}
