export interface RateLimiterOptions {
  windowMs: number;
  maxRequests: number;
}

interface BucketEntry {
  tokens: number;
  lastRefill: number;
}

export class TokenBucketRateLimiter {
  private buckets: Map<string, BucketEntry> = new Map();
  private readonly options: RateLimiterOptions;
  private cleanupTimer: ReturnType<typeof setInterval>;

  constructor(options: RateLimiterOptions) {
    this.options = options;
    // Periodically evict stale entries
    this.cleanupTimer = setInterval(() => this.cleanup(), this.options.windowMs * 2);
  }

  allow(key: string): { allowed: boolean; remaining: number; resetMs: number } {
    const now = Date.now();
    let entry = this.buckets.get(key);

    if (!entry) {
      entry = { tokens: this.options.maxRequests, lastRefill: now };
      this.buckets.set(key, entry);
    }

    const elapsed = now - entry.lastRefill;
    const refill = Math.floor((elapsed / this.options.windowMs) * this.options.maxRequests);
    if (refill > 0) {
      entry.tokens = Math.min(this.options.maxRequests, entry.tokens + refill);
      entry.lastRefill = now;
    }

    const resetMs = this.options.windowMs - (now - entry.lastRefill);

    if (entry.tokens > 0) {
      entry.tokens -= 1;
      return { allowed: true, remaining: entry.tokens, resetMs };
    }
    return { allowed: false, remaining: 0, resetMs };
  }

  private cleanup(): void {
    const cutoff = Date.now() - this.options.windowMs * 3;
    for (const [key, entry] of this.buckets) {
      if (entry.lastRefill < cutoff) {
        this.buckets.delete(key);
      }
    }
  }

  stop(): void {
    clearInterval(this.cleanupTimer);
  }
}
