import { describe, it, expect, afterEach } from 'vitest';
import { TokenBucketRateLimiter } from '../src/rate-limiter.js';

describe('TokenBucketRateLimiter', () => {
  let limiter: TokenBucketRateLimiter;

  afterEach(() => {
    limiter.stop();
  });

  it('allows requests within limit', () => {
    limiter = new TokenBucketRateLimiter({ windowMs: 60_000, maxRequests: 5 });
    for (let i = 0; i < 5; i++) {
      expect(limiter.allow('ip1').allowed).toBe(true);
    }
  });

  it('blocks requests exceeding limit', () => {
    limiter = new TokenBucketRateLimiter({ windowMs: 60_000, maxRequests: 3 });
    limiter.allow('ip2');
    limiter.allow('ip2');
    limiter.allow('ip2');
    const result = limiter.allow('ip2');
    expect(result.allowed).toBe(false);
    expect(result.remaining).toBe(0);
  });

  it('tracks remaining tokens correctly', () => {
    limiter = new TokenBucketRateLimiter({ windowMs: 60_000, maxRequests: 10 });
    const r1 = limiter.allow('ip3');
    expect(r1.remaining).toBe(9);
    const r2 = limiter.allow('ip3');
    expect(r2.remaining).toBe(8);
  });

  it('uses separate buckets per key', () => {
    limiter = new TokenBucketRateLimiter({ windowMs: 60_000, maxRequests: 2 });
    limiter.allow('a');
    limiter.allow('a');
    expect(limiter.allow('a').allowed).toBe(false);
    expect(limiter.allow('b').allowed).toBe(true);
  });
});
