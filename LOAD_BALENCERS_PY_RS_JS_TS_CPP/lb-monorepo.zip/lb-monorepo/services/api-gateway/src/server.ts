import http from 'http';
import { Logger } from '@lb/logger';
import { globalMetrics } from '@lb/metrics';
import { ConfigError } from '@lb/errors';
import { TokenBucketRateLimiter } from './rate-limiter.js';

function requireEnv(key: string): string {
  const val = process.env[key];
  if (!val) throw new ConfigError(key);
  return val;
}

function getEnv(key: string, fallback: string): string {
  return process.env[key] ?? fallback;
}

const log = new Logger('api-gateway');
let isShuttingDown = false;
let server: http.Server;
let rateLimiter: TokenBucketRateLimiter;

const SECURITY_HEADERS: Record<string, string> = {
  'Strict-Transport-Security': 'max-age=63072000; includeSubDomains; preload',
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'geolocation=(), camera=(), microphone=()',
  'X-XSS-Protection': '0',
};

function applySecurityHeaders(res: http.ServerResponse): void {
  for (const [k, v] of Object.entries(SECURITY_HEADERS)) {
    res.setHeader(k, v);
  }
}

function extractClientIp(req: http.IncomingMessage): string {
  const fwd = req.headers['x-forwarded-for'];
  if (typeof fwd === 'string') return fwd.split(',')[0].trim();
  return req.socket.remoteAddress ?? '0.0.0.0';
}

function generateCorrelationId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

function sendJson(res: http.ServerResponse, status: number, body: unknown): void {
  applySecurityHeaders(res);
  res.writeHead(status, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(body));
}

async function proxyToLoadBalancer(
  req: http.IncomingMessage,
  res: http.ServerResponse,
  lbUrl: string,
  correlationId: string,
): Promise<void> {
  const targetUrl = `${lbUrl}${req.url ?? '/'}`;

  const chunks: Buffer[] = [];
  req.on('data', (c: Buffer) => chunks.push(c));
  await new Promise<void>(r => req.on('end', r));
  const body = chunks.length > 0 ? Buffer.concat(chunks) : undefined;

  const forwardHeaders: Record<string, string> = {
    'x-correlation-id': correlationId,
    'x-forwarded-for': extractClientIp(req),
    'x-gateway': 'lb-api-gateway/1.0',
  };
  for (const [k, v] of Object.entries(req.headers)) {
    if (v !== undefined && k !== 'host') {
      forwardHeaders[k] = Array.isArray(v) ? v.join(', ') : v;
    }
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30_000);

  try {
    const upstreamRes = await fetch(targetUrl, {
      method: req.method ?? 'GET',
      headers: forwardHeaders,
      body:
        req.method !== 'GET' && req.method !== 'HEAD' && body?.length ? body : undefined,
      signal: controller.signal,
    });

    const responseHeaders: Record<string, string> = {};
    upstreamRes.headers.forEach((v, k) => {
      responseHeaders[k] = v;
    });
    // Always enforce security headers on every response
    Object.assign(responseHeaders, SECURITY_HEADERS);
    responseHeaders['x-correlation-id'] = correlationId;

    res.writeHead(upstreamRes.status, responseHeaders);
    const responseBody = await upstreamRes.arrayBuffer();
    res.end(Buffer.from(responseBody));

    globalMetrics.incrementCounter('gateway_requests_total', {
      status: String(upstreamRes.status),
    });
  } finally {
    clearTimeout(timeout);
  }
}

async function handleRequest(
  req: http.IncomingMessage,
  res: http.ServerResponse,
  lbUrl: string,
): Promise<void> {
  if (isShuttingDown) {
    sendJson(res, 503, { error: 'Service shutting down' });
    return;
  }

  const correlationId =
    (req.headers['x-correlation-id'] as string) ?? generateCorrelationId();
  res.setHeader('X-Correlation-ID', correlationId);
  applySecurityHeaders(res);

  const clog = log.child(correlationId);
  const clientIp = extractClientIp(req);

  if (req.url === '/health' && req.method === 'GET') {
    sendJson(res, 200, { status: 'ready', live: true });
    return;
  }

  if (req.url === '/metrics' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4' });
    res.end(globalMetrics.renderPrometheus());
    return;
  }

  const rl = rateLimiter.allow(clientIp);
  res.setHeader('X-RateLimit-Remaining', String(rl.remaining));
  res.setHeader('X-RateLimit-Reset', String(rl.resetMs));

  if (!rl.allowed) {
    globalMetrics.incrementCounter('gateway_rate_limited_total', { ip: clientIp });
    clog.warn('Rate limit exceeded', { clientIp });
    sendJson(res, 429, { error: 'Too Many Requests' });
    return;
  }

  const start = Date.now();
  clog.info('Request received', { method: req.method, url: req.url, clientIp });

  try {
    await proxyToLoadBalancer(req, res, lbUrl, correlationId);
    globalMetrics.recordHistogram('gateway_request_duration_ms', Date.now() - start);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    clog.error('Gateway proxy error', { error: message });
    globalMetrics.incrementCounter('gateway_errors_total');
    if (!res.headersSent) {
      sendJson(res, 502, { error: 'Bad Gateway' });
    }
  }
}

function main(): void {
  const port = parseInt(getEnv('PORT', '3000'), 10);
  const lbUrl = requireEnv('LOAD_BALANCER_URL');
  const rlWindowMs = parseInt(getEnv('RATE_LIMIT_WINDOW_MS', '60000'), 10);
  const rlMaxRequests = parseInt(getEnv('RATE_LIMIT_MAX_REQUESTS', '200'), 10);

  rateLimiter = new TokenBucketRateLimiter({
    windowMs: rlWindowMs,
    maxRequests: rlMaxRequests,
  });

  log.info('API gateway starting', { port, lbUrl });

  server = http.createServer((req, res) => {
    handleRequest(req, res, lbUrl).catch(err => {
      log.error('Uncaught handler error', {
        error: err instanceof Error ? err.message : String(err),
      });
      if (!res.headersSent) {
        sendJson(res, 500, { error: 'Internal Server Error' });
      }
    });
  });

  server.listen(port, () => {
    log.info('API gateway listening', { port });
  });

  function gracefulShutdown(signal: string): void {
    log.info('Graceful shutdown', { signal });
    isShuttingDown = true;
    rateLimiter.stop();
    server.close(err => {
      if (err) {
        log.error('Error on shutdown', { error: err.message });
        process.exit(1);
      }
      log.info('Gateway shut down cleanly');
      process.exit(0);
    });
    setTimeout(() => {
      log.error('Forced shutdown');
      process.exit(1);
    }, 30_000).unref();
  }

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  process.on('uncaughtException', err => {
    log.error('Uncaught exception', { error: err.message });
    gracefulShutdown('uncaughtException');
  });
  process.on('unhandledRejection', reason => {
    log.error('Unhandled rejection', { reason: String(reason) });
  });
}

main();
