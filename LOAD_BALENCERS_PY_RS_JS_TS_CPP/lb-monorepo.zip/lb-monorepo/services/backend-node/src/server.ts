import http from 'http';
import { Logger } from '@lb/logger';
import { globalMetrics } from '@lb/metrics';
import { ConfigError } from '@lb/errors';

function getEnv(key: string, fallback: string): string {
  return process.env[key] ?? fallback;
}

const NODE_ID = getEnv('NODE_ID', 'backend-unknown');
const log = new Logger(`backend-node:${NODE_ID}`);
let isShuttingDown = false;
let server: http.Server;
const startTime = Date.now();

function sendJson(res: http.ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'X-Content-Type-Options': 'nosniff',
    'X-Backend-Node': NODE_ID,
  });
  res.end(JSON.stringify(body));
}

async function handleRequest(
  req: http.IncomingMessage,
  res: http.ServerResponse,
): Promise<void> {
  if (isShuttingDown) {
    sendJson(res, 503, { error: 'Shutting down' });
    return;
  }

  const correlationId = req.headers['x-correlation-id'] as string | undefined;
  if (correlationId) res.setHeader('X-Correlation-ID', correlationId);

  globalMetrics.incrementCounter('backend_requests_total', { node: NODE_ID });

  if (req.url === '/health' && req.method === 'GET') {
    const uptimeMs = Date.now() - startTime;
    sendJson(res, 200, {
      status: 'ready',
      live: true,
      nodeId: NODE_ID,
      uptimeMs,
    });
    return;
  }

  if (req.url === '/metrics' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4' });
    res.end(globalMetrics.renderPrometheus());
    return;
  }

  // Echo endpoint - returns request metadata for testing
  if (req.url === '/echo' && req.method === 'GET') {
    sendJson(res, 200, {
      nodeId: NODE_ID,
      correlationId: correlationId ?? null,
      method: req.method,
      url: req.url,
      headers: req.headers,
      timestamp: new Date().toISOString(),
    });
    return;
  }

  // Simulate latency for load testing
  if (req.url === '/slow' && req.method === 'GET') {
    const delayMs = parseInt(getEnv('SLOW_DELAY_MS', '500'), 10);
    await new Promise<void>(r => setTimeout(r, delayMs));
    sendJson(res, 200, { nodeId: NODE_ID, delayMs });
    return;
  }

  sendJson(res, 404, { error: 'Not found', nodeId: NODE_ID });
}

function main(): void {
  const port = parseInt(getEnv('PORT', '9000'), 10);

  log.info('Backend node starting', { nodeId: NODE_ID, port });

  server = http.createServer((req, res) => {
    const start = Date.now();
    handleRequest(req, res)
      .then(() => {
        globalMetrics.recordHistogram('backend_request_duration_ms', Date.now() - start, {
          node: NODE_ID,
        });
      })
      .catch(err => {
        log.error('Unhandled error', {
          error: err instanceof Error ? err.message : String(err),
        });
        if (!res.headersSent) {
          sendJson(res, 500, { error: 'Internal Server Error' });
        }
      });
  });

  server.listen(port, () => {
    log.info('Backend node listening', { port, nodeId: NODE_ID });
  });

  function gracefulShutdown(signal: string): void {
    log.info('Graceful shutdown', { signal, nodeId: NODE_ID });
    isShuttingDown = true;
    server.close(err => {
      if (err) {
        log.error('Error on shutdown', { error: err.message });
        process.exit(1);
      }
      log.info('Backend node shut down cleanly', { nodeId: NODE_ID });
      process.exit(0);
    });
    setTimeout(() => {
      log.error('Forced shutdown');
      process.exit(1);
    }, 30_000).unref();
  }

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  process.on('uncaughtException', err => {
    log.error('Uncaught exception', { error: err.message });
    gracefulShutdown('uncaughtException');
  });
  process.on('unhandledRejection', reason => {
    log.error('Unhandled rejection', { reason: String(reason) });
  });
}

main();
