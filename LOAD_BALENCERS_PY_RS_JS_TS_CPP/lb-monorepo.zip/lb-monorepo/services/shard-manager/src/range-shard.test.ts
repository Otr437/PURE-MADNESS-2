import { describe, it, expect, beforeEach } from 'vitest';
import { RangeShardStrategy, ModuloShardStrategy } from '../src/range-shard.js';
import { ShardNotFoundError } from '@lb/errors';

describe('RangeShardStrategy', () => {
  let strategy: RangeShardStrategy;

  beforeEach(() => {
    strategy = new RangeShardStrategy();
    strategy.addNode({ id: 'shard-a', url: 'http://a', virtualNodes: 1 });
    strategy.addNode({ id: 'shard-b', url: 'http://b', virtualNodes: 1 });
    strategy.definePartition('shard-a', 'a', 'mzzzzz');
    strategy.definePartition('shard-b', 'n', 'zzzzzz');
  });

  it('routes keys to correct range partition', () => {
    expect(strategy.getNode('apple').id).toBe('shard-a');
    expect(strategy.getNode('mango').id).toBe('shard-a');
    expect(strategy.getNode('orange').id).toBe('shard-b');
    expect(strategy.getNode('zebra').id).toBe('shard-b');
  });

  it('throws ShardNotFoundError for out-of-range key', () => {
    expect(() => strategy.getNode('1234')).toThrow(ShardNotFoundError);
  });
});

describe('ModuloShardStrategy', () => {
  let strategy: ModuloShardStrategy;

  beforeEach(() => {
    strategy = new ModuloShardStrategy();
    strategy.addNode({ id: 'shard-0', url: 'http://s0', virtualNodes: 1 });
    strategy.addNode({ id: 'shard-1', url: 'http://s1', virtualNodes: 1 });
    strategy.addNode({ id: 'shard-2', url: 'http://s2', virtualNodes: 1 });
  });

  it('distributes keys by modulo', () => {
    expect(strategy.getNode(0).id).toBe('shard-0');
    expect(strategy.getNode(1).id).toBe('shard-1');
    expect(strategy.getNode(2).id).toBe('shard-2');
    expect(strategy.getNode(3).id).toBe('shard-0');
    expect(strategy.getNode(4).id).toBe('shard-1');
  });

  it('throws ShardNotFoundError when no nodes', () => {
    const empty = new ModuloShardStrategy();
    expect(() => empty.getNode(5)).toThrow(ShardNotFoundError);
  });
});
