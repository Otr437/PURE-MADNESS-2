import { ShardNotFoundError } from '@lb/errors';

export interface ShardNode {
  id: string;
  url: string;
  virtualNodes: number;
}

export class ConsistentHashRing {
  private ring: Map<number, string> = new Map();
  private sortedKeys: number[] = [];
  private nodes: Map<string, ShardNode> = new Map();

  private fnv1a32(input: string): number {
    let hash = 2166136261;
    for (let i = 0; i < input.length; i++) {
      hash ^= input.charCodeAt(i);
      hash = Math.imul(hash, 16777619) >>> 0;
    }
    return hash;
  }

  addNode(node: ShardNode): void {
    this.nodes.set(node.id, node);
    for (let v = 0; v < node.virtualNodes; v++) {
      const key = this.fnv1a32(`${node.id}:vn${v}`);
      this.ring.set(key, node.id);
    }
    this.rebuildSortedKeys();
  }

  removeNode(id: string): void {
    const node = this.nodes.get(id);
    if (!node) return;
    this.nodes.delete(id);
    for (let v = 0; v < node.virtualNodes; v++) {
      const key = this.fnv1a32(`${id}:vn${v}`);
      this.ring.delete(key);
    }
    this.rebuildSortedKeys();
  }

  getNode(shardKey: string): ShardNode {
    if (this.sortedKeys.length === 0) {
      throw new ShardNotFoundError(shardKey);
    }
    const hash = this.fnv1a32(shardKey);
    for (const ringKey of this.sortedKeys) {
      if (hash <= ringKey) {
        const nodeId = this.ring.get(ringKey)!;
        return this.nodes.get(nodeId)!;
      }
    }
    // Wrap around to first node
    const firstKey = this.sortedKeys[0];
    const nodeId = this.ring.get(firstKey)!;
    return this.nodes.get(nodeId)!;
  }

  getReplicaNodes(shardKey: string, replicaCount: number): ShardNode[] {
    if (this.sortedKeys.length === 0) throw new ShardNotFoundError(shardKey);
    const hash = this.fnv1a32(shardKey);
    const seen = new Set<string>();
    const result: ShardNode[] = [];

    let startIdx = this.sortedKeys.findIndex(k => hash <= k);
    if (startIdx === -1) startIdx = 0;

    for (let i = 0; i < this.sortedKeys.length && result.length < replicaCount; i++) {
      const idx = (startIdx + i) % this.sortedKeys.length;
      const nodeId = this.ring.get(this.sortedKeys[idx])!;
      if (!seen.has(nodeId)) {
        seen.add(nodeId);
        result.push(this.nodes.get(nodeId)!);
      }
    }
    return result;
  }

  getAllNodes(): ShardNode[] {
    return Array.from(this.nodes.values());
  }

  getNodeCount(): number {
    return this.nodes.size;
  }

  private rebuildSortedKeys(): void {
    this.sortedKeys = Array.from(this.ring.keys()).sort((a, b) => a - b);
  }
}
