import { ShardNotFoundError } from '@lb/errors';
import { ShardNode } from './consistent-hash.js';

export interface RangePartition {
  nodeId: string;
  minKey: string;
  maxKey: string;
}

export class RangeShardStrategy {
  private partitions: RangePartition[] = [];
  private nodes: Map<string, ShardNode> = new Map();

  addNode(node: ShardNode): void {
    this.nodes.set(node.id, node);
  }

  removeNode(id: string): void {
    this.nodes.delete(id);
    this.partitions = this.partitions.filter(p => p.nodeId !== id);
  }

  definePartition(nodeId: string, minKey: string, maxKey: string): void {
    if (!this.nodes.has(nodeId)) {
      throw new Error(`Node ${nodeId} not registered`);
    }
    this.partitions.push({ nodeId, minKey, maxKey });
    this.partitions.sort((a, b) => a.minKey.localeCompare(b.minKey));
  }

  getNode(shardKey: string): ShardNode {
    for (const partition of this.partitions) {
      if (shardKey >= partition.minKey && shardKey <= partition.maxKey) {
        const node = this.nodes.get(partition.nodeId);
        if (!node) throw new ShardNotFoundError(shardKey);
        return node;
      }
    }
    throw new ShardNotFoundError(shardKey);
  }

  getAllNodes(): ShardNode[] {
    return Array.from(this.nodes.values());
  }
}

export class ModuloShardStrategy {
  private nodes: ShardNode[] = [];

  addNode(node: ShardNode): void {
    this.nodes.push(node);
    this.nodes.sort((a, b) => a.id.localeCompare(b.id));
  }

  removeNode(id: string): void {
    this.nodes = this.nodes.filter(n => n.id !== id);
  }

  getNode(numericKey: number): ShardNode {
    if (this.nodes.length === 0) throw new ShardNotFoundError(String(numericKey));
    const index = numericKey % this.nodes.length;
    return this.nodes[index];
  }

  getAllNodes(): ShardNode[] {
    return [...this.nodes];
  }
}
