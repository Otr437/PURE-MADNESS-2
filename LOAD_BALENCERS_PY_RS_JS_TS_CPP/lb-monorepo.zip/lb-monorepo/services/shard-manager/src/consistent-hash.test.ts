import { describe, it, expect, beforeEach } from 'vitest';
import { ConsistentHashRing } from '../src/consistent-hash.js';
import { ShardNotFoundError } from '@lb/errors';

describe('ConsistentHashRing', () => {
  let ring: ConsistentHashRing;

  beforeEach(() => {
    ring = new ConsistentHashRing();
  });

  it('throws ShardNotFoundError when no nodes', () => {
    expect(() => ring.getNode('somekey')).toThrow(ShardNotFoundError);
  });

  it('returns a node for a key after adding nodes', () => {
    ring.addNode({ id: 'node-1', url: 'http://node1', virtualNodes: 150 });
    ring.addNode({ id: 'node-2', url: 'http://node2', virtualNodes: 150 });
    const node = ring.getNode('user-12345');
    expect(['node-1', 'node-2']).toContain(node.id);
  });

  it('returns same node for same key (deterministic)', () => {
    ring.addNode({ id: 'node-1', url: 'http://node1', virtualNodes: 150 });
    ring.addNode({ id: 'node-2', url: 'http://node2', virtualNodes: 150 });
    ring.addNode({ id: 'node-3', url: 'http://node3', virtualNodes: 150 });
    const key = 'stable-key-abc';
    const first = ring.getNode(key).id;
    for (let i = 0; i < 10; i++) {
      expect(ring.getNode(key).id).toBe(first);
    }
  });

  it('remaps minimal keys on node removal', () => {
    ring.addNode({ id: 'node-1', url: 'http://node1', virtualNodes: 150 });
    ring.addNode({ id: 'node-2', url: 'http://node2', virtualNodes: 150 });
    ring.addNode({ id: 'node-3', url: 'http://node3', virtualNodes: 150 });

    const keys = Array.from({ length: 300 }, (_, i) => `key-${i}`);
    const before = new Map(keys.map(k => [k, ring.getNode(k).id]));

    ring.removeNode('node-2');

    let remapped = 0;
    for (const k of keys) {
      if (ring.getNode(k).id !== before.get(k)) remapped++;
    }
    // Consistent hashing: only ~1/N keys should remap
    expect(remapped).toBeLessThan(keys.length * 0.5);
  });

  it('getReplicaNodes returns unique nodes', () => {
    ring.addNode({ id: 'node-1', url: 'http://node1', virtualNodes: 150 });
    ring.addNode({ id: 'node-2', url: 'http://node2', virtualNodes: 150 });
    ring.addNode({ id: 'node-3', url: 'http://node3', virtualNodes: 150 });
    const replicas = ring.getReplicaNodes('some-key', 3);
    const ids = replicas.map(n => n.id);
    expect(new Set(ids).size).toBe(ids.length);
    expect(ids.length).toBe(3);
  });
});
