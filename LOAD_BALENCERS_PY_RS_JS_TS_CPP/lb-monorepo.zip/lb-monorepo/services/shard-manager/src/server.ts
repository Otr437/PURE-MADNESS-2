import http from 'http';
import { Logger } from '@lb/logger';
import { globalMetrics } from '@lb/metrics';
import { ConfigError, ShardNotFoundError, ValidationError } from '@lb/errors';
import { ConsistentHashRing } from './consistent-hash.js';
import { ModuloShardStrategy, RangeShardStrategy } from './range-shard.js';

function requireEnv(key: string): string {
  const val = process.env[key];
  if (!val) throw new ConfigError(key);
  return val;
}

function getEnv(key: string, fallback: string): string {
  return process.env[key] ?? fallback;
}

const log = new Logger('shard-manager');
let isShuttingDown = false;
let server: http.Server;

const ring = new ConsistentHashRing();
const rangeStrategy = new RangeShardStrategy();
const moduloStrategy = new ModuloShardStrategy();

async function readBody(req: http.IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = [];
  req.on('data', (c: Buffer) => chunks.push(c));
  await new Promise<void>(r => req.on('end', r));
  const raw = Buffer.concat(chunks).toString('utf8');
  if (!raw) return {};
  return JSON.parse(raw);
}

function sendJson(res: http.ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
  });
  res.end(payload);
}

async function handleRequest(
  req: http.IncomingMessage,
  res: http.ServerResponse,
): Promise<void> {
  if (isShuttingDown) {
    sendJson(res, 503, { error: 'Service shutting down' });
    return;
  }

  const correlationId =
    (req.headers['x-correlation-id'] as string) ??
    `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
  res.setHeader('X-Correlation-ID', correlationId);
  const clog = log.child(correlationId);

  const url = req.url ?? '/';
  const method = req.method ?? 'GET';

  if (url === '/health' && method === 'GET') {
    sendJson(res, 200, {
      status: 'ready',
      live: true,
      shards: {
        consistentHash: ring.getNodeCount(),
        rangeNodes: rangeStrategy.getAllNodes().length,
        moduloNodes: moduloStrategy.getAllNodes().length,
      },
    });
    return;
  }

  if (url === '/metrics' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4' });
    res.end(globalMetrics.renderPrometheus());
    return;
  }

  // POST /resolve/consistent?key=<shardKey>&replicas=<n>
  if (url.startsWith('/resolve/consistent') && method === 'GET') {
    const params = new URL(url, 'http://localhost').searchParams;
    const shardKey = params.get('key');
    const replicas = parseInt(params.get('replicas') ?? '1', 10);
    if (!shardKey) {
      sendJson(res, 400, { error: 'Missing query param: key' });
      return;
    }
    try {
      const nodes =
        replicas > 1
          ? ring.getReplicaNodes(shardKey, replicas)
          : [ring.getNode(shardKey)];
      globalMetrics.incrementCounter('shard_resolves_total', { strategy: 'consistent-hash' });
      sendJson(res, 200, { shardKey, nodes });
    } catch (err) {
      if (err instanceof ShardNotFoundError) {
        sendJson(res, 404, { error: err.message });
      } else {
        throw err;
      }
    }
    return;
  }

  // GET /resolve/range?key=<shardKey>
  if (url.startsWith('/resolve/range') && method === 'GET') {
    const params = new URL(url, 'http://localhost').searchParams;
    const shardKey = params.get('key');
    if (!shardKey) {
      sendJson(res, 400, { error: 'Missing query param: key' });
      return;
    }
    try {
      const node = rangeStrategy.getNode(shardKey);
      globalMetrics.incrementCounter('shard_resolves_total', { strategy: 'range' });
      sendJson(res, 200, { shardKey, node });
    } catch (err) {
      if (err instanceof ShardNotFoundError) {
        sendJson(res, 404, { error: err.message });
      } else {
        throw err;
      }
    }
    return;
  }

  // GET /resolve/modulo?key=<numericKey>
  if (url.startsWith('/resolve/modulo') && method === 'GET') {
    const params = new URL(url, 'http://localhost').searchParams;
    const rawKey = params.get('key');
    if (!rawKey) {
      sendJson(res, 400, { error: 'Missing query param: key' });
      return;
    }
    const numericKey = parseInt(rawKey, 10);
    if (isNaN(numericKey)) {
      sendJson(res, 400, { error: 'key must be a numeric value for modulo strategy' });
      return;
    }
    try {
      const node = moduloStrategy.getNode(numericKey);
      globalMetrics.incrementCounter('shard_resolves_total', { strategy: 'modulo' });
      sendJson(res, 200, { shardKey: rawKey, node });
    } catch (err) {
      if (err instanceof ShardNotFoundError) {
        sendJson(res, 404, { error: err.message });
      } else {
        throw err;
      }
    }
    return;
  }

  // POST /nodes/consistent
  if (url === '/nodes/consistent' && method === 'POST') {
    const body = (await readBody(req)) as Record<string, unknown>;
    const id = body['id'];
    const nodeUrl = body['url'];
    const virtualNodes = Number(body['virtualNodes'] ?? 150);
    if (typeof id !== 'string' || !id.trim()) {
      sendJson(res, 400, { error: 'Field "id" is required and must be a non-empty string' });
      return;
    }
    if (typeof nodeUrl !== 'string' || !nodeUrl.trim()) {
      sendJson(res, 400, { error: 'Field "url" is required and must be a non-empty string' });
      return;
    }
    ring.addNode({ id, url: nodeUrl, virtualNodes });
    clog.info('Consistent hash node added', { id, url: nodeUrl, virtualNodes });
    globalMetrics.setGauge('shard_node_count', ring.getNodeCount(), { strategy: 'consistent-hash' });
    sendJson(res, 201, { id, url: nodeUrl, virtualNodes });
    return;
  }

  // DELETE /nodes/consistent/:id
  if (url.startsWith('/nodes/consistent/') && method === 'DELETE') {
    const id = url.split('/nodes/consistent/')[1];
    if (!id) {
      sendJson(res, 400, { error: 'Node id required in path' });
      return;
    }
    ring.removeNode(id);
    clog.info('Consistent hash node removed', { id });
    globalMetrics.setGauge('shard_node_count', ring.getNodeCount(), { strategy: 'consistent-hash' });
    sendJson(res, 200, { removed: id });
    return;
  }

  // POST /nodes/modulo
  if (url === '/nodes/modulo' && method === 'POST') {
    const body = (await readBody(req)) as Record<string, unknown>;
    const id = body['id'];
    const nodeUrl = body['url'];
    if (typeof id !== 'string' || typeof nodeUrl !== 'string') {
      sendJson(res, 400, { error: 'Fields "id" and "url" are required strings' });
      return;
    }
    moduloStrategy.addNode({ id, url: nodeUrl, virtualNodes: 1 });
    clog.info('Modulo shard node added', { id, url: nodeUrl });
    sendJson(res, 201, { id, url: nodeUrl });
    return;
  }

  // POST /partitions/range — define a range partition
  if (url === '/partitions/range' && method === 'POST') {
    const body = (await readBody(req)) as Record<string, unknown>;
    const nodeId = body['nodeId'];
    const minKey = body['minKey'];
    const maxKey = body['maxKey'];
    const nodeUrl = body['url'];
    if (
      typeof nodeId !== 'string' ||
      typeof minKey !== 'string' ||
      typeof maxKey !== 'string' ||
      typeof nodeUrl !== 'string'
    ) {
      sendJson(res, 400, { error: 'Fields nodeId, url, minKey, maxKey required as strings' });
      return;
    }
    rangeStrategy.addNode({ id: nodeId, url: nodeUrl, virtualNodes: 1 });
    rangeStrategy.definePartition(nodeId, minKey, maxKey);
    clog.info('Range partition defined', { nodeId, minKey, maxKey });
    sendJson(res, 201, { nodeId, minKey, maxKey });
    return;
  }

  // GET /nodes — list all nodes across strategies
  if (url === '/nodes' && method === 'GET') {
    sendJson(res, 200, {
      consistentHash: ring.getAllNodes(),
      range: rangeStrategy.getAllNodes(),
      modulo: moduloStrategy.getAllNodes(),
    });
    return;
  }

  sendJson(res, 404, { error: 'Not found' });
}

function main(): void {
  const port = parseInt(getEnv('PORT', '8081'), 10);

  log.info('Shard manager starting', { port });

  server = http.createServer((req, res) => {
    handleRequest(req, res).catch(err => {
      log.error('Unhandled error', { error: err instanceof Error ? err.message : String(err) });
      if (!res.headersSent) {
        sendJson(res, 500, { error: 'Internal Server Error' });
      }
    });
  });

  server.listen(port, () => {
    log.info('Shard manager listening', { port });
  });

  function gracefulShutdown(signal: string): void {
    log.info('Graceful shutdown', { signal });
    isShuttingDown = true;
    server.close(err => {
      if (err) {
        log.error('Error on shutdown', { error: err.message });
        process.exit(1);
      }
      log.info('Shard manager shut down cleanly');
      process.exit(0);
    });
    setTimeout(() => {
      log.error('Forced shutdown');
      process.exit(1);
    }, 30_000).unref();
  }

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  process.on('uncaughtException', err => {
    log.error('Uncaught exception', { error: err.message });
    gracefulShutdown('uncaughtException');
  });
  process.on('unhandledRejection', reason => {
    log.error('Unhandled rejection', { reason: String(reason) });
  });
}

main();
