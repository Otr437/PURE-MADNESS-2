export type LogLevel = 'debug' | 'info' | 'warn' | 'error';

export interface LogEntry {
  timestamp: string;
  level: LogLevel;
  service: string;
  correlationId?: string;
  message: string;
  [key: string]: unknown;
}

export class Logger {
  private readonly service: string;
  private readonly minLevel: LogLevel;
  private static readonly levelOrder: Record<LogLevel, number> = {
    debug: 0,
    info: 1,
    warn: 2,
    error: 3,
  };

  constructor(service: string, minLevel: LogLevel = 'info') {
    this.service = service;
    this.minLevel = minLevel;
  }

  private shouldLog(level: LogLevel): boolean {
    return Logger.levelOrder[level] >= Logger.levelOrder[this.minLevel];
  }

  private write(level: LogLevel, message: string, meta: Record<string, unknown> = {}): void {
    if (!this.shouldLog(level)) return;
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      service: this.service,
      message,
      ...meta,
    };
    const line = JSON.stringify(entry);
    if (level === 'error') {
      process.stderr.write(line + '\n');
    } else {
      process.stdout.write(line + '\n');
    }
  }

  debug(message: string, meta?: Record<string, unknown>): void {
    this.write('debug', message, meta);
  }

  info(message: string, meta?: Record<string, unknown>): void {
    this.write('info', message, meta);
  }

  warn(message: string, meta?: Record<string, unknown>): void {
    this.write('warn', message, meta);
  }

  error(message: string, meta?: Record<string, unknown>): void {
    this.write('error', message, meta);
  }

  child(correlationId: string): CorrelatedLogger {
    return new CorrelatedLogger(this.service, this.minLevel, correlationId);
  }
}

export class CorrelatedLogger extends Logger {
  private readonly correlationId: string;

  constructor(service: string, minLevel: LogLevel, correlationId: string) {
    super(service, minLevel);
    this.correlationId = correlationId;
  }

  private withId(meta?: Record<string, unknown>): Record<string, unknown> {
    return { correlationId: this.correlationId, ...meta };
  }

  override debug(message: string, meta?: Record<string, unknown>): void {
    super.debug(message, this.withId(meta));
  }

  override info(message: string, meta?: Record<string, unknown>): void {
    super.info(message, this.withId(meta));
  }

  override warn(message: string, meta?: Record<string, unknown>): void {
    super.warn(message, this.withId(meta));
  }

  override error(message: string, meta?: Record<string, unknown>): void {
    super.error(message, this.withId(meta));
  }
}
