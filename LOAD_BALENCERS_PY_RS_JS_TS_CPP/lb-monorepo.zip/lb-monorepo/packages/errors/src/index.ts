export class AppError extends Error {
  public readonly statusCode: number;
  public readonly code: string;
  public readonly isOperational: boolean;

  constructor(message: string, statusCode: number, code: string, isOperational = true) {
    super(message);
    this.name = this.constructor.name;
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = isOperational;
    Error.captureStackTrace(this, this.constructor);
  }
}

export class NoHealthyBackendError extends AppError {
  constructor(message = 'No healthy backend available') {
    super(message, 503, 'NO_HEALTHY_BACKEND');
  }
}

export class BackendTimeoutError extends AppError {
  constructor(backendId: string) {
    super(`Backend ${backendId} timed out`, 504, 'BACKEND_TIMEOUT');
  }
}

export class CircuitOpenError extends AppError {
  constructor(backendId: string) {
    super(`Circuit open for backend ${backendId}`, 503, 'CIRCUIT_OPEN');
  }
}

export class ShardNotFoundError extends AppError {
  constructor(shardKey: string) {
    super(`No shard found for key ${shardKey}`, 500, 'SHARD_NOT_FOUND');
  }
}

export class ValidationError extends AppError {
  public readonly field?: string;
  constructor(message: string, field?: string) {
    super(message, 400, 'VALIDATION_ERROR');
    this.field = field;
  }
}

export class ConfigError extends AppError {
  constructor(missingKey: string) {
    super(`Required configuration key missing: ${missingKey}`, 500, 'CONFIG_ERROR', false);
  }
}
