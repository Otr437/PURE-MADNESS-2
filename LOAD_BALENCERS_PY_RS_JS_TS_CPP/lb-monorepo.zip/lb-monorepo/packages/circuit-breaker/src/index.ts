import { CircuitOpenError } from '@lb/errors';
import { Logger } from '@lb/logger';

export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export interface CircuitBreakerOptions {
  failureThreshold: number;
  successThreshold: number;
  timeout: number;
  halfOpenMaxCalls: number;
}

const DEFAULT_OPTIONS: CircuitBreakerOptions = {
  failureThreshold: 5,
  successThreshold: 2,
  timeout: 60_000,
  halfOpenMaxCalls: 1,
};

export class CircuitBreaker {
  private state: CircuitState = 'CLOSED';
  private failureCount = 0;
  private successCount = 0;
  private halfOpenCallCount = 0;
  private lastFailureTime = 0;
  private readonly options: CircuitBreakerOptions;
  private readonly log: Logger;

  constructor(
    private readonly name: string,
    options: Partial<CircuitBreakerOptions> = {},
    log?: Logger,
  ) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
    this.log = log ?? new Logger('circuit-breaker');
  }

  getState(): CircuitState {
    return this.state;
  }

  async execute<T>(fn: () => Promise<T>): Promise<T> {
    this.transitionIfNeeded();

    if (this.state === 'OPEN') {
      throw new CircuitOpenError(this.name);
    }

    if (this.state === 'HALF_OPEN') {
      if (this.halfOpenCallCount >= this.options.halfOpenMaxCalls) {
        throw new CircuitOpenError(this.name);
      }
      this.halfOpenCallCount += 1;
    }

    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (err) {
      this.onFailure(err instanceof Error ? err : new Error(String(err)));
      throw err;
    }
  }

  private transitionIfNeeded(): void {
    if (
      this.state === 'OPEN' &&
      Date.now() - this.lastFailureTime >= this.options.timeout
    ) {
      this.log.info('Circuit transitioning to HALF_OPEN', { circuit: this.name });
      this.state = 'HALF_OPEN';
      this.halfOpenCallCount = 0;
      this.successCount = 0;
    }
  }

  private onSuccess(): void {
    if (this.state === 'HALF_OPEN') {
      this.successCount += 1;
      if (this.successCount >= this.options.successThreshold) {
        this.log.info('Circuit transitioning to CLOSED', { circuit: this.name });
        this.state = 'CLOSED';
        this.failureCount = 0;
        this.successCount = 0;
        this.halfOpenCallCount = 0;
      }
    } else {
      this.failureCount = 0;
    }
  }

  private onFailure(err: Error): void {
    this.lastFailureTime = Date.now();
    if (this.state === 'HALF_OPEN') {
      this.log.warn('Circuit HALF_OPEN test failed, returning to OPEN', {
        circuit: this.name,
        error: err.message,
      });
      this.state = 'OPEN';
      this.halfOpenCallCount = 0;
      return;
    }
    this.failureCount += 1;
    if (this.failureCount >= this.options.failureThreshold) {
      this.log.error('Circuit transitioning to OPEN', {
        circuit: this.name,
        failureCount: this.failureCount,
        error: err.message,
      });
      this.state = 'OPEN';
    }
  }

  reset(): void {
    this.state = 'CLOSED';
    this.failureCount = 0;
    this.successCount = 0;
    this.halfOpenCallCount = 0;
    this.lastFailureTime = 0;
  }
}
