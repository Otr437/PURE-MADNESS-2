import { describe, it, expect, beforeEach } from 'vitest';
import { CircuitBreaker } from '../src/index.js';
import { CircuitOpenError } from '@lb/errors';

describe('CircuitBreaker', () => {
  let cb: CircuitBreaker;

  beforeEach(() => {
    cb = new CircuitBreaker('test', {
      failureThreshold: 3,
      successThreshold: 2,
      timeout: 100,
      halfOpenMaxCalls: 1,
    });
  });

  it('starts CLOSED and allows calls', async () => {
    expect(cb.getState()).toBe('CLOSED');
    const result = await cb.execute(async () => 'ok');
    expect(result).toBe('ok');
  });

  it('opens after reaching failure threshold', async () => {
    const fail = async (): Promise<void> => { throw new Error('fail'); };
    for (let i = 0; i < 3; i++) {
      await cb.execute(fail).catch(() => void 0);
    }
    expect(cb.getState()).toBe('OPEN');
  });

  it('throws CircuitOpenError when OPEN', async () => {
    const fail = async (): Promise<void> => { throw new Error('fail'); };
    for (let i = 0; i < 3; i++) {
      await cb.execute(fail).catch(() => void 0);
    }
    await expect(cb.execute(async () => 'ok')).rejects.toThrow(CircuitOpenError);
  });

  it('transitions to HALF_OPEN after timeout', async () => {
    const fail = async (): Promise<void> => { throw new Error('fail'); };
    for (let i = 0; i < 3; i++) {
      await cb.execute(fail).catch(() => void 0);
    }
    await new Promise(r => setTimeout(r, 150));
    // Trigger a transition check
    await cb.execute(async () => 'probe').catch(() => void 0);
    expect(['HALF_OPEN', 'CLOSED', 'OPEN']).toContain(cb.getState());
  });

  it('closes after successful calls in HALF_OPEN', async () => {
    const fail = async (): Promise<void> => { throw new Error('fail'); };
    for (let i = 0; i < 3; i++) {
      await cb.execute(fail).catch(() => void 0);
    }
    await new Promise(r => setTimeout(r, 150));
    await cb.execute(async () => 'ok');
    await cb.execute(async () => 'ok');
    expect(cb.getState()).toBe('CLOSED');
  });

  it('resets to CLOSED on reset()', async () => {
    const fail = async (): Promise<void> => { throw new Error('fail'); };
    for (let i = 0; i < 3; i++) {
      await cb.execute(fail).catch(() => void 0);
    }
    cb.reset();
    expect(cb.getState()).toBe('CLOSED');
  });
});
