import { Logger } from '@lb/logger';
import { globalMetrics } from '@lb/metrics';

export type HealthStatus = 'healthy' | 'unhealthy' | 'unknown';

export interface BackendHealth {
  id: string;
  url: string;
  status: HealthStatus;
  lastChecked: number;
  consecutiveFailures: number;
  consecutiveSuccesses: number;
  latencyMs: number;
}

export interface HealthCheckerOptions {
  intervalMs: number;
  timeoutMs: number;
  healthyThreshold: number;
  unhealthyThreshold: number;
  path: string;
}

const DEFAULT_OPTIONS: HealthCheckerOptions = {
  intervalMs: 10_000,
  timeoutMs: 5_000,
  healthyThreshold: 2,
  unhealthyThreshold: 3,
  path: '/health',
};

export class HealthChecker {
  private readonly backends: Map<string, BackendHealth> = new Map();
  private timers: Map<string, ReturnType<typeof setInterval>> = new Map();
  private readonly options: HealthCheckerOptions;
  private readonly log: Logger;

  constructor(options: Partial<HealthCheckerOptions> = {}, log?: Logger) {
    this.options = { ...DEFAULT_OPTIONS, ...options };
    this.log = log ?? new Logger('health-checker');
  }

  register(id: string, url: string): void {
    this.backends.set(id, {
      id,
      url,
      status: 'unknown',
      lastChecked: 0,
      consecutiveFailures: 0,
      consecutiveSuccesses: 0,
      latencyMs: 0,
    });
    this.scheduleCheck(id);
  }

  deregister(id: string): void {
    const timer = this.timers.get(id);
    if (timer) {
      clearInterval(timer);
      this.timers.delete(id);
    }
    this.backends.delete(id);
  }

  getHealth(id: string): BackendHealth | undefined {
    return this.backends.get(id);
  }

  isHealthy(id: string): boolean {
    return this.backends.get(id)?.status === 'healthy';
  }

  getAllHealthy(): BackendHealth[] {
    return Array.from(this.backends.values()).filter(b => b.status === 'healthy');
  }

  getAll(): BackendHealth[] {
    return Array.from(this.backends.values());
  }

  private scheduleCheck(id: string): void {
    this.performCheck(id).catch(() => void 0);
    const timer = setInterval(() => {
      this.performCheck(id).catch(() => void 0);
    }, this.options.intervalMs);
    this.timers.set(id, timer);
  }

  private async performCheck(id: string): Promise<void> {
    const backend = this.backends.get(id);
    if (!backend) return;

    const url = `${backend.url}${this.options.path}`;
    const start = Date.now();
    let ok = false;

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), this.options.timeoutMs);
      const res = await fetch(url, { signal: controller.signal });
      clearTimeout(timeout);
      ok = res.status === 200;
    } catch {
      ok = false;
    }

    const latencyMs = Date.now() - start;
    backend.lastChecked = Date.now();
    backend.latencyMs = latencyMs;

    globalMetrics.recordHistogram('health_check_latency_ms', latencyMs, { backend: id });

    if (ok) {
      backend.consecutiveFailures = 0;
      backend.consecutiveSuccesses += 1;
      if (
        backend.status !== 'healthy' &&
        backend.consecutiveSuccesses >= this.options.healthyThreshold
      ) {
        backend.status = 'healthy';
        this.log.info('Backend transitioned to healthy', { backend: id, latencyMs });
        globalMetrics.incrementCounter('health_status_transitions_total', {
          backend: id,
          status: 'healthy',
        });
      }
    } else {
      backend.consecutiveSuccesses = 0;
      backend.consecutiveFailures += 1;
      if (
        backend.status !== 'unhealthy' &&
        backend.consecutiveFailures >= this.options.unhealthyThreshold
      ) {
        backend.status = 'unhealthy';
        this.log.warn('Backend transitioned to unhealthy', {
          backend: id,
          consecutiveFailures: backend.consecutiveFailures,
        });
        globalMetrics.incrementCounter('health_status_transitions_total', {
          backend: id,
          status: 'unhealthy',
        });
      }
    }

    globalMetrics.setGauge('backend_healthy', backend.status === 'healthy' ? 1 : 0, {
      backend: id,
    });
  }

  stopAll(): void {
    for (const [id, timer] of this.timers) {
      clearInterval(timer);
      this.timers.delete(id);
    }
    this.log.info('Health checker stopped');
  }
}
