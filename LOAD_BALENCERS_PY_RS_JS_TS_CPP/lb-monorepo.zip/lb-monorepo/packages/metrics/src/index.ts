export interface MetricLabels {
  [key: string]: string;
}

interface CounterEntry {
  value: number;
  labels: MetricLabels;
}

interface HistogramEntry {
  sum: number;
  count: number;
  buckets: Map<number, number>;
  labels: MetricLabels;
}

interface GaugeEntry {
  value: number;
  labels: MetricLabels;
}

function labelsKey(labels: MetricLabels): string {
  return Object.entries(labels)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}="${v}"`)
    .join(',');
}

export class MetricsRegistry {
  private counters: Map<string, Map<string, CounterEntry>> = new Map();
  private histograms: Map<string, Map<string, HistogramEntry>> = new Map();
  private gauges: Map<string, Map<string, GaugeEntry>> = new Map();
  private static readonly DEFAULT_BUCKETS = [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10];

  incrementCounter(name: string, labels: MetricLabels = {}, amount = 1): void {
    if (!this.counters.has(name)) {
      this.counters.set(name, new Map());
    }
    const key = labelsKey(labels);
    const registry = this.counters.get(name)!;
    const existing = registry.get(key);
    if (existing) {
      existing.value += amount;
    } else {
      registry.set(key, { value: amount, labels });
    }
  }

  recordHistogram(name: string, value: number, labels: MetricLabels = {}): void {
    if (!this.histograms.has(name)) {
      this.histograms.set(name, new Map());
    }
    const key = labelsKey(labels);
    const registry = this.histograms.get(name)!;
    const existing = registry.get(key);
    if (existing) {
      existing.sum += value;
      existing.count += 1;
      for (const [bucket] of existing.buckets) {
        if (value <= bucket) {
          existing.buckets.set(bucket, existing.buckets.get(bucket)! + 1);
        }
      }
    } else {
      const buckets = new Map<number, number>();
      for (const b of MetricsRegistry.DEFAULT_BUCKETS) {
        buckets.set(b, value <= b ? 1 : 0);
      }
      registry.set(key, { sum: value, count: 1, buckets, labels });
    }
  }

  setGauge(name: string, value: number, labels: MetricLabels = {}): void {
    if (!this.gauges.has(name)) {
      this.gauges.set(name, new Map());
    }
    const key = labelsKey(labels);
    this.gauges.get(name)!.set(key, { value, labels });
  }

  renderPrometheus(): string {
    const lines: string[] = [];

    for (const [name, entries] of this.counters) {
      lines.push(`# TYPE ${name} counter`);
      for (const entry of entries.values()) {
        const lk = labelsKey(entry.labels);
        lines.push(`${name}{${lk}} ${entry.value}`);
      }
    }

    for (const [name, entries] of this.histograms) {
      lines.push(`# TYPE ${name} histogram`);
      for (const entry of entries.values()) {
        const lk = labelsKey(entry.labels);
        for (const [b, count] of entry.buckets) {
          lines.push(`${name}_bucket{${lk},le="${b}"} ${count}`);
        }
        lines.push(`${name}_bucket{${lk},le="+Inf"} ${entry.count}`);
        lines.push(`${name}_sum{${lk}} ${entry.sum}`);
        lines.push(`${name}_count{${lk}} ${entry.count}`);
      }
    }

    for (const [name, entries] of this.gauges) {
      lines.push(`# TYPE ${name} gauge`);
      for (const entry of entries.values()) {
        const lk = labelsKey(entry.labels);
        lines.push(`${name}{${lk}} ${entry.value}`);
      }
    }

    return lines.join('\n') + '\n';
  }

  reset(): void {
    this.counters.clear();
    this.histograms.clear();
    this.gauges.clear();
  }
}

export const globalMetrics = new MetricsRegistry();
