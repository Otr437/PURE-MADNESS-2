import { describe, it, expect, beforeEach } from 'vitest';
import { MetricsRegistry } from '../src/index.js';

describe('MetricsRegistry', () => {
  let registry: MetricsRegistry;

  beforeEach(() => {
    registry = new MetricsRegistry();
  });

  it('increments counters', () => {
    registry.incrementCounter('requests_total', { method: 'GET' });
    registry.incrementCounter('requests_total', { method: 'GET' });
    registry.incrementCounter('requests_total', { method: 'POST' });
    const output = registry.renderPrometheus();
    expect(output).toContain('requests_total{method="GET"} 2');
    expect(output).toContain('requests_total{method="POST"} 1');
  });

  it('sets gauge values', () => {
    registry.setGauge('active_connections', 42, { backend: 'b1' });
    const output = registry.renderPrometheus();
    expect(output).toContain('active_connections{backend="b1"} 42');
  });

  it('records histogram and includes sum/count/buckets', () => {
    registry.recordHistogram('latency_ms', 0.05, { service: 'lb' });
    registry.recordHistogram('latency_ms', 0.5, { service: 'lb' });
    const output = registry.renderPrometheus();
    expect(output).toContain('latency_ms_sum{service="lb"}');
    expect(output).toContain('latency_ms_count{service="lb"} 2');
    expect(output).toContain('latency_ms_bucket');
  });

  it('resets all metrics', () => {
    registry.incrementCounter('foo');
    registry.reset();
    const output = registry.renderPrometheus();
    expect(output.trim()).toBe('');
  });
});
