use crate::middleware::RateLimiter;
use arc_swap::ArcSwap;
use axum::{
    body::Body,
    extract::{Request, State},
    http::{HeaderMap, HeaderName, HeaderValue, Method, StatusCode, Uri},
    response::{IntoResponse, Response},
};
use bytes::Bytes;
use lb_core::{
    algorithm::SelectionAlgorithm,
    backend::Backend,
    config::{LbConfig, RateLimitKey},
    health::{HealthCheckConfig, HealthCheckKind, HealthCheckResult},
    shard::ShardManager,
    types::{BackendStatus, RequestContext},
};
use metrics_core::LbMetrics;
use std::{sync::Arc, time::Instant};
use tracing::{debug, error, info, warn};
use uuid::Uuid;

/// Hard cap on inbound request body (16 MiB). Requests larger than this are
/// rejected with 413 before any backend selection or upstream call.
const MAX_BODY_BYTES: usize = 16 * 1024 * 1024;

/// Maximum retry attempts for idempotent HTTP methods (GET, HEAD, OPTIONS, PUT, DELETE).
/// Non-idempotent methods (POST, PATCH) are attempted exactly once.
const MAX_RETRIES: u32 = 3;
/// Base backoff duration in milliseconds before the first retry.
const RETRY_BASE_MS: u64 = 50;
/// Maximum backoff ceiling after jitter is applied.
const RETRY_MAX_MS: u64 = 2_000;

pub struct AppState {
    pub backends: Arc<ArcSwap<Vec<Arc<Backend>>>>,
    pub algorithm: Arc<ArcSwap<Arc<dyn SelectionAlgorithm>>>,
    pub shard_manager: Option<Arc<ShardManager>>,
    pub metrics: Arc<LbMetrics>,
    pub http_client: Arc<reqwest::Client>,
    pub config: Arc<LbConfig>,
    pub rate_limiter: Option<Arc<RateLimiter>>,
}

pub async fn proxy_handler(
    State(state): State<Arc<AppState>>,
    req: Request<Body>,
) -> Response {
    let start = Instant::now();
    let method = req.method().clone();
    let uri = req.uri().clone();
    let headers = req.headers().clone();
    let path = uri.path().to_owned();
    let method_str = method.as_str().to_owned();

    let correlation_id = headers
        .get("x-correlation-id")
        .or_else(|| headers.get("x-request-id"))
        .and_then(|v| v.to_str().ok())
        .map(|s| s.to_owned())
        .unwrap_or_else(|| Uuid::new_v4().to_string());

    // Client IP: first entry of X-Forwarded-For, else X-Real-IP, else "unknown".
    let client_ip = headers
        .get("x-forwarded-for")
        .and_then(|v| v.to_str().ok())
        .and_then(|s| s.split(',').next())
        .map(|s| s.trim().to_owned())
        .or_else(|| {
            headers
                .get("x-real-ip")
                .and_then(|v| v.to_str().ok())
                .map(|s| s.to_owned())
        })
        .unwrap_or_else(|| "unknown".to_owned());

    // Preserve existing X-Forwarded-For chain so we append rather than replace.
    let existing_forwarded_for = headers
        .get("x-forwarded-for")
        .and_then(|v| v.to_str().ok())
        .map(|s| s.to_owned());

    // Read body early — reject oversized payloads before any backend selection.
    let body_bytes = match axum::body::to_bytes(req.into_body(), MAX_BODY_BYTES).await {
        Ok(b) => b,
        Err(_) => {
            return build_error_response(
                StatusCode::PAYLOAD_TOO_LARGE,
                "Request body exceeds maximum allowed size",
                &correlation_id,
            );
        }
    };

    let mut ctx = RequestContext::new(client_ip.clone(), method_str.clone(), path.clone());
    ctx.correlation_id = Some(correlation_id.clone());

    // Rate limiting — token bucket enforced before backend selection.
    if let Some(rl) = &state.rate_limiter {
        let rate_key = if let Some(rl_config) = &state.config.rate_limit {
            match &rl_config.key_strategy {
                RateLimitKey::ClientIp => client_ip.clone(),
                RateLimitKey::Header(h) => headers
                    .get(h.as_str())
                    .and_then(|v| v.to_str().ok())
                    .unwrap_or("unknown")
                    .to_owned(),
                RateLimitKey::Global => "global".to_owned(),
            }
        } else {
            client_ip.clone()
        };

        if !rl.check(&rate_key) {
            state.metrics.record_rate_limit_hit(&rate_key);
            warn!(key = %rate_key, correlation_id = %correlation_id, "Rate limit exceeded");
            return build_error_response(
                StatusCode::TOO_MANY_REQUESTS,
                "Rate limit exceeded",
                &correlation_id,
            );
        }
    }

    // Backend selection: shard routing takes precedence over algorithm routing.
    let backend_result = if let Some(shard_mgr) = &state.shard_manager {
        if let Some(shard_cfg) = &state.config.sharding {
            if shard_cfg.enabled {
                let shard_key = headers
                    .get(shard_cfg.key_header.as_str())
                    .and_then(|v| v.to_str().ok())
                    .unwrap_or(&client_ip)
                    .to_owned();

                match shard_mgr.shard_for_key(&shard_key) {
                    Ok(shard_id) => {
                        state.metrics.record_shard_request(shard_id);
                        shard_mgr.backend_for_key(&shard_key).map_err(|e| {
                            warn!(shard_key = %shard_key, error = %e, correlation_id = %correlation_id, "Shard backend selection failed");
                            e
                        })
                    }
                    Err(e) => {
                        warn!(shard_key = %shard_key, error = %e, correlation_id = %correlation_id, "Shard key mapping failed");
                        Err(e)
                    }
                }
            } else {
                select_backend_via_algorithm(&state, &ctx, &correlation_id).await
            }
        } else {
            select_backend_via_algorithm(&state, &ctx, &correlation_id).await
        }
    } else {
        select_backend_via_algorithm(&state, &ctx, &correlation_id).await
    };

    let backend = match backend_result {
        Ok(b) => b,
        Err(e) => {
            error!(error = %e, correlation_id = %correlation_id, "No backend available");
            state.metrics.record_backend_error("none", "no_healthy_backend");
            return build_error_response(
                StatusCode::SERVICE_UNAVAILABLE,
                "Service temporarily unavailable",
                &correlation_id,
            );
        }
    };

    let backend_id = backend.id.as_str().to_owned();
    let algorithm_name = state.algorithm.load().name().to_owned();

    backend.increment_connections();
    state.metrics.set_backend_connections(&backend_id, backend.active_connections() as f64);

    // Retry loop with exponential backoff + full jitter for idempotent methods.
    let is_idempotent = matches!(method_str.as_str(), "GET" | "HEAD" | "OPTIONS" | "PUT" | "DELETE");
    let max_attempts = if is_idempotent { MAX_RETRIES } else { 1 };

    let upstream_start = Instant::now();
    let mut upstream_response: Option<Response> = None;
    let mut last_error: Option<String> = None;

    for attempt in 0..max_attempts {
        if attempt > 0 {
            let cap = std::cmp::min(RETRY_MAX_MS, RETRY_BASE_MS * (1u64 << attempt));
            let jitter = rand::random::<u64>() % (cap + 1);
            tokio::time::sleep(std::time::Duration::from_millis(jitter)).await;
            debug!(
                backend = %backend_id,
                attempt = attempt + 1,
                jitter_ms = jitter,
                correlation_id = %correlation_id,
                "Retrying upstream request"
            );
        }

        match forward_request(
            &state.http_client,
            &backend,
            &method,
            &uri,
            &headers,
            body_bytes.clone(),
            &correlation_id,
            &client_ip,
            existing_forwarded_for.as_deref(),
        )
        .await
        {
            Ok(resp) => {
                upstream_response = Some(resp);
                break;
            }
            Err(e) => {
                warn!(
                    backend = %backend_id,
                    attempt = attempt + 1,
                    error = %e,
                    correlation_id = %correlation_id,
                    "Upstream attempt failed"
                );
                last_error = Some(e);
            }
        }
    }

    let upstream_latency = upstream_start.elapsed().as_secs_f64();
    backend.decrement_connections();
    state.metrics.set_backend_connections(&backend_id, backend.active_connections() as f64);

    match upstream_response {
        Some(response) => {
            let status = response.status().as_u16();
            let total_latency = start.elapsed().as_secs_f64();
            backend.record_success(upstream_latency * 1000.0);
            state.metrics.record_request(&method_str, &path, status, &algorithm_name, total_latency);
            state.metrics.record_backend_request(&backend_id, &algorithm_name);
            state.metrics.record_backend_latency(&backend_id, upstream_latency);
            debug!(
                backend = %backend_id,
                status = status,
                latency_ms = upstream_latency * 1000.0,
                correlation_id = %correlation_id,
                "Request proxied successfully"
            );
            response
        }
        None => {
            backend.record_failure();
            state.metrics.record_backend_error(&backend_id, "upstream_error");
            error!(
                backend = %backend_id,
                error = ?last_error,
                attempts = max_attempts,
                correlation_id = %correlation_id,
                "All upstream attempts failed"
            );
            build_error_response(StatusCode::BAD_GATEWAY, "Upstream server error", &correlation_id)
        }
    }
}

async fn select_backend_via_algorithm(
    state: &AppState,
    ctx: &RequestContext,
    correlation_id: &str,
) -> lb_core::error::LbResult<Arc<Backend>> {
    let backends_snapshot = state.backends.load();
    let algorithm = state.algorithm.load();
    algorithm.select(&backends_snapshot, ctx).await.map(|b| {
        debug!(
            backend = %b.id,
            algorithm = algorithm.name(),
            correlation_id = %correlation_id,
            "Backend selected"
        );
        b.clone()
    })
}

#[allow(clippy::too_many_arguments)]
async fn forward_request(
    client: &reqwest::Client,
    backend: &Backend,
    method: &Method,
    uri: &Uri,
    headers: &HeaderMap,
    body_bytes: Bytes,
    correlation_id: &str,
    client_ip: &str,
    existing_forwarded_for: Option<&str>,
) -> Result<Response, String> {
    let upstream_url = format!(
        "{}{}",
        backend.config.base_url(),
        uri.path_and_query().map(|pq| pq.as_str()).unwrap_or("/")
    );

    // Build X-Forwarded-For chain: append this proxy's observed client IP.
    let forwarded_for = match existing_forwarded_for {
        Some(existing) => format!("{}, {}", existing, client_ip),
        None => client_ip.to_owned(),
    };

    let mut upstream_req = client
        .request(method.clone(), &upstream_url)
        .timeout(std::time::Duration::from_millis(backend.config.request_timeout_ms));

    // Forward headers — strip hop-by-hop per RFC 7230 §6.1,
    // and strip x-forwarded-for so we set it ourselves below.
    for (name, value) in headers.iter() {
        let name_str = name.as_str().to_lowercase();
        if !is_hop_by_hop_header(&name_str) && name_str != "x-forwarded-for" {
            upstream_req = upstream_req.header(name, value);
        }
    }

    upstream_req = upstream_req
        .header("x-forwarded-for", &forwarded_for)
        .header("x-forwarded-by", "rust-lb/1.0")
        .header("x-correlation-id", correlation_id);

    if !body_bytes.is_empty() {
        upstream_req = upstream_req.body(body_bytes);
    }

    let upstream_resp = upstream_req
        .send()
        .await
        .map_err(|e| format!("Upstream send error: {}", e))?;

    let status = upstream_resp.status();
    let mut response_builder = axum::response::Response::builder().status(status.as_u16());

    for (name, value) in upstream_resp.headers() {
        let name_str = name.as_str().to_lowercase();
        if !is_hop_by_hop_header(&name_str) {
            if let (Ok(hn), Ok(hv)) = (
                HeaderName::from_bytes(name.as_str().as_bytes()),
                HeaderValue::from_bytes(value.as_bytes()),
            ) {
                response_builder = response_builder.header(hn, hv);
            }
        }
    }

    // Security response headers — applied to every proxied response.
    response_builder = response_builder
        .header("x-correlation-id", correlation_id)
        .header("x-content-type-options", "nosniff")
        .header("x-frame-options", "DENY")
        .header("referrer-policy", "strict-origin-when-cross-origin")
        .header("permissions-policy", "geolocation=(), camera=(), microphone=()")
        .header(
            "content-security-policy",
            "default-src 'self'; object-src 'none'; frame-ancestors 'none'",
        )
        // HSTS: 1 year, includeSubDomains. Browsers ignore on plain HTTP so safe to set unconditionally.
        .header("strict-transport-security", "max-age=31536000; includeSubDomains")
        // Suppress any server version disclosure from upstream or axum.
        .header("server", "");

    let resp_bytes = upstream_resp
        .bytes()
        .await
        .map_err(|e| format!("Failed to read upstream response body: {}", e))?;

    response_builder
        .body(Body::from(resp_bytes))
        .map_err(|e| format!("Failed to build response: {}", e))
}

fn is_hop_by_hop_header(name: &str) -> bool {
    matches!(
        name,
        "connection"
            | "keep-alive"
            | "proxy-authenticate"
            | "proxy-authorization"
            | "te"
            | "trailers"
            | "transfer-encoding"
            | "upgrade"
    )
}

fn build_error_response(status: StatusCode, message: &str, correlation_id: &str) -> Response {
    let body = serde_json::json!({ "error": message, "correlation_id": correlation_id });
    (
        status,
        [
            (
                axum::http::header::CONTENT_TYPE,
                HeaderValue::from_static("application/json"),
            ),
            (
                HeaderName::from_static("x-correlation-id"),
                HeaderValue::from_str(correlation_id)
                    .unwrap_or_else(|_| HeaderValue::from_static("unknown")),
            ),
            (
                HeaderName::from_static("x-content-type-options"),
                HeaderValue::from_static("nosniff"),
            ),
        ],
        body.to_string(),
    )
        .into_response()
}

pub async fn health_check_loop(state: Arc<AppState>, config: HealthCheckConfig) {
    let interval = std::time::Duration::from_secs(config.interval_secs);
    let mut ticker = tokio::time::interval(interval);

    loop {
        ticker.tick().await;
        let backends_snapshot = state.backends.load();
        let mut tasks = Vec::new();

        for backend in backends_snapshot.iter() {
            let backend = backend.clone();
            let config = config.clone();
            let client = state.http_client.clone();
            let metrics = state.metrics.clone();

            tasks.push(tokio::spawn(async move {
                let result = run_health_check(&client, &backend, &config).await;
                match &result.status {
                    BackendStatus::Healthy => {
                        if !backend.is_healthy() {
                            info!(backend = %backend.id, "Backend recovered — marking healthy");
                        }
                        backend.set_status(BackendStatus::Healthy);
                        metrics.set_backend_health(backend.id.as_str(), true);
                    }
                    BackendStatus::Unhealthy => {
                        if backend.is_healthy() {
                            warn!(
                                backend = %backend.id,
                                error = ?result.error,
                                "Backend failed health check — marking unhealthy"
                            );
                        }
                        backend.set_status(BackendStatus::Unhealthy);
                        metrics.set_backend_health(backend.id.as_str(), false);
                    }
                    _ => {}
                }
            }));
        }

        for task in tasks {
            if let Err(e) = task.await {
                error!(error = %e, "Health check task panicked");
            }
        }
    }
}

async fn run_health_check(
    client: &reqwest::Client,
    backend: &Backend,
    config: &HealthCheckConfig,
) -> HealthCheckResult {
    let start = Instant::now();
    let backend_id = backend.id.as_str().to_owned();

    let result = match config.kind {
        HealthCheckKind::Http => {
            let url = format!("{}{}", backend.config.base_url(), config.path);
            client
                .get(&url)
                .timeout(std::time::Duration::from_secs(config.timeout_secs))
                .send()
                .await
        }
        HealthCheckKind::Tcp => {
            let addr = backend.config.address();
            match tokio::time::timeout(
                std::time::Duration::from_secs(config.timeout_secs),
                tokio::net::TcpStream::connect(&addr),
            )
            .await
            {
                Ok(Ok(_)) => {
                    return HealthCheckResult {
                        backend_id,
                        status: BackendStatus::Healthy,
                        latency_ms: start.elapsed().as_secs_f64() * 1000.0,
                        error: None,
                        checked_at: chrono::Utc::now(),
                    }
                }
                Ok(Err(e)) => {
                    return HealthCheckResult {
                        backend_id,
                        status: BackendStatus::Unhealthy,
                        latency_ms: start.elapsed().as_secs_f64() * 1000.0,
                        error: Some(e.to_string()),
                        checked_at: chrono::Utc::now(),
                    }
                }
                Err(_) => {
                    return HealthCheckResult {
                        backend_id,
                        status: BackendStatus::Unhealthy,
                        latency_ms: start.elapsed().as_secs_f64() * 1000.0,
                        error: Some("TCP connect timeout".to_owned()),
                        checked_at: chrono::Utc::now(),
                    }
                }
            }
        }
    };

    let latency_ms = start.elapsed().as_secs_f64() * 1000.0;

    match result {
        Ok(resp) if resp.status().as_u16() == config.expected_status => HealthCheckResult {
            backend_id,
            status: BackendStatus::Healthy,
            latency_ms,
            error: None,
            checked_at: chrono::Utc::now(),
        },
        Ok(resp) => HealthCheckResult {
            backend_id,
            status: BackendStatus::Unhealthy,
            latency_ms,
            error: Some(format!("Unexpected status: {}", resp.status().as_u16())),
            checked_at: chrono::Utc::now(),
        },
        Err(e) => HealthCheckResult {
            backend_id,
            status: BackendStatus::Unhealthy,
            latency_ms,
            error: Some(e.to_string()),
            checked_at: chrono::Utc::now(),
        },
    }
}
