use crate::proxy::AppState;
use axum::{
    body::Body,
    extract::{Request, State},
    http::{header, HeaderValue, StatusCode},
    middleware::{self, Next},
    response::{IntoResponse, Response},
    routing::get,
    Json, Router,
};
use serde::Serialize;
use std::{net::SocketAddr, sync::Arc};
use tracing::{error, info, warn};

#[derive(Debug, Serialize)]
struct HealthResponse {
    status: &'static str,
    version: &'static str,
    uptime_secs: u64,
}

#[derive(Debug, Serialize)]
struct BackendStatusResponse {
    id: String,
    address: String,
    status: String,
    active_connections: u64,
    total_requests: u64,
    total_errors: u64,
    avg_latency_ms: f64,
    circuit_breaker_open: bool,
}

#[derive(Debug, Serialize)]
struct StatsResponse {
    total_backends: usize,
    healthy_backends: usize,
    unhealthy_backends: usize,
    shard_count: usize,
    algorithm: String,
}

static START_TIME: std::sync::OnceLock<std::time::Instant> = std::sync::OnceLock::new();

pub async fn run_admin_server(addr: SocketAddr, state: Arc<AppState>) -> anyhow::Result<()> {
    START_TIME.get_or_init(std::time::Instant::now);

    let app = build_admin_router(state);
    let listener = tokio::net::TcpListener::bind(addr)
        .await
        .map_err(|e| anyhow::anyhow!("Admin bind error: {}", e))?;

    info!(addr = %addr, "Admin server listening");
    axum::serve(listener, app)
        .await
        .map_err(|e| anyhow::anyhow!("Admin server error: {}", e))
}

fn build_admin_router(state: Arc<AppState>) -> Router {
    // Extract the admin token once so the middleware closure can own it.
    let admin_token = state.config.server.admin_token.clone();

    // Liveness and readiness are unauthenticated — used by Kubernetes probes.
    // Everything else requires a valid Bearer token.
    Router::new()
        .route("/health", get(health_handler))
        .route("/ready", get(readiness_handler))
        .route("/metrics", get(metrics_handler))
        .route("/admin/backends", get(backends_handler))
        .route("/admin/stats", get(stats_handler))
        .layer(middleware::from_fn(move |req: Request<Body>, next: Next| {
            let token = admin_token.clone();
            async move { require_admin_token(token, req, next).await }
        }))
        .layer(middleware::from_fn(strip_server_header))
        .with_state(state)
}

/// Strip the Server header from every admin response to prevent version disclosure.
async fn strip_server_header(req: Request<Body>, next: Next) -> Response {
    let mut response = next.run(req).await;
    response.headers_mut().remove(header::SERVER);
    response
        .headers_mut()
        .insert(header::SERVER, HeaderValue::from_static(""));
    response
}

/// Enforce Bearer token auth on all admin endpoints except /health and /ready.
/// If no admin_token is configured the service logs a startup warning and the
/// admin API is disabled entirely — all requests return 503.
async fn require_admin_token(
    configured_token: Option<String>,
    req: Request<Body>,
    next: Next,
) -> Response {
    let path = req.uri().path().to_owned();

    // /health and /ready are always open — used by orchestrator probes.
    if path == "/health" || path == "/ready" {
        return next.run(req).await;
    }

    let token = match configured_token {
        None => {
            warn!(path = %path, "Admin API request rejected — no admin_token configured");
            return (
                StatusCode::SERVICE_UNAVAILABLE,
                Json(serde_json::json!({
                    "error": "Admin API disabled — admin_token not configured"
                })),
            )
                .into_response();
        }
        Some(t) => t,
    };

    let auth_header = req
        .headers()
        .get(header::AUTHORIZATION)
        .and_then(|v| v.to_str().ok())
        .unwrap_or("");

    let provided = if auth_header.starts_with("Bearer ") {
        &auth_header["Bearer ".len()..]
    } else {
        ""
    };

    // Constant-time comparison to prevent timing attacks.
    if !constant_time_eq(provided.as_bytes(), token.as_bytes()) {
        warn!(path = %path, "Admin API unauthorized request");
        return (
            StatusCode::UNAUTHORIZED,
            [(header::WWW_AUTHENTICATE, HeaderValue::from_static("Bearer realm=\"admin\""))],
            Json(serde_json::json!({ "error": "Unauthorized" })),
        )
            .into_response();
    }

    next.run(req).await
}

/// XOR-based constant-time byte comparison — prevents timing oracle on the token.
fn constant_time_eq(a: &[u8], b: &[u8]) -> bool {
    if a.len() != b.len() {
        return false;
    }
    a.iter().zip(b.iter()).fold(0u8, |acc, (x, y)| acc | (x ^ y)) == 0
}

async fn health_handler() -> impl IntoResponse {
    let uptime_secs = START_TIME.get().map(|t| t.elapsed().as_secs()).unwrap_or(0);
    (
        StatusCode::OK,
        Json(HealthResponse {
            status: "ok",
            version: env!("CARGO_PKG_VERSION"),
            uptime_secs,
        }),
    )
}

async fn readiness_handler(State(state): State<Arc<AppState>>) -> impl IntoResponse {
    let backends = state.backends.load();
    let has_healthy = backends.iter().any(|b| b.is_healthy());
    if has_healthy {
        (StatusCode::OK, Json(serde_json::json!({ "status": "ready" })))
    } else {
        (
            StatusCode::SERVICE_UNAVAILABLE,
            Json(serde_json::json!({ "status": "not_ready", "reason": "no healthy backends" })),
        )
    }
}

async fn metrics_handler(State(state): State<Arc<AppState>>) -> Response {
    match state.metrics.render() {
        Ok(text) => (
            StatusCode::OK,
            [(
                axum::http::header::CONTENT_TYPE,
                "text/plain; version=0.0.4; charset=utf-8",
            )],
            text,
        )
            .into_response(),
        Err(e) => {
            error!(error = %e, "Failed to render metrics");
            (StatusCode::INTERNAL_SERVER_ERROR, "Failed to render metrics").into_response()
        }
    }
}

async fn backends_handler(State(state): State<Arc<AppState>>) -> impl IntoResponse {
    let backends = state.backends.load();
    let response: Vec<BackendStatusResponse> = backends
        .iter()
        .map(|b| {
            let stats = b.stats();
            BackendStatusResponse {
                id: b.id.as_str().to_owned(),
                address: b.config.address(),
                status: b.status().to_string(),
                active_connections: stats.active_connections,
                total_requests: stats.total_requests,
                total_errors: stats.total_errors,
                avg_latency_ms: stats.avg_latency_ms,
                circuit_breaker_open: b.is_circuit_open(),
            }
        })
        .collect();
    (StatusCode::OK, Json(response))
}

async fn stats_handler(State(state): State<Arc<AppState>>) -> impl IntoResponse {
    let backends = state.backends.load();
    let healthy = backends.iter().filter(|b| b.is_healthy()).count();
    let shard_count = state.shard_manager.as_ref().map(|sm| sm.shard_count()).unwrap_or(0);
    let algorithm = state.algorithm.load().name().to_owned();
    (
        StatusCode::OK,
        Json(StatsResponse {
            total_backends: backends.len(),
            healthy_backends: healthy,
            unhealthy_backends: backends.len() - healthy,
            shard_count,
            algorithm,
        }),
    )
}
