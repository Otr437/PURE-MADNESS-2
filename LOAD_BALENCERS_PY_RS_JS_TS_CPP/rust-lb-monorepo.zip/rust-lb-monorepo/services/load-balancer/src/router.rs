use crate::{middleware, proxy};
use axum::{routing::any, Router};
use std::sync::Arc;
use tower::ServiceBuilder;
use tower_http::{
    cors::CorsLayer,
    request_id::{MakeRequestUuid, PropagateRequestIdLayer, SetRequestIdLayer},
    timeout::TimeoutLayer,
    trace::TraceLayer,
};

pub fn build_router(state: Arc<proxy::AppState>) -> Router {
    let request_timeout =
        std::time::Duration::from_millis(state.config.server.request_timeout_ms);

    // CORS: config-driven allow-list. Empty = CORS disabled. Never wildcard.
    let cors = if let Some(origins) = &state.config.server.allowed_origins {
        let parsed: Vec<axum::http::HeaderValue> =
            origins.iter().filter_map(|o| o.parse().ok()).collect();
        if parsed.is_empty() {
            CorsLayer::new()
        } else {
            CorsLayer::new()
                .allow_methods([
                    axum::http::Method::GET,
                    axum::http::Method::POST,
                    axum::http::Method::PUT,
                    axum::http::Method::DELETE,
                    axum::http::Method::PATCH,
                    axum::http::Method::HEAD,
                    axum::http::Method::OPTIONS,
                ])
                .allow_origin(tower_http::cors::AllowOrigin::list(parsed))
                .allow_headers(tower_http::cors::AllowHeaders::mirror_request())
        }
    } else {
        CorsLayer::new()
    };

    let mut router = Router::new()
        .route("/{*path}", any(proxy::proxy_handler))
        .route("/", any(proxy::proxy_handler))
        .with_state(state.clone());

    // Rate limiter is applied as a router-level layer so every route — including
    // any added in the future — is covered without any per-handler wiring.
    if let Some(rl) = &state.rate_limiter {
        router = router.layer(axum::middleware::from_fn_with_state(
            rl.clone(),
            middleware::rate_limit_middleware,
        ));
    }

    router.layer(
        ServiceBuilder::new()
            .layer(TraceLayer::new_for_http())
            .layer(SetRequestIdLayer::x_request_id(MakeRequestUuid))
            .layer(PropagateRequestIdLayer::x_request_id())
            .layer(TimeoutLayer::new(request_timeout))
            .layer(cors),
    )
}
