use axum::{
    body::Body,
    extract::Request,
    http::{HeaderValue, StatusCode},
    middleware::Next,
    response::{IntoResponse, Response},
};
use dashmap::DashMap;
use lb_core::config::{RateLimitConfig, RateLimitKey};
use std::{
    sync::Arc,
    time::{Duration, Instant},
};
use tracing::warn;

/// Token-bucket rate limiter keyed per client (IP, header value, or "global").
/// This is exposed as an axum middleware function so it is applied at the router
/// layer — every route, present and future, is covered automatically.
#[derive(Debug, Clone)]
pub struct RateLimiter {
    config: RateLimitConfig,
    buckets: Arc<DashMap<String, TokenBucket>>,
}

#[derive(Debug, Clone)]
struct TokenBucket {
    tokens: f64,
    last_refill: Instant,
}

impl TokenBucket {
    fn new(burst_size: u32) -> Self {
        Self {
            tokens: burst_size as f64,
            last_refill: Instant::now(),
        }
    }

    fn try_consume(&mut self, rate_per_second: f64, burst_size: f64) -> bool {
        let now = Instant::now();
        let elapsed = now.duration_since(self.last_refill).as_secs_f64();
        self.tokens = (self.tokens + elapsed * rate_per_second).min(burst_size);
        self.last_refill = now;
        if self.tokens >= 1.0 {
            self.tokens -= 1.0;
            true
        } else {
            false
        }
    }
}

impl RateLimiter {
    pub fn new(config: RateLimitConfig) -> Self {
        Self {
            config,
            buckets: Arc::new(DashMap::new()),
        }
    }

    /// Returns true if the request is allowed under the current token budget.
    pub fn check(&self, key: &str) -> bool {
        let rate = self.config.requests_per_second as f64;
        let burst = self.config.burst_size as f64;
        let mut bucket = self
            .buckets
            .entry(key.to_owned())
            .or_insert_with(|| TokenBucket::new(self.config.burst_size));
        let allowed = bucket.try_consume(rate, burst);
        if !allowed {
            warn!(key = %key, "Rate limit exceeded");
        }
        allowed
    }

    /// Evict buckets that have been idle longer than `max_idle`.
    /// Call from a background task periodically to prevent unbounded memory growth.
    pub fn evict_stale(&self, max_idle: Duration) {
        self.buckets
            .retain(|_, bucket| bucket.last_refill.elapsed() < max_idle);
    }

    /// Derive the rate-limit key from the request using the configured strategy.
    fn key_for_request(&self, req: &Request<Body>) -> String {
        match &self.config.key_strategy {
            RateLimitKey::ClientIp => req
                .headers()
                .get("x-forwarded-for")
                .and_then(|v| v.to_str().ok())
                .and_then(|s| s.split(',').next())
                .map(|s| s.trim().to_owned())
                .or_else(|| {
                    req.headers()
                        .get("x-real-ip")
                        .and_then(|v| v.to_str().ok())
                        .map(|s| s.to_owned())
                })
                .unwrap_or_else(|| "unknown".to_owned()),

            RateLimitKey::Header(h) => req
                .headers()
                .get(h.as_str())
                .and_then(|v| v.to_str().ok())
                .unwrap_or("unknown")
                .to_owned(),

            RateLimitKey::Global => "global".to_owned(),
        }
    }
}

/// Axum middleware function — wraps the entire router so no route can bypass it.
/// Install with: `.layer(axum::middleware::from_fn_with_state(rl, rate_limit_middleware))`
pub async fn rate_limit_middleware(
    axum::extract::State(rl): axum::extract::State<Arc<RateLimiter>>,
    req: Request<Body>,
    next: Next,
) -> Response {
    let key = rl.key_for_request(&req);
    if !rl.check(&key) {
        return (
            StatusCode::TOO_MANY_REQUESTS,
            [(
                axum::http::header::RETRY_AFTER,
                HeaderValue::from_static("1"),
            )],
            axum::Json(serde_json::json!({ "error": "Rate limit exceeded" })),
        )
            .into_response();
    }
    next.run(req).await
}
