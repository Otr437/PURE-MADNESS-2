# Unified Security Suite — WAF + Crypto Service

Two production-ready Rust microservices sharing a **dynamic plugin entry-point system**.

```
unified-security/
├── shared/                  ← plugin trait contract (no concrete implementations)
│   └── src/
│       ├── plugin.rs        ← PluginRegistry + all trait definitions
│       ├── event.rs         ← SecurityEvent / CryptoEvent
│       ├── config.rs        ← shared config types
│       ├── error.rs         ← PluginError enum
│       └── health.rs        ← HealthStatus types
├── waf-microservice/        ← Web Application Firewall (port 8080)
├── crypto-service/          ← Encryption / hashing / JWT service (port 8081)
└── plugins/                 ← Example external plugins (drop-in replacements)
    ├── redis_rate_limiter/
    ├── vault_secret_manager/
    ├── webhook_event_sink/
    ├── oidc_auth_provider/
    └── abuseipdb_threat_intel/
```

---

## Dynamic Entry Point Architecture

Every extension point is a Rust trait in `shared/src/plugin.rs`.  
Neither service ever imports a concrete external type — they only call `PluginRegistry`.

```
External System                shared crate            WAF / Crypto Service
──────────────                 ────────────            ────────────────────
RedisRateLimiter  ─implements─▶ RateLimitBackend ◀─calls─ registry.check_rate_limit()
VaultSecretManager─implements─▶ SecretManager    ◀─calls─ registry.get_secret()
WebhookEventSink  ─implements─▶ EventSink        ◀─calls─ registry.emit_security_event()
OidcAuthProvider  ─implements─▶ AuthProvider     ◀─calls─ registry.auth_providers[0].validate_token()
AbuseIpDbPlugin   ─implements─▶ ThreatIntelligence◀─calls─ (used inside OwaspDetectorPlugin)
SoftwareCrypto    ─implements─▶ CryptoProvider   ◀─calls─ registry.crypto_providers[0].encrypt()
```

### Plugin Capabilities

| Trait                | Built-in impl            | Swap-in example        |
|----------------------|--------------------------|------------------------|
| `WafInspector`       | `OwaspDetectorPlugin`    | ML model, custom rules |
| `RateLimitBackend`   | `InMemoryRateLimiter`    | Redis, Valkey          |
| `ThreatIntelligence` | *(none)*                 | AbuseIPDB, Shodan      |
| `SecretManager`      | *(none)*                 | Vault, AWS Secrets     |
| `KeyStoreBackend`    | `InMemoryKeyStore`       | Vault, AWS KMS, HSM    |
| `CryptoProvider`     | `SoftwareCryptoProvider` | AWS KMS, Azure KV, HSM |
| `AuthProvider`       | *(none)*                 | OIDC, SAML, API keys   |
| `EventSink`          | *(none)*                 | Webhook, Kafka, SIEM   |
| `MetricsSink`        | `PrometheusMetricsSink`  | DataDog, OTel, StatsD  |

### Registering a Plugin (3 lines)

```rust
// In main() — before starting the server:
registry.register_rate_backend(
    Arc::new(RedisRateLimiter::new("redis://localhost:6379"))
).await;
```

The service automatically uses the first registered plugin for each capability.  
Multiple plugins of the same type all receive events (fan-out for sinks/inspectors).

---

## WAF Microservice — Port 8080

### Protections
- SQL Injection (11 patterns)
- XSS (9 patterns)
- Path Traversal (6 patterns)
- Command Injection (6 patterns)
- XXE / SSRF
- Rate limiting (pluggable backend)
- Malicious user-agent detection
- Custom rules engine (hot-reload via API)
- IP whitelist / blacklist (persistent)

### Admin API

| Method | Path                     | Description                     |
|--------|--------------------------|---------------------------------|
| GET    | `/waf/health`            | Health + uptime                 |
| GET    | `/waf/metrics`           | Prometheus metrics              |
| GET    | `/waf/stats`             | Block/whitelist counts          |
| GET    | `/waf/plugins`           | All registered plugins          |
| GET    | `/waf/blocked-ips`       | Active IP blocks                |
| DELETE | `/waf/blocked-ips/:ip`   | Unblock a specific IP           |
| POST   | `/waf/clear-blocks`      | Clear all blocks                |
| GET    | `/waf/whitelist`         | List whitelisted IPs            |
| POST   | `/waf/whitelist`         | Add IP to whitelist             |
| DELETE | `/waf/whitelist/:ip`     | Remove from whitelist           |
| GET    | `/waf/rules`             | List custom rules               |
| POST   | `/waf/rules`             | Replace custom rules            |
| GET    | `/waf/attack-logs`       | Last 100 attack logs            |

---

## Crypto Service — Port 8081

### Operations

| Method | Path                  | Description                                   |
|--------|-----------------------|-----------------------------------------------|
| GET    | `/health`             | Health + uptime                               |
| GET    | `/algorithms`         | All supported algorithms                      |
| GET    | `/plugins`            | Registered plugins                            |
| POST   | `/encrypt`            | AES-256-GCM / ChaCha20-Poly1305 / RSA-4096   |
| POST   | `/decrypt`            | Decrypt any of the above                      |
| POST   | `/hash`               | SHA-256/512, SHA3-256/512, BLAKE3             |
| POST   | `/hmac`               | HMAC-SHA256                                   |
| POST   | `/keys/generate`      | Generate AES-256 / RSA-4096 / Ed25519 key     |
| GET    | `/keys`               | List all managed keys                         |
| GET    | `/keys/:id`           | Get key by ID                                 |
| DELETE | `/keys/:id`           | Delete key                                    |
| POST   | `/sign`               | Ed25519 sign                                  |
| POST   | `/verify`             | Ed25519 verify                                |
| POST   | `/password/hash`      | bcrypt / Argon2id / scrypt                    |
| POST   | `/password/verify`    | Auto-detect algorithm and verify              |
| POST   | `/jwt/create`         | HS256 JWT with custom claims                  |
| POST   | `/jwt/verify`         | Verify JWT, return claims                     |
| GET    | `/secrets/:path`      | Read secret (requires SecretManager plugin)   |
| POST   | `/secrets/:path`      | Write secret (requires SecretManager plugin)  |
| DELETE | `/secrets/:path`      | Delete secret (requires SecretManager plugin) |
| POST   | `/auth/validate`      | Validate token (requires AuthProvider plugin) |

---

## Quick Start

```bash
# Build and start everything (WAF + Crypto + Prometheus + Grafana)
docker-compose up -d

# Verify both services are healthy
curl http://localhost:8080/waf/health
curl http://localhost:8081/health

# Test WAF — SQL injection should be blocked
curl "http://localhost:8080/api/users?id=1' OR '1'='1"
# → 403

# Test WAF — clean request passes
curl "http://localhost:8080/api/users?id=42"
# → {"waf":"passed",...}

# Encrypt data
curl -X POST http://localhost:8081/encrypt \
  -H "Content-Type: application/json" \
  -d '{"data":"secret","algorithm":"aes-256-gcm"}'

# Hash password
curl -X POST http://localhost:8081/password/hash \
  -H "Content-Type: application/json" \
  -d '{"password":"my_password","algorithm":"argon2"}'

# View Prometheus metrics
curl http://localhost:8080/waf/metrics

# View Grafana dashboards
open http://localhost:3000   # admin / admin
```

## Build from Source

```bash
cargo build --release
./target/release/waf-microservice &
./target/release/crypto-service &
```

## Writing a New Plugin

1. Create a new crate (or add a module to an existing one).
2. Add `shared = { path = "../shared" }` as a dependency.
3. Implement one or more traits from `shared::plugin`.
4. In the service's `main()`, call `registry.register_*()`.

That's it. No core changes needed.
