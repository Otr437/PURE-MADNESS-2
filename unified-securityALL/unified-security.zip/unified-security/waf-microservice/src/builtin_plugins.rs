// waf-microservice/src/builtin_plugins.rs
//
// Concrete implementations of shared plugin traits that ship with the WAF.
// External systems implement the same traits in their own crates.

use std::sync::Arc;
use async_trait::async_trait;
use axum::http::{HeaderMap, Method, Uri};
use lazy_static::lazy_static;
use regex::Regex;

use shared::plugin::{
    InspectionVerdict, MetricsSink, PluginCapability, PluginMeta,
    VerdictSeverity, WafInspector,
};
use shared::error::PluginError;
use crate::metrics::WafMetrics;

// ─── OWASP PATTERN DETECTOR ──────────────────────────────────────────────────

lazy_static! {
    static ref SQL_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"(?i)(union\s+select|union\s+all\s+select)").unwrap(),
        Regex::new(r"(?i)(select\s+.+\s+from\s+)").unwrap(),
        Regex::new(r"(?i)(insert\s+into\s+.+\s+values)").unwrap(),
        Regex::new(r"(?i)(delete\s+from\s+)").unwrap(),
        Regex::new(r"(?i)(update\s+.+\s+set\s+)").unwrap(),
        Regex::new(r"(?i)(drop\s+(table|database|schema))").unwrap(),
        Regex::new(r"(?i)(exec(\s|\()|execute(\s|\())").unwrap(),
        Regex::new(r"(?i)(benchmark|sleep|waitfor)\s*\(").unwrap(),
        Regex::new(r"(?i)((\%27)|(\'))\s*(or|and)\s*((\%27)|(\'))").unwrap(),
        Regex::new(r"(?i)0x[0-9a-f]{4,}").unwrap(),
        Regex::new(r"(?i)(information_schema|sys\.objects|sysobjects)").unwrap(),
    ];

    static ref XSS_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"(?i)<script[^>]*>").unwrap(),
        Regex::new(r"(?i)<iframe[^>]*>").unwrap(),
        Regex::new(r"(?i)on\w+\s*=\s*['\"]").unwrap(),
        Regex::new(r"(?i)javascript\s*:").unwrap(),
        Regex::new(r"(?i)vbscript\s*:").unwrap(),
        Regex::new(r"(?i)data\s*:\s*text/html").unwrap(),
        Regex::new(r"(?i)<svg[^>]*onload").unwrap(),
        Regex::new(r"(?i)expression\s*\(").unwrap(),
        Regex::new(r"(?i)<img[^>]+onerror\s*=").unwrap(),
    ];

    static ref PATH_TRAVERSAL_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"(\.\./|\.\.\\)").unwrap(),
        Regex::new(r"(%2e%2e%2f|%2e%2e/)").unwrap(),
        Regex::new(r"(?i)(/etc/passwd|/etc/shadow|/etc/hosts)").unwrap(),
        Regex::new(r"(?i)(c:\\windows|c:\\winnt)").unwrap(),
        Regex::new(r"(?i)(/proc/self/)").unwrap(),
        Regex::new(r"\x00").unwrap(),
    ];

    static ref CMD_INJECTION_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"(?i)(;|\||&&|\|\||`|\$\(|\$\{)").unwrap(),
        Regex::new(r"(?i)(nc|netcat|ncat)\s+\d").unwrap(),
        Regex::new(r"(?i)(bash|sh|zsh)\s+-[ci]").unwrap(),
        Regex::new(r"(?i)(wget|curl)\s+http").unwrap(),
        Regex::new(r"(?i)(/dev/tcp/|/dev/udp/)").unwrap(),
        Regex::new(r"(?i)(eval|exec|system|passthru|shell_exec)\s*\(").unwrap(),
    ];

    static ref XXE_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"(?i)<!ENTITY").unwrap(),
        Regex::new(r"(?i)<!DOCTYPE").unwrap(),
        Regex::new(r"(?i)SYSTEM\s+['\"]").unwrap(),
        Regex::new(r"(?i)file://").unwrap(),
        Regex::new(r"(?i)php://filter").unwrap(),
    ];

    static ref SSRF_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"(?i)https?://(localhost|127\.0\.0\.1|0\.0\.0\.0|::1)").unwrap(),
        Regex::new(r"(?i)https?://192\.168\.\d+\.\d+").unwrap(),
        Regex::new(r"(?i)https?://10\.\d+\.\d+\.\d+").unwrap(),
        Regex::new(r"(?i)https?://172\.(1[6-9]|2\d|3[01])\.\d+\.\d+").unwrap(),
        Regex::new(r"(?i)https?://169\.254\.169\.254").unwrap(), // AWS metadata
        Regex::new(r"(?i)(gopher|dict|ldap|tftp)://").unwrap(),
    ];

    static ref MALICIOUS_UA_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"(?i)(sqlmap|nikto|nmap|masscan|nessus)").unwrap(),
        Regex::new(r"(?i)(burpsuite|acunetix|havij|zaproxy)").unwrap(),
        Regex::new(r"(?i)(metasploit|hydra|medusa|beef)").unwrap(),
        Regex::new(r"(?i)python-requests/[0-9]").unwrap(),
        Regex::new(r"(?i)go-http-client/[0-9]").unwrap(),
    ];
}

pub struct OwaspDetectorPlugin {
    meta: PluginMeta,
}

impl OwaspDetectorPlugin {
    pub fn new() -> Self {
        Self {
            meta: PluginMeta {
                id:          "builtin.owasp_detector".into(),
                name:        "OWASP Attack Detector".into(),
                version:     "2.0.0".into(),
                description: "Detects SQLi, XSS, Path Traversal, CMDi, XXE, SSRF".into(),
                author:      "built-in".into(),
                capabilities: vec![PluginCapability::WafInspector],
            },
        }
    }

    fn check_patterns(patterns: &[Regex], input: &str) -> Option<String> {
        for pat in patterns {
            if let Some(m) = pat.find(input) {
                return Some(m.as_str().to_string());
            }
        }
        None
    }
}

#[async_trait]
impl WafInspector for OwaspDetectorPlugin {
    fn meta(&self) -> &PluginMeta { &self.meta }

    async fn inspect(
        &self,
        method:    &Method,
        uri:       &Uri,
        headers:   &HeaderMap,
        body:      &str,
        _client_ip: &str,
    ) -> Result<InspectionVerdict, PluginError> {
        let query    = uri.query().unwrap_or("");
        let path     = uri.path();
        let combined = format!("{} {} {}", query, body, path);
        let ua       = headers.get("user-agent")
            .and_then(|v| v.to_str().ok()).unwrap_or("");

        // Malicious user-agent — check first (cheap)
        if Self::check_patterns(&MALICIOUS_UA_PATTERNS, ua).is_some() {
            return Ok(InspectionVerdict::Block {
                reason: "Malicious user-agent detected".into(),
                severity: VerdictSeverity::High,
            });
        }

        // SQLi
        if let Some(m) = Self::check_patterns(&SQL_PATTERNS, &combined) {
            return Ok(InspectionVerdict::Block {
                reason: format!("SQL injection: {}", m),
                severity: VerdictSeverity::Critical,
            });
        }

        // XSS
        if let Some(m) = Self::check_patterns(&XSS_PATTERNS, &combined) {
            return Ok(InspectionVerdict::Block {
                reason: format!("XSS: {}", m),
                severity: VerdictSeverity::Critical,
            });
        }

        // Path traversal
        if let Some(m) = Self::check_patterns(&PATH_TRAVERSAL_PATTERNS, &combined) {
            return Ok(InspectionVerdict::Block {
                reason: format!("Path traversal: {}", m),
                severity: VerdictSeverity::High,
            });
        }

        // Command injection
        if let Some(m) = Self::check_patterns(&CMD_INJECTION_PATTERNS, &combined) {
            return Ok(InspectionVerdict::Block {
                reason: format!("Command injection: {}", m),
                severity: VerdictSeverity::Critical,
            });
        }

        // XXE
        if let Some(m) = Self::check_patterns(&XXE_PATTERNS, body) {
            return Ok(InspectionVerdict::Block {
                reason: format!("XXE: {}", m),
                severity: VerdictSeverity::High,
            });
        }

        // SSRF
        if let Some(m) = Self::check_patterns(&SSRF_PATTERNS, &combined) {
            return Ok(InspectionVerdict::Block {
                reason: format!("SSRF: {}", m),
                severity: VerdictSeverity::High,
            });
        }

        Ok(InspectionVerdict::Allow)
    }
}

// ─── PROMETHEUS METRICS SINK ─────────────────────────────────────────────────

pub struct PrometheusMetricsSink {
    meta:    PluginMeta,
    metrics: Arc<WafMetrics>,
}

impl PrometheusMetricsSink {
    pub fn new(metrics: Arc<WafMetrics>) -> Self {
        Self {
            metrics,
            meta: PluginMeta {
                id:          "builtin.prometheus_sink".into(),
                name:        "Prometheus Metrics Sink".into(),
                version:     "2.0.0".into(),
                description: "Exports WAF metrics to Prometheus".into(),
                author:      "built-in".into(),
                capabilities: vec![PluginCapability::MetricsSink],
            },
        }
    }
}

#[async_trait]
impl MetricsSink for PrometheusMetricsSink {
    fn meta(&self) -> &PluginMeta { &self.meta }

    async fn counter(
        &self, name: &str, _labels: &[(&str, &str)], _delta: f64,
    ) -> Result<(), PluginError> {
        match name {
            "requests_allowed"          => self.metrics.requests_allowed.inc(),
            "requests_blocked"          => self.metrics.requests_blocked.inc(),
            "rate_limits_triggered"     => self.metrics.rate_limits_triggered.inc(),
            "sql_injection_blocked"     => self.metrics.sql_injection_blocked.inc(),
            "xss_blocked"               => self.metrics.xss_blocked.inc(),
            "path_traversal_blocked"    => self.metrics.path_traversal_blocked.inc(),
            "command_injection_blocked" => self.metrics.command_injection_blocked.inc(),
            _ => {}
        }
        Ok(())
    }

    async fn gauge(
        &self, _name: &str, _labels: &[(&str, &str)], _val: f64,
    ) -> Result<(), PluginError> { Ok(()) }

    async fn histogram(
        &self, name: &str, _labels: &[(&str, &str)], val: f64,
    ) -> Result<(), PluginError> {
        if name == "response_time" {
            self.metrics.response_time.observe(val);
        }
        Ok(())
    }
}
