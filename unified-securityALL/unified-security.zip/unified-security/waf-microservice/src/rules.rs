// waf-microservice/src/rules.rs
use axum::http::{HeaderMap, Method, Uri};
use regex::Regex;
use serde::{Deserialize, Serialize};
use std::sync::Arc;
use tokio::sync::RwLock;
use crate::config::WafConfig;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Rule {
    pub id:          String,
    pub name:        String,
    pub description: String,
    pub enabled:     bool,
    pub action:      RuleAction,
    pub conditions:  Vec<Condition>,
    pub ban_duration: u64,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum RuleAction { Block, Log, Challenge }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Condition {
    pub field:          ConditionField,
    pub operator:       ConditionOperator,
    pub value:          String,
    pub case_sensitive: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ConditionField {
    Method, Path, Query, Body, UserAgent, Header(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ConditionOperator {
    Equals, NotEquals, Contains, NotContains, StartsWith, EndsWith,
    Regex, LengthGreater, LengthLess,
}

#[derive(Debug, Clone)]
pub struct RuleViolation {
    pub rule_id:      String,
    pub rule_name:    String,
    pub action:       RuleAction,
    pub ban_duration: u64,
}

pub struct RuleEngine {
    rules: Arc<RwLock<Vec<Rule>>>,
}

impl RuleEngine {
    pub fn new(_config: Arc<WafConfig>) -> Self {
        let defaults = vec![
            Rule {
                id: "block_env".into(), name: "Block .env access".into(),
                description: "Deny .env file requests".into(), enabled: true,
                action: RuleAction::Block,
                conditions: vec![Condition {
                    field: ConditionField::Path,
                    operator: ConditionOperator::Contains,
                    value: ".env".into(), case_sensitive: false,
                }],
                ban_duration: 3600,
            },
            Rule {
                id: "block_git".into(), name: "Block .git access".into(),
                description: "Deny .git directory requests".into(), enabled: true,
                action: RuleAction::Block,
                conditions: vec![Condition {
                    field: ConditionField::Path,
                    operator: ConditionOperator::Contains,
                    value: ".git/".into(), case_sensitive: false,
                }],
                ban_duration: 3600,
            },
            Rule {
                id: "block_php".into(), name: "Block PHP files".into(),
                description: "Deny direct PHP file access".into(), enabled: true,
                action: RuleAction::Block,
                conditions: vec![Condition {
                    field: ConditionField::Path,
                    operator: ConditionOperator::EndsWith,
                    value: ".php".into(), case_sensitive: false,
                }],
                ban_duration: 600,
            },
        ];
        Self { rules: Arc::new(RwLock::new(defaults)) }
    }

    pub async fn check_request(
        &self, method: &Method, uri: &Uri, headers: &HeaderMap, body: &str,
    ) -> Option<RuleViolation> {
        let rules = self.rules.read().await;
        for rule in rules.iter().filter(|r| r.enabled) {
            if rule.conditions.iter().all(|c| self.eval(c, method, uri, headers, body)) {
                return Some(RuleViolation {
                    rule_id:      rule.id.clone(),
                    rule_name:    rule.name.clone(),
                    action:       rule.action.clone(),
                    ban_duration: rule.ban_duration,
                });
            }
        }
        None
    }

    fn eval(&self, c: &Condition, method: &Method, uri: &Uri,
            headers: &HeaderMap, body: &str) -> bool {
        let raw = match &c.field {
            ConditionField::Method     => method.to_string(),
            ConditionField::Path       => uri.path().to_string(),
            ConditionField::Query      => uri.query().unwrap_or("").to_string(),
            ConditionField::Body       => body.to_string(),
            ConditionField::UserAgent  => headers.get("user-agent")
                .and_then(|v| v.to_str().ok()).unwrap_or("").to_string(),
            ConditionField::Header(n)  => headers.get(n.as_str())
                .and_then(|v| v.to_str().ok()).unwrap_or("").to_string(),
        };
        let (field, val) = if !c.case_sensitive {
            (raw.to_lowercase(), c.value.to_lowercase())
        } else {
            (raw, c.value.clone())
        };
        match c.operator {
            ConditionOperator::Equals        => field == val,
            ConditionOperator::NotEquals     => field != val,
            ConditionOperator::Contains      => field.contains(&val),
            ConditionOperator::NotContains   => !field.contains(&val),
            ConditionOperator::StartsWith    => field.starts_with(&val),
            ConditionOperator::EndsWith      => field.ends_with(&val),
            ConditionOperator::Regex         => Regex::new(&val).map(|r| r.is_match(&field)).unwrap_or(false),
            ConditionOperator::LengthGreater => val.parse::<usize>().map(|n| field.len() > n).unwrap_or(false),
            ConditionOperator::LengthLess    => val.parse::<usize>().map(|n| field.len() < n).unwrap_or(false),
        }
    }

    pub async fn get_rules(&self)               -> Vec<Rule>    { self.rules.read().await.clone() }
    pub async fn update_rules(&self, r: Vec<Rule>)              { *self.rules.write().await = r; }
    pub async fn add_rule(&self, r: Rule)                       { self.rules.write().await.push(r); }
    pub async fn remove_rule(&self, id: &str)                   { self.rules.write().await.retain(|r| r.id != id); }
}
