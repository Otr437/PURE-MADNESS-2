// waf-microservice/src/metrics.rs
use prometheus::{Counter, Histogram, HistogramOpts, IntCounter, IntGauge, Opts, Registry};

pub struct WafMetrics {
    pub registry:                  Registry,
    pub requests_allowed:          IntCounter,
    pub requests_blocked:          IntCounter,
    pub rate_limits_triggered:     IntCounter,
    pub sql_injection_blocked:     IntCounter,
    pub xss_blocked:               IntCounter,
    pub path_traversal_blocked:    IntCounter,
    pub command_injection_blocked: IntCounter,
    pub response_time:             Histogram,
    pub active_blocks:             IntGauge,
}

impl WafMetrics {
    pub fn new() -> Self {
        let registry = Registry::new();
        macro_rules! counter {
            ($n:expr, $h:expr) => {{
                let c = IntCounter::with_opts(Opts::new($n, $h)).unwrap();
                registry.register(Box::new(c.clone())).unwrap();
                c
            }};
        }
        let response_time = Histogram::with_opts(
            HistogramOpts::new("waf_response_time_seconds", "Response time")
        ).unwrap();
        registry.register(Box::new(response_time.clone())).unwrap();

        let active_blocks = IntGauge::with_opts(
            Opts::new("waf_active_blocks", "Active IP blocks")
        ).unwrap();
        registry.register(Box::new(active_blocks.clone())).unwrap();

        Self {
            registry,
            requests_allowed:          counter!("waf_requests_allowed",          "Allowed"),
            requests_blocked:          counter!("waf_requests_blocked",           "Blocked"),
            rate_limits_triggered:     counter!("waf_rate_limits",                "Rate limits"),
            sql_injection_blocked:     counter!("waf_sqli_blocked",               "SQLi blocked"),
            xss_blocked:               counter!("waf_xss_blocked",                "XSS blocked"),
            path_traversal_blocked:    counter!("waf_path_traversal_blocked",     "PTrav blocked"),
            command_injection_blocked: counter!("waf_cmdi_blocked",               "CMDi blocked"),
            response_time,
            active_blocks,
        }
    }
}
