// waf-microservice/src/attacks.rs  (re-exported for backwards compat)
pub use crate::builtin_plugins::OwaspDetectorPlugin;
