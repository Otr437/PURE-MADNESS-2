// waf-microservice/src/storage.rs
use sqlx::SqlitePool;
use std::collections::HashMap;

pub async fn init_database(db: &SqlitePool) -> anyhow::Result<()> {
    sqlx::query(r#"
        CREATE TABLE IF NOT EXISTS attack_logs (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp      INTEGER NOT NULL DEFAULT (strftime('%s','now')),
            ip_address     TEXT NOT NULL,
            attack_type    TEXT NOT NULL,
            severity       TEXT NOT NULL,
            request_method TEXT NOT NULL,
            request_path   TEXT NOT NULL,
            user_agent     TEXT NOT NULL,
            blocked        INTEGER NOT NULL,
            details        TEXT
        )"#).execute(db).await?;

    sqlx::query(r#"
        CREATE TABLE IF NOT EXISTS blocked_ips (
            ip_address  TEXT PRIMARY KEY,
            unblock_at  INTEGER NOT NULL,
            reason      TEXT NOT NULL,
            block_count INTEGER NOT NULL DEFAULT 1
        )"#).execute(db).await?;

    sqlx::query(r#"
        CREATE TABLE IF NOT EXISTS whitelist (
            ip_address TEXT PRIMARY KEY,
            reason     TEXT NOT NULL,
            added_at   INTEGER NOT NULL DEFAULT (strftime('%s','now'))
        )"#).execute(db).await?;

    sqlx::query("CREATE INDEX IF NOT EXISTS idx_al_ts ON attack_logs(timestamp)").execute(db).await?;
    sqlx::query("CREATE INDEX IF NOT EXISTS idx_al_ip ON attack_logs(ip_address)").execute(db).await?;
    Ok(())
}

pub async fn load_whitelist(db: &SqlitePool) -> anyhow::Result<HashMap<String, String>> {
    let rows = sqlx::query_as::<_, (String, String)>(
        "SELECT ip_address, reason FROM whitelist"
    ).fetch_all(db).await?;
    Ok(rows.into_iter().collect())
}

pub async fn log_attack(
    db: &SqlitePool, ip: &str, attack_type: &str, severity: &str,
    method: &str, path: &str, ua: &str, blocked: bool, details: &str,
) {
    let _ = sqlx::query(
        "INSERT INTO attack_logs (ip_address,attack_type,severity,request_method,request_path,user_agent,blocked,details)
         VALUES (?,?,?,?,?,?,?,?)"
    )
    .bind(ip).bind(attack_type).bind(severity)
    .bind(method).bind(path).bind(ua).bind(blocked).bind(details)
    .execute(db).await;
}

pub async fn fetch_attack_logs(db: &SqlitePool, limit: i64) -> anyhow::Result<Vec<serde_json::Value>> {
    let rows = sqlx::query(
        "SELECT id,timestamp,ip_address,attack_type,severity,request_method,request_path,user_agent,blocked,details
         FROM attack_logs ORDER BY id DESC LIMIT ?"
    ).bind(limit).fetch_all(db).await?;

    Ok(rows.iter().map(|r| serde_json::json!({
        "id":         sqlx::Row::try_get::<i64,_>(r,"id").ok(),
        "timestamp":  sqlx::Row::try_get::<i64,_>(r,"timestamp").ok(),
        "ip":         sqlx::Row::try_get::<String,_>(r,"ip_address").ok(),
        "type":       sqlx::Row::try_get::<String,_>(r,"attack_type").ok(),
        "severity":   sqlx::Row::try_get::<String,_>(r,"severity").ok(),
        "method":     sqlx::Row::try_get::<String,_>(r,"request_method").ok(),
        "path":       sqlx::Row::try_get::<String,_>(r,"request_path").ok(),
        "ua":         sqlx::Row::try_get::<String,_>(r,"user_agent").ok(),
        "blocked":    sqlx::Row::try_get::<bool,_>(r,"blocked").ok(),
        "details":    sqlx::Row::try_get::<String,_>(r,"details").ok(),
    })).collect())
}
