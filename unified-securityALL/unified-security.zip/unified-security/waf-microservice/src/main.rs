// waf-microservice/src/main.rs
//
// Dynamic entry-point architecture:
//   1. PluginRegistry is created first.
//   2. Built-in plugins (detectors, in-memory rate limiter, Prometheus sink)
//      are registered with the registry.
//   3. Optional external plugins (Redis, Vault, Webhook, …) register themselves
//      based on environment / config — the WAF core never imports them directly.
//   4. The axum Router and the WAF middleware only interact with the registry.

use std::{
    collections::HashMap,
    net::SocketAddr,
    sync::Arc,
    time::{Duration, SystemTime, UNIX_EPOCH},
};

use axum::{
    body::Body,
    extract::{ConnectInfo, Path, Request, State},
    http::{HeaderMap, Method, StatusCode, Uri},
    middleware::{self, Next},
    response::{IntoResponse, Response},
    routing::{delete, get, post},
    Json, Router,
};
use serde::{Deserialize, Serialize};
use sqlx::sqlite::SqlitePool;
use tokio::sync::RwLock;
use tower_http::{cors::CorsLayer, trace::TraceLayer};
use tracing::{error, info, warn};

use shared::{
    event::{EventSeverity, SecurityEvent, SecurityEventType},
    plugin::{InspectionVerdict, PluginRegistry, VerdictSeverity},
    health::{ComponentHealth, HealthState, HealthStatus},
};

mod attacks;
mod builtin_plugins;
mod config;
mod metrics;
mod rate_limit;
mod rules;
mod storage;

use attacks::*;
use builtin_plugins::*;
use config::WafConfig;
use metrics::WafMetrics;
use rate_limit::InMemoryRateLimiter;
use rules::*;
use storage::init_database;

// ─── STATE ───────────────────────────────────────────────────────────────────

#[derive(Clone)]
pub struct AppState {
    pub db:          SqlitePool,
    pub config:      Arc<WafConfig>,
    pub registry:    Arc<PluginRegistry>,
    pub blocked_ips: Arc<RwLock<HashMap<String, BlockInfo>>>,
    pub whitelist:   Arc<RwLock<HashMap<String, String>>>,
    pub metrics:     Arc<WafMetrics>,
    pub rule_engine: Arc<RuleEngine>,
    pub start_time:  u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BlockInfo {
    pub reason:      String,
    pub blocked_at:  u64,
    pub unblock_at:  u64,
    pub block_count: u32,
}

// ─── MAIN ────────────────────────────────────────────────────────────────────

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter("waf_microservice=debug,tower_http=debug")
        .json()
        .init();

    info!("Starting WAF Microservice v2.0.0");

    let config = Arc::new(WafConfig::load()?);
    let db     = SqlitePool::connect(&config.database_url).await?;
    init_database(&db).await?;
    info!("Database ready");

    // ── Bootstrap plugin registry ─────────────────────────────────────────────
    let registry = PluginRegistry::new();

    // Built-in WAF inspectors (OWASP pattern detectors)
    registry.register_waf_inspector(Arc::new(OwaspDetectorPlugin::new())).await;

    // Built-in in-memory rate limiter (replaced by Redis plugin when configured)
    registry.register_rate_backend(
        Arc::new(InMemoryRateLimiter::new(
            config.rate_limit_requests,
            config.rate_limit_window,
        ))
    ).await;

    // Built-in Prometheus metrics sink
    let metrics = Arc::new(WafMetrics::new());
    registry.register_metrics_sink(Arc::new(PrometheusMetricsSink::new(metrics.clone()))).await;

    // ── Optional external plugins loaded from config ──────────────────────────
    // Any system that wants to plug in calls register_*() here.
    // The WAF core doesn't know or care which concrete types they are.
    //
    // Example (Redis rate limiter):
    //   if let Some(url) = &config.plugin.redis_url {
    //       registry.register_rate_backend(Arc::new(RedisRateLimiter::new(url))).await;
    //   }
    //
    // Example (Vault secret manager):
    //   if let Some(url) = &config.plugin.vault_url {
    //       registry.register_secret_manager(Arc::new(VaultSecretManager::new(url, token))).await;
    //   }
    //
    // Example (Webhook event sink):
    //   if let Some(url) = &config.plugin.event_webhook_url {
    //       registry.register_event_sink(Arc::new(WebhookEventSink::new(url))).await;
    //   }

    info!("Plugin registry ready ({} plugin(s) loaded)",
          registry.list_all_plugins().await.len());

    let whitelist = Arc::new(RwLock::new(
        storage::load_whitelist(&db).await?,
    ));

    let state = AppState {
        db,
        config:      config.clone(),
        registry,
        blocked_ips: Arc::new(RwLock::new(HashMap::new())),
        whitelist,
        metrics,
        rule_engine: Arc::new(RuleEngine::new(config.clone())),
        start_time:  now(),
    };

    // ── Router ────────────────────────────────────────────────────────────────
    let app = Router::new()
        // Health & info
        .route("/waf/health",       get(health_check))
        .route("/waf/metrics",      get(get_prometheus_metrics))
        .route("/waf/stats",        get(get_stats))
        .route("/waf/plugins",      get(list_plugins))
        // IP management
        .route("/waf/blocked-ips",  get(list_blocked_ips))
        .route("/waf/blocked-ips/:ip", delete(unblock_ip_handler))
        .route("/waf/clear-blocks", post(clear_blocks))
        .route("/waf/whitelist",    get(list_whitelist).post(add_to_whitelist))
        .route("/waf/whitelist/:ip", delete(remove_from_whitelist))
        // Rules
        .route("/waf/rules",        get(list_rules).post(update_rules))
        // Logs
        .route("/waf/attack-logs",  get(get_attack_logs))
        // Proxy everything else
        .fallback(proxy_handler)
        // WAF inspection middleware applied to ALL routes
        .layer(middleware::from_fn_with_state(state.clone(), waf_middleware))
        .layer(CorsLayer::permissive())
        .layer(TraceLayer::new_for_http())
        .with_state(state);

    let addr = SocketAddr::from(([0, 0, 0, 0], config.port));
    info!("WAF listening on {}", addr);
    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, app.into_make_service_with_connect_info::<SocketAddr>()).await?;
    Ok(())
}

// ─── WAF MIDDLEWARE ───────────────────────────────────────────────────────────

async fn waf_middleware(
    State(state): State<AppState>,
    ConnectInfo(addr): ConnectInfo<SocketAddr>,
    req: Request,
    next: Next,
) -> Result<Response, StatusCode> {
    let start = SystemTime::now();
    let ip     = addr.ip().to_string();
    let method = req.method().clone();
    let uri    = req.uri().clone();
    let hdrs   = req.headers().clone();

    // Admin paths bypass inspection
    if uri.path().starts_with("/waf/") {
        return Ok(next.run(req).await);
    }

    // ── 1. Whitelist fast-path ────────────────────────────────────────────────
    {
        let wl = state.whitelist.read().await;
        if wl.contains_key(&ip) {
            state.metrics.requests_allowed.inc();
            return Ok(next.run(req).await);
        }
    }

    // ── 2. Hard-blocked IPs ───────────────────────────────────────────────────
    {
        let blocked = state.blocked_ips.read().await;
        if let Some(info) = blocked.get(&ip) {
            if now() < info.unblock_at {
                state.metrics.requests_blocked.inc();
                warn!("Blocked IP attempt: {}", ip);
                emit_blocked(&state, &ip, &method, &uri, &hdrs, &info.reason).await;
                return Err(StatusCode::FORBIDDEN);
            }
        }
    }

    // ── 3. Rate limit (via plugin registry) ───────────────────────────────────
    let allowed = state.registry.check_rate_limit(
        &ip,
        state.config.rate_limit_requests,
        state.config.rate_limit_window,
    ).await;

    if !allowed {
        state.metrics.requests_blocked.inc();
        state.metrics.rate_limits_triggered.inc();
        warn!("Rate limit: {}", ip);
        block_ip_internal(&state, &ip, "Rate limit exceeded", state.config.rate_limit_ban_duration).await;
        let ev = SecurityEvent::new(
            SecurityEventType::RateLimitExceeded,
            &ip, method.as_str(), uri.path(),
            get_ua(&hdrs), true, EventSeverity::High,
            "Rate limit exceeded",
        );
        state.registry.emit_security_event(ev).await;
        return Err(StatusCode::TOO_MANY_REQUESTS);
    }

    // ── 4. Read body for deep inspection ─────────────────────────────────────
    let (parts, body) = req.into_parts();
    let bytes = axum::body::to_bytes(body, usize::MAX).await
        .map_err(|_| StatusCode::BAD_REQUEST)?;
    let body_str = String::from_utf8_lossy(&bytes).to_string();

    // ── 5. Request size guard ─────────────────────────────────────────────────
    if bytes.len() > state.config.max_request_size {
        state.metrics.requests_blocked.inc();
        emit_event(&state, SecurityEventType::LargePayload, &ip, &method, &uri, &hdrs,
                   EventSeverity::Medium, "Payload too large").await;
        return Err(StatusCode::PAYLOAD_TOO_LARGE);
    }
    if uri.to_string().len() > state.config.max_url_length {
        state.metrics.requests_blocked.inc();
        return Err(StatusCode::URI_TOO_LONG);
    }

    // ── 6. Dynamic plugin inspection pipeline ────────────────────────────────
    let verdict = state.registry.run_inspectors(
        &method, &uri, &hdrs, &body_str, &ip,
    ).await;

    match verdict {
        InspectionVerdict::Block { reason, severity } => {
            state.metrics.requests_blocked.inc();
            let ev_sev = match severity {
                VerdictSeverity::Critical => EventSeverity::Critical,
                VerdictSeverity::High     => EventSeverity::High,
                VerdictSeverity::Medium   => EventSeverity::Medium,
                VerdictSeverity::Low      => EventSeverity::Low,
            };
            warn!("Plugin blocked {} — {}", ip, reason);
            block_ip_internal(&state, &ip, &reason, state.config.attack_ban_duration).await;
            emit_event(&state, SecurityEventType::CustomRule(reason.clone()),
                       &ip, &method, &uri, &hdrs, ev_sev, &reason).await;
            storage::log_attack(&state.db, &ip, &reason, "PluginBlock",
                                "High", method.as_str(), uri.path(),
                                &get_ua(&hdrs), true, &reason).await;
            return Err(StatusCode::FORBIDDEN);
        }
        InspectionVerdict::Challenge { .. } => {
            // Extend here: return 403 or a JS challenge page
            return Err(StatusCode::FORBIDDEN);
        }
        InspectionVerdict::Log { reason } => {
            warn!("Plugin logged suspicious request from {}: {}", ip, reason);
        }
        InspectionVerdict::Allow => {}
    }

    // ── 7. Rebuild and forward ────────────────────────────────────────────────
    state.metrics.requests_allowed.inc();
    let req = Request::from_parts(parts, Body::from(bytes));
    let resp = next.run(req).await;
    if let Ok(elapsed) = start.elapsed() {
        state.metrics.response_time.observe(elapsed.as_secs_f64());
    }
    Ok(resp)
}

// ─── ADMIN HANDLERS ──────────────────────────────────────────────────────────

async fn health_check(State(state): State<AppState>) -> impl IntoResponse {
    let db_ok = sqlx::query("SELECT 1").fetch_one(&state.db).await.is_ok();
    let uptime = now().saturating_sub(state.start_time);

    let status = HealthStatus {
        status:  if db_ok { HealthState::Healthy } else { HealthState::Degraded },
        service: "waf-microservice".into(),
        version: "2.0.0".into(),
        uptime_secs: uptime,
        checks:  vec![
            ComponentHealth {
                name:    "database".into(),
                status:  if db_ok { HealthState::Healthy } else { HealthState::Unhealthy },
                latency_ms: None,
                message: None,
            },
        ],
    };
    Json(status)
}

async fn get_prometheus_metrics(State(state): State<AppState>) -> impl IntoResponse {
    use prometheus::Encoder;
    let encoder = prometheus::TextEncoder::new();
    let families = state.metrics.registry.gather();
    let mut buf = vec![];
    encoder.encode(&families, &mut buf).unwrap_or_default();
    Response::builder()
        .header("Content-Type", encoder.format_type())
        .body(Body::from(buf))
        .unwrap()
}

async fn get_stats(State(state): State<AppState>) -> impl IntoResponse {
    Json(serde_json::json!({
        "blocked_ips":   state.blocked_ips.read().await.len(),
        "whitelist_size": state.whitelist.read().await.len(),
        "uptime_secs":   now().saturating_sub(state.start_time),
    }))
}

async fn list_plugins(State(state): State<AppState>) -> impl IntoResponse {
    Json(state.registry.list_all_plugins().await)
}

async fn list_blocked_ips(State(state): State<AppState>) -> impl IntoResponse {
    let blocked = state.blocked_ips.read().await;
    let t = now();
    let list: Vec<_> = blocked.iter()
        .filter(|(_, i)| t < i.unblock_at)
        .map(|(ip, i)| serde_json::json!({
            "ip": ip,
            "reason": i.reason,
            "blocked_at": i.blocked_at,
            "unblock_at": i.unblock_at,
            "remaining_secs": i.unblock_at.saturating_sub(t),
            "block_count": i.block_count,
        }))
        .collect();
    Json(list)
}

async fn unblock_ip_handler(
    State(state): State<AppState>,
    Path(ip): Path<String>,
) -> impl IntoResponse {
    state.blocked_ips.write().await.remove(&ip);
    Json(serde_json::json!({"success": true, "ip": ip}))
}

async fn clear_blocks(State(state): State<AppState>) -> impl IntoResponse {
    state.blocked_ips.write().await.clear();
    Json(serde_json::json!({"success": true}))
}

async fn list_whitelist(State(state): State<AppState>) -> impl IntoResponse {
    let wl = state.whitelist.read().await;
    let list: Vec<_> = wl.iter()
        .map(|(ip, r)| serde_json::json!({"ip": ip, "reason": r}))
        .collect();
    Json(list)
}

#[derive(Deserialize)]
struct WhitelistReq { ip: String, reason: String }

async fn add_to_whitelist(
    State(state): State<AppState>,
    Json(req): Json<WhitelistReq>,
) -> impl IntoResponse {
    if req.ip.parse::<std::net::IpAddr>().is_err() {
        return (StatusCode::BAD_REQUEST, "Invalid IP").into_response();
    }
    let _ = sqlx::query(
        "INSERT OR REPLACE INTO whitelist (ip_address, reason) VALUES (?,?)"
    )
    .bind(&req.ip).bind(&req.reason)
    .execute(&state.db).await;

    state.whitelist.write().await.insert(req.ip.clone(), req.reason.clone());
    Json(serde_json::json!({"success": true})).into_response()
}

async fn remove_from_whitelist(
    State(state): State<AppState>,
    Path(ip): Path<String>,
) -> impl IntoResponse {
    let _ = sqlx::query("DELETE FROM whitelist WHERE ip_address=?")
        .bind(&ip).execute(&state.db).await;
    state.whitelist.write().await.remove(&ip);
    Json(serde_json::json!({"success": true, "ip": ip}))
}

async fn list_rules(State(state): State<AppState>) -> impl IntoResponse {
    Json(state.rule_engine.get_rules().await)
}

#[derive(Deserialize)]
struct RulesUpdate { rules: Vec<Rule> }

async fn update_rules(
    State(state): State<AppState>,
    Json(body): Json<RulesUpdate>,
) -> impl IntoResponse {
    state.rule_engine.update_rules(body.rules).await;
    Json(serde_json::json!({"success": true}))
}

async fn get_attack_logs(State(state): State<AppState>) -> impl IntoResponse {
    match storage::fetch_attack_logs(&state.db, 100).await {
        Ok(logs) => Json(logs).into_response(),
        Err(e)   => {
            error!("DB error: {}", e);
            StatusCode::INTERNAL_SERVER_ERROR.into_response()
        }
    }
}

async fn proxy_handler(
    State(_state): State<AppState>,
    method: Method,
    uri: Uri,
) -> impl IntoResponse {
    Json(serde_json::json!({
        "waf": "passed",
        "method": method.to_string(),
        "path": uri.path(),
    }))
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

fn now() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs()
}

fn get_ua(h: &HeaderMap) -> String {
    h.get("user-agent").and_then(|v| v.to_str().ok())
     .unwrap_or("unknown").to_string()
}

async fn block_ip_internal(state: &AppState, ip: &str, reason: &str, secs: u64) {
    let t = now();
    let mut blocked = state.blocked_ips.write().await;
    let count = blocked.get(ip).map(|i| i.block_count + 1).unwrap_or(1);
    blocked.insert(ip.to_string(), BlockInfo {
        reason: reason.to_string(),
        blocked_at: t, unblock_at: t + secs, block_count: count,
    });
    let _ = sqlx::query(
        "INSERT OR REPLACE INTO blocked_ips (ip_address,unblock_at,reason,block_count) VALUES(?,?,?,?)"
    )
    .bind(ip).bind((t + secs) as i64).bind(reason).bind(count as i64)
    .execute(&state.db).await;
}

async fn emit_blocked(
    state: &AppState, ip: &str, method: &Method, uri: &Uri,
    hdrs: &HeaderMap, reason: &str,
) {
    let ev = SecurityEvent::new(
        SecurityEventType::IpBlocked,
        ip, method.as_str(), uri.path(), get_ua(hdrs),
        true, EventSeverity::High, reason,
    );
    state.registry.emit_security_event(ev).await;
}

async fn emit_event(
    state: &AppState,
    kind: SecurityEventType,
    ip: &str, method: &Method, uri: &Uri, hdrs: &HeaderMap,
    severity: EventSeverity, details: &str,
) {
    let ev = SecurityEvent::new(
        kind, ip, method.as_str(), uri.path(), get_ua(hdrs),
        true, severity, details,
    );
    state.registry.emit_security_event(ev).await;
}
