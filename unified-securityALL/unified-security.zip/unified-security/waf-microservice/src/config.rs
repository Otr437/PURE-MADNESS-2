// waf-microservice/src/config.rs
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WafConfig {
    pub port:                   u16,
    pub database_url:           String,
    pub rate_limit_requests:    u32,
    pub rate_limit_window:      u64,
    pub rate_limit_ban_duration: u64,
    pub attack_ban_duration:    u64,
    pub max_request_size:       usize,
    pub max_url_length:         usize,
    pub plugin:                 shared::config::PluginConfig,
}

impl WafConfig {
    pub fn load() -> anyhow::Result<Self> {
        if let Ok(s) = std::fs::read_to_string("waf-config.toml") {
            return Ok(toml::from_str(&s)?);
        }
        Ok(Self::default())
    }
}

impl Default for WafConfig {
    fn default() -> Self {
        Self {
            port:                    8080,
            database_url:            "sqlite://waf.db".into(),
            rate_limit_requests:     100,
            rate_limit_window:       60,
            rate_limit_ban_duration: 300,
            attack_ban_duration:     3600,
            max_request_size:        10 * 1024 * 1024,
            max_url_length:          2048,
            plugin:                  Default::default(),
        }
    }
}
