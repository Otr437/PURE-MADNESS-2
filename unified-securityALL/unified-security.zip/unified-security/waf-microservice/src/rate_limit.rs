// waf-microservice/src/rate_limit.rs
use async_trait::async_trait;
use std::{collections::HashMap, sync::Arc, time::{SystemTime, UNIX_EPOCH}};
use tokio::sync::Mutex;
use shared::plugin::{PluginCapability, PluginMeta, RateLimitBackend};
use shared::error::PluginError;

pub struct InMemoryRateLimiter {
    meta:    PluginMeta,
    default_limit:  u32,
    default_window: u64,
    windows: Arc<Mutex<HashMap<String, Vec<u64>>>>,
}

impl InMemoryRateLimiter {
    pub fn new(limit: u32, window: u64) -> Self {
        Self {
            meta: PluginMeta {
                id:           "builtin.in_memory_rate_limiter".into(),
                name:         "In-Memory Rate Limiter".into(),
                version:      "2.0.0".into(),
                description:  "Token-window rate limiter backed by a HashMap".into(),
                author:       "built-in".into(),
                capabilities: vec![PluginCapability::RateLimitBackend],
            },
            default_limit:  limit,
            default_window: window,
            windows: Arc::new(Mutex::new(HashMap::new())),
        }
    }
}

fn ts() -> u64 { SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs() }

#[async_trait]
impl RateLimitBackend for InMemoryRateLimiter {
    fn meta(&self) -> &PluginMeta { &self.meta }

    async fn check(&self, key: &str, limit: u32, window_secs: u64) -> Result<bool, PluginError> {
        let now        = ts();
        let cutoff     = now - window_secs;
        let mut windows = self.windows.lock().await;
        let w          = windows.entry(key.to_string()).or_default();
        w.retain(|&t| t > cutoff);
        if w.len() >= limit as usize {
            return Ok(false);
        }
        w.push(now);
        // Periodic GC
        if windows.len() > 50_000 {
            windows.retain(|_, v| !v.is_empty());
        }
        Ok(true)
    }

    async fn reset(&self, key: &str) -> Result<(), PluginError> {
        self.windows.lock().await.remove(key);
        Ok(())
    }

    async fn remaining(&self, key: &str, window_secs: u64) -> Result<u32, PluginError> {
        let now    = ts();
        let cutoff = now - window_secs;
        let windows = self.windows.lock().await;
        let count  = windows.get(key)
            .map(|v| v.iter().filter(|&&t| t > cutoff).count())
            .unwrap_or(0);
        Ok(self.default_limit.saturating_sub(count as u32))
    }
}
