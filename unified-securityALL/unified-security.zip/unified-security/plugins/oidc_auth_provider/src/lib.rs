// plugins/oidc_auth_provider/src/lib.rs
//
// Validates Bearer tokens against any OIDC-compliant issuer (Keycloak, Auth0,
// Cognito, Okta, …).
// Register with:
//   registry.register_auth_provider(Arc::new(OidcAuthProvider::new(issuer, audience))).await;

use async_trait::async_trait;
use shared::plugin::{AuthProvider, PluginCapability, PluginMeta, TokenClaims};
use shared::error::PluginError;

pub struct OidcAuthProvider {
    meta:     PluginMeta,
    issuer:   String,
    audience: String,
}

impl OidcAuthProvider {
    pub fn new(issuer: &str, audience: &str) -> Self {
        Self {
            issuer:   issuer.to_string(),
            audience: audience.to_string(),
            meta: PluginMeta {
                id:           "plugin.oidc_auth_provider".into(),
                name:         "OIDC Auth Provider".into(),
                version:      "1.0.0".into(),
                description:  "Validates JWTs via OIDC JWKS discovery".into(),
                author:       "external".into(),
                capabilities: vec![PluginCapability::AuthProvider, PluginCapability::TokenValidator],
            },
        }
    }

    fn jwks_url(&self) -> String {
        format!("{}/.well-known/jwks.json", self.issuer)
    }
}

#[async_trait]
impl AuthProvider for OidcAuthProvider {
    fn meta(&self) -> &PluginMeta { &self.meta }

    async fn validate_token(&self, token: &str) -> Result<TokenClaims, PluginError> {
        // Production implementation:
        //
        // 1. Fetch JWKS from self.jwks_url() (cached with TTL).
        // 2. Decode token header to find `kid`.
        // 3. Find matching JWK, convert to DecodingKey.
        // 4. Validate signature, exp, aud, iss with jsonwebtoken.
        // 5. Extract standard claims (sub, roles, permissions, exp).
        //
        //   let jwks = fetch_jwks(&self.jwks_url()).await?;
        //   let claims = decode_jwt(token, &jwks, &self.audience, &self.issuer)?;
        //   Ok(TokenClaims { subject: claims.sub, ... })

        Err(PluginError::Unavailable(
            format!("OidcAuthProvider: configure issuer={}", self.issuer)
        ))
    }

    async fn refresh_token(&self, _token: &str) -> Result<String, PluginError> {
        Err(PluginError::Unavailable("OidcAuthProvider: refresh not implemented".into()))
    }

    async fn revoke_token(&self, _token: &str) -> Result<(), PluginError> {
        // POST to issuer's revocation endpoint
        Ok(())
    }

    async fn introspect(&self, token: &str) -> Result<serde_json::Value, PluginError> {
        // POST to issuer's /introspect endpoint
        Err(PluginError::Unavailable("OidcAuthProvider: introspect not implemented".into()))
    }
}
