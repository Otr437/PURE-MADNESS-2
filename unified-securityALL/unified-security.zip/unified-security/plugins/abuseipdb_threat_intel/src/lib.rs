// plugins/abuseipdb_threat_intel/src/lib.rs
//
// Plugs real-time IP reputation data from AbuseIPDB into the WAF.
// Register with:
//   registry.register_threat_intel(Arc::new(AbuseIpDbPlugin::new(api_key))).await;

use async_trait::async_trait;
use shared::plugin::{
    DomainReputation, IpReputation, PluginCapability, PluginMeta, ThreatIntelligence,
};
use shared::error::PluginError;

pub struct AbuseIpDbPlugin {
    meta:    PluginMeta,
    api_key: String,
    /// Score above which an IP is considered malicious (0–100).
    block_threshold: u8,
}

impl AbuseIpDbPlugin {
    pub fn new(api_key: &str) -> Self {
        Self {
            api_key: api_key.to_string(),
            block_threshold: 50,
            meta: PluginMeta {
                id:           "plugin.abuseipdb".into(),
                name:         "AbuseIPDB Threat Intel".into(),
                version:      "1.0.0".into(),
                description:  "IP reputation scores from AbuseIPDB".into(),
                author:       "external".into(),
                capabilities: vec![
                    PluginCapability::ThreatIntelligence,
                    PluginCapability::IpReputationCheck,
                ],
            },
        }
    }
}

#[async_trait]
impl ThreatIntelligence for AbuseIpDbPlugin {
    fn meta(&self) -> &PluginMeta { &self.meta }

    async fn lookup_ip(&self, ip: &str) -> Result<IpReputation, PluginError> {
        // Production:
        //
        //   let resp = reqwest::Client::new()
        //       .get("https://api.abuseipdb.com/api/v2/check")
        //       .header("Key", &self.api_key)
        //       .header("Accept", "application/json")
        //       .query(&[("ipAddress", ip), ("maxAgeInDays", "90")])
        //       .send().await
        //       .map_err(|e| PluginError::Unavailable(e.to_string()))?
        //       .json::<serde_json::Value>().await
        //       .map_err(|e| PluginError::Internal(e.to_string()))?;
        //
        //   let score = resp["data"]["abuseConfidenceScore"].as_u64().unwrap_or(0) as f32;
        //   let country = resp["data"]["countryCode"].as_str().map(|s| s.to_string());
        //
        //   Ok(IpReputation {
        //       ip: ip.to_string(),
        //       score: score / 100.0,
        //       categories: vec![],
        //       country,
        //       asn: resp["data"]["isp"].as_str().map(|_| 0),
        //       blocked: score >= self.block_threshold as f32,
        //   })

        // Stub until API key is configured:
        Ok(IpReputation {
            ip:         ip.to_string(),
            score:      0.0,
            categories: vec![],
            country:    None,
            asn:        None,
            blocked:    false,
        })
    }

    async fn lookup_domain(&self, domain: &str) -> Result<DomainReputation, PluginError> {
        // AbuseIPDB is IP-focused; domain lookup would use a different feed.
        Ok(DomainReputation {
            domain:     domain.to_string(),
            score:      0.0,
            categories: vec![],
            blocked:    false,
        })
    }
}
