// plugins/webhook_event_sink/src/lib.rs
//
// Forwards every SecurityEvent and CryptoEvent to a configurable HTTP endpoint.
// Plug into either service:
//   registry.register_event_sink(Arc::new(WebhookEventSink::new(url))).await;

use async_trait::async_trait;
use shared::event::{CryptoEvent, SecurityEvent};
use shared::plugin::{EventSink, PluginCapability, PluginMeta};
use shared::error::PluginError;

pub struct WebhookEventSink {
    meta:        PluginMeta,
    endpoint:    String,
    // client:   reqwest::Client,
}

impl WebhookEventSink {
    pub fn new(endpoint: &str) -> Self {
        Self {
            endpoint: endpoint.to_string(),
            meta: PluginMeta {
                id:           "plugin.webhook_event_sink".into(),
                name:         "Webhook Event Sink".into(),
                version:      "1.0.0".into(),
                description:  "POSTs security/crypto events to a webhook URL".into(),
                author:       "external".into(),
                capabilities: vec![PluginCapability::Auditor],
            },
        }
    }
}

#[async_trait]
impl EventSink for WebhookEventSink {
    fn meta(&self) -> &PluginMeta { &self.meta }

    async fn send_security_event(&self, event: SecurityEvent) -> Result<(), PluginError> {
        // Production:
        //   self.client.post(&self.endpoint)
        //       .json(&event).send().await
        //       .map_err(|e| PluginError::Unavailable(e.to_string()))?;
        tracing::info!(
            target: "webhook_sink",
            event_id   = %event.id,
            event_type = ?event.event_type,
            ip         = %event.ip_address,
            blocked    = event.blocked,
            "Security event → {}",
            self.endpoint,
        );
        Ok(())
    }

    async fn send_crypto_event(&self, event: CryptoEvent) -> Result<(), PluginError> {
        tracing::info!(
            target: "webhook_sink",
            event_id   = %event.id,
            event_type = ?event.event_type,
            algorithm  = %event.algorithm,
            success    = event.success,
            "Crypto event → {}",
            self.endpoint,
        );
        Ok(())
    }

    async fn flush(&self) -> Result<(), PluginError> { Ok(()) }
}
