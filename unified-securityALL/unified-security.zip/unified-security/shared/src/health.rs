// shared/src/health.rs

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HealthStatus {
    pub status:   HealthState,
    pub service:  String,
    pub version:  String,
    pub checks:   Vec<ComponentHealth>,
    pub uptime_secs: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "lowercase")]
pub enum HealthState {
    Healthy,
    Degraded,
    Unhealthy,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ComponentHealth {
    pub name:    String,
    pub status:  HealthState,
    pub latency_ms: Option<u64>,
    pub message: Option<String>,
}
