// shared/src/plugin.rs
//
// Every external integration implements one or more of these traits and calls
// PluginRegistry::register().  Both the WAF and the crypto service call
// PluginRegistry::get_*() at startup and at runtime — they never import a
// concrete impl directly, which is what makes the entry points truly dynamic.

use std::{collections::HashMap, sync::Arc};
use async_trait::async_trait;
use axum::http::{HeaderMap, Method, Uri};
use serde_json::Value;
use tokio::sync::RwLock;
use crate::event::{SecurityEvent, CryptoEvent};
use crate::error::PluginError;

// ─── METADATA ────────────────────────────────────────────────────────────────

#[derive(Debug, Clone)]
pub struct PluginMeta {
    pub id:          String,
    pub name:        String,
    pub version:     String,
    pub description: String,
    pub author:      String,
    pub capabilities: Vec<PluginCapability>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PluginCapability {
    WafInspector,
    WafRuleProvider,
    ThreatIntelligence,
    IpReputationCheck,
    RateLimitBackend,
    SecretManager,
    KeyStoreBackend,
    CryptoProvider,
    Notifier,
    Auditor,
    MetricsSink,
    AuthProvider,
    TokenValidator,
}

// ─── WAF TRAITS ──────────────────────────────────────────────────────────────

/// Inspect an incoming request and optionally produce a verdict.
/// Return None to pass the request on to the next inspector.
#[async_trait]
pub trait WafInspector: Send + Sync + 'static {
    fn meta(&self) -> &PluginMeta;

    async fn inspect(
        &self,
        method:  &Method,
        uri:     &Uri,
        headers: &HeaderMap,
        body:    &str,
        client_ip: &str,
    ) -> Result<InspectionVerdict, PluginError>;
}

#[derive(Debug, Clone)]
pub enum InspectionVerdict {
    Allow,
    Block  { reason: String, severity: VerdictSeverity },
    Challenge { reason: String },
    Log    { reason: String },
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum VerdictSeverity {
    Critical,
    High,
    Medium,
    Low,
}

/// Supply additional WAF rules at startup or on-demand.
#[async_trait]
pub trait WafRuleProvider: Send + Sync + 'static {
    fn meta(&self) -> &PluginMeta;
    async fn load_rules(&self) -> Result<Vec<Value>, PluginError>;
    async fn reload(&self)    -> Result<Vec<Value>, PluginError>;
}

/// Real-time IP reputation / threat intel feed.
#[async_trait]
pub trait ThreatIntelligence: Send + Sync + 'static {
    fn meta(&self) -> &PluginMeta;
    async fn lookup_ip(&self, ip: &str) -> Result<IpReputation, PluginError>;
    async fn lookup_domain(&self, domain: &str) -> Result<DomainReputation, PluginError>;
}

#[derive(Debug, Clone)]
pub struct IpReputation {
    pub ip:          String,
    pub score:       f32,          // 0.0 (clean) – 1.0 (malicious)
    pub categories:  Vec<String>,  // "botnet", "tor", "vpn", …
    pub country:     Option<String>,
    pub asn:         Option<u32>,
    pub blocked:     bool,
}

#[derive(Debug, Clone)]
pub struct DomainReputation {
    pub domain:      String,
    pub score:       f32,
    pub categories:  Vec<String>,
    pub blocked:     bool,
}

/// Pluggable rate-limiting backend (Redis, DynamoDB, Valkey, in-memory, …).
#[async_trait]
pub trait RateLimitBackend: Send + Sync + 'static {
    fn meta(&self) -> &PluginMeta;
    /// Returns true when the request is allowed.
    async fn check(&self, key: &str, limit: u32, window_secs: u64) -> Result<bool, PluginError>;
    async fn reset(&self, key: &str) -> Result<(), PluginError>;
    async fn remaining(&self, key: &str, window_secs: u64) -> Result<u32, PluginError>;
}

// ─── CRYPTO TRAITS ───────────────────────────────────────────────────────────

/// Pluggable secret / key storage (HashiCorp Vault, AWS KMS, Azure Key Vault, …).
#[async_trait]
pub trait SecretManager: Send + Sync + 'static {
    fn meta(&self) -> &PluginMeta;
    async fn get_secret(&self, path: &str)          -> Result<String, PluginError>;
    async fn put_secret(&self, path: &str, val: &str) -> Result<(), PluginError>;
    async fn delete_secret(&self, path: &str)        -> Result<(), PluginError>;
    async fn list_secrets(&self, prefix: &str)       -> Result<Vec<String>, PluginError>;
    async fn rotate_secret(&self, path: &str)        -> Result<String, PluginError>;
}

/// Pluggable cryptographic key storage.
#[async_trait]
pub trait KeyStoreBackend: Send + Sync + 'static {
    fn meta(&self) -> &PluginMeta;
    async fn store_key(&self, id: &str, blob: &[u8])  -> Result<(), PluginError>;
    async fn load_key(&self, id: &str)                 -> Result<Vec<u8>, PluginError>;
    async fn delete_key(&self, id: &str)               -> Result<(), PluginError>;
    async fn list_keys(&self, prefix: &str)            -> Result<Vec<String>, PluginError>;
    async fn rotate_key(&self, id: &str)               -> Result<(), PluginError>;
}

/// Pluggable symmetric / asymmetric crypto provider (HSM, TPM, Cloud KMS …).
#[async_trait]
pub trait CryptoProvider: Send + Sync + 'static {
    fn meta(&self) -> &PluginMeta;
    async fn encrypt(&self, key_id: &str, data: &[u8]) -> Result<Vec<u8>, PluginError>;
    async fn decrypt(&self, key_id: &str, data: &[u8]) -> Result<Vec<u8>, PluginError>;
    async fn sign(&self,    key_id: &str, data: &[u8]) -> Result<Vec<u8>, PluginError>;
    async fn verify(&self,  key_id: &str, data: &[u8], sig: &[u8]) -> Result<bool, PluginError>;
    async fn generate_key(&self, algorithm: &str)       -> Result<String, PluginError>;
}

// ─── CROSS-CUTTING TRAITS ────────────────────────────────────────────────────

/// Auth / identity provider (OAuth2, OIDC, SAML, API keys …).
#[async_trait]
pub trait AuthProvider: Send + Sync + 'static {
    fn meta(&self) -> &PluginMeta;
    async fn validate_token(&self, token: &str)        -> Result<TokenClaims, PluginError>;
    async fn refresh_token(&self, token: &str)         -> Result<String, PluginError>;
    async fn revoke_token(&self, token: &str)          -> Result<(), PluginError>;
    async fn introspect(&self, token: &str)            -> Result<Value, PluginError>;
}

#[derive(Debug, Clone)]
pub struct TokenClaims {
    pub subject:     String,
    pub roles:       Vec<String>,
    pub permissions: Vec<String>,
    pub expires_at:  i64,
    pub extra:       Value,
}

/// Receives structured security / crypto events for audit, alerting, SIEM, etc.
#[async_trait]
pub trait EventSink: Send + Sync + 'static {
    fn meta(&self) -> &PluginMeta;
    async fn send_security_event(&self, event: SecurityEvent) -> Result<(), PluginError>;
    async fn send_crypto_event(&self,   event: CryptoEvent)   -> Result<(), PluginError>;
    async fn flush(&self)                                      -> Result<(), PluginError>;
}

/// Metrics back-end (Prometheus, DataDog, OTel …).
#[async_trait]
pub trait MetricsSink: Send + Sync + 'static {
    fn meta(&self) -> &PluginMeta;
    async fn counter(&self, name: &str, labels: &[(&str, &str)], delta: f64) -> Result<(), PluginError>;
    async fn gauge(&self,   name: &str, labels: &[(&str, &str)], val: f64)   -> Result<(), PluginError>;
    async fn histogram(&self, name: &str, labels: &[(&str, &str)], val: f64) -> Result<(), PluginError>;
}

// ─── PLUGIN REGISTRY ─────────────────────────────────────────────────────────

/// Central registry — both services call this instead of importing concrete types.
#[derive(Default)]
pub struct PluginRegistry {
    pub waf_inspectors:    RwLock<Vec<Arc<dyn WafInspector>>>,
    pub rule_providers:    RwLock<Vec<Arc<dyn WafRuleProvider>>>,
    pub threat_intel:      RwLock<Vec<Arc<dyn ThreatIntelligence>>>,
    pub rate_backends:     RwLock<Vec<Arc<dyn RateLimitBackend>>>,
    pub secret_managers:   RwLock<Vec<Arc<dyn SecretManager>>>,
    pub key_stores:        RwLock<Vec<Arc<dyn KeyStoreBackend>>>,
    pub crypto_providers:  RwLock<Vec<Arc<dyn CryptoProvider>>>,
    pub auth_providers:    RwLock<Vec<Arc<dyn AuthProvider>>>,
    pub event_sinks:       RwLock<Vec<Arc<dyn EventSink>>>,
    pub metrics_sinks:     RwLock<Vec<Arc<dyn MetricsSink>>>,
}

impl PluginRegistry {
    pub fn new() -> Arc<Self> { Arc::new(Self::default()) }

    // ── Registration ──────────────────────────────────────────────────────────
    pub async fn register_waf_inspector(&self, p: Arc<dyn WafInspector>) {
        self.waf_inspectors.write().await.push(p);
    }
    pub async fn register_rule_provider(&self, p: Arc<dyn WafRuleProvider>) {
        self.rule_providers.write().await.push(p);
    }
    pub async fn register_threat_intel(&self, p: Arc<dyn ThreatIntelligence>) {
        self.threat_intel.write().await.push(p);
    }
    pub async fn register_rate_backend(&self, p: Arc<dyn RateLimitBackend>) {
        self.rate_backends.write().await.push(p);
    }
    pub async fn register_secret_manager(&self, p: Arc<dyn SecretManager>) {
        self.secret_managers.write().await.push(p);
    }
    pub async fn register_key_store(&self, p: Arc<dyn KeyStoreBackend>) {
        self.key_stores.write().await.push(p);
    }
    pub async fn register_crypto_provider(&self, p: Arc<dyn CryptoProvider>) {
        self.crypto_providers.write().await.push(p);
    }
    pub async fn register_auth_provider(&self, p: Arc<dyn AuthProvider>) {
        self.auth_providers.write().await.push(p);
    }
    pub async fn register_event_sink(&self, p: Arc<dyn EventSink>) {
        self.event_sinks.write().await.push(p);
    }
    pub async fn register_metrics_sink(&self, p: Arc<dyn MetricsSink>) {
        self.metrics_sinks.write().await.push(p);
    }

    // ── Convenience: run all WAF inspectors, return first non-Allow verdict ──
    pub async fn run_inspectors(
        &self,
        method: &Method,
        uri:    &Uri,
        headers: &HeaderMap,
        body:   &str,
        ip:     &str,
    ) -> InspectionVerdict {
        let inspectors = self.waf_inspectors.read().await;
        for inspector in inspectors.iter() {
            match inspector.inspect(method, uri, headers, body, ip).await {
                Ok(InspectionVerdict::Allow) => continue,
                Ok(verdict) => return verdict,
                Err(e) => {
                    tracing::error!("Inspector {} error: {}", inspector.meta().id, e);
                    continue;
                }
            }
        }
        InspectionVerdict::Allow
    }

    // ── Convenience: fan-out to all event sinks ──────────────────────────────
    pub async fn emit_security_event(&self, event: SecurityEvent) {
        let sinks = self.event_sinks.read().await;
        for sink in sinks.iter() {
            if let Err(e) = sink.send_security_event(event.clone()).await {
                tracing::warn!("EventSink {} error: {}", sink.meta().id, e);
            }
        }
    }

    pub async fn emit_crypto_event(&self, event: CryptoEvent) {
        let sinks = self.event_sinks.read().await;
        for sink in sinks.iter() {
            if let Err(e) = sink.send_crypto_event(event.clone()).await {
                tracing::warn!("EventSink {} error: {}", sink.meta().id, e);
            }
        }
    }

    // ── Convenience: first registered rate-limit backend (or in-memory) ──────
    pub async fn check_rate_limit(
        &self,
        key: &str,
        limit: u32,
        window_secs: u64,
    ) -> bool {
        let backends = self.rate_backends.read().await;
        if backends.is_empty() { return true; }
        match backends[0].check(key, limit, window_secs).await {
            Ok(allowed) => allowed,
            Err(e) => { tracing::error!("RateLimit backend error: {}", e); true }
        }
    }

    // ── Convenience: first registered secret manager ─────────────────────────
    pub async fn get_secret(&self, path: &str) -> Option<String> {
        let managers = self.secret_managers.read().await;
        if managers.is_empty() { return None; }
        match managers[0].get_secret(path).await {
            Ok(v) => Some(v),
            Err(e) => { tracing::error!("SecretManager error for {}: {}", path, e); None }
        }
    }

    // ── Convenience: first registered key store ───────────────────────────────
    pub async fn load_key(&self, id: &str) -> Option<Vec<u8>> {
        let stores = self.key_stores.read().await;
        if stores.is_empty() { return None; }
        match stores[0].load_key(id).await {
            Ok(k) => Some(k),
            Err(_) => None,
        }
    }

    /// Snapshot of all registered plugin metadata, useful for the /plugins endpoint.
    pub async fn list_all_plugins(&self) -> Vec<Value> {
        let mut out = vec![];
        macro_rules! collect {
            ($field:ident, $kind:expr) => {
                for p in self.$field.read().await.iter() {
                    let m = p.meta();
                    out.push(serde_json::json!({
                        "id": m.id,
                        "name": m.name,
                        "version": m.version,
                        "kind": $kind,
                        "capabilities": format!("{:?}", m.capabilities),
                    }));
                }
            };
        }
        collect!(waf_inspectors,   "WafInspector");
        collect!(rule_providers,   "WafRuleProvider");
        collect!(threat_intel,     "ThreatIntelligence");
        collect!(rate_backends,    "RateLimitBackend");
        collect!(secret_managers,  "SecretManager");
        collect!(key_stores,       "KeyStoreBackend");
        collect!(crypto_providers, "CryptoProvider");
        collect!(auth_providers,   "AuthProvider");
        collect!(event_sinks,      "EventSink");
        collect!(metrics_sinks,    "MetricsSink");
        out
    }
}
