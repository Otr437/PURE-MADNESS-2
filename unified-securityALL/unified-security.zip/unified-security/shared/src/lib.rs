// shared/src/lib.rs
// ─────────────────────────────────────────────────────────────────────────────
// Unified plugin / extension trait system.
//
// Any external system (WAF rule packs, auth providers, secret managers,
// observability back-ends, AI-based detectors …) implements one or more of
// the traits below and registers itself through `PluginRegistry`.
//
// Nothing in waf-microservice or crypto-service is hard-coded — they only
// talk to these traits.
// ─────────────────────────────────────────────────────────────────────────────

pub mod plugin;
pub mod event;
pub mod config;
pub mod error;
pub mod health;

pub use plugin::*;
pub use event::*;
pub use config::*;
pub use error::*;
pub use health::*;
