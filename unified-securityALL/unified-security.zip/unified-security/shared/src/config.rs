// shared/src/config.rs

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ServiceConfig {
    pub service_name: String,
    pub port:         u16,
    pub log_level:    String,
    pub database_url: String,
    pub plugins:      PluginConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct PluginConfig {
    /// Optional Redis URL for pluggable rate-limit backend
    pub redis_url:          Option<String>,
    /// Optional HashiCorp Vault address
    pub vault_url:          Option<String>,
    pub vault_token:        Option<String>,
    /// Optional webhook URL to POST security events to
    pub event_webhook_url:  Option<String>,
    /// Optional external threat intel API key
    pub threat_intel_key:   Option<String>,
    /// Optional OpenTelemetry collector endpoint
    pub otel_endpoint:      Option<String>,
}
