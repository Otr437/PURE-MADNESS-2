// shared/src/error.rs

use thiserror::Error;

#[derive(Debug, Error)]
pub enum PluginError {
    #[error("Not found: {0}")]
    NotFound(String),
    #[error("Unauthorized: {0}")]
    Unauthorized(String),
    #[error("Backend unavailable: {0}")]
    Unavailable(String),
    #[error("Invalid input: {0}")]
    InvalidInput(String),
    #[error("Internal error: {0}")]
    Internal(String),
    #[error("Timeout: {0}")]
    Timeout(String),
    #[error("Rate limit: {0}")]
    RateLimit(String),
}
