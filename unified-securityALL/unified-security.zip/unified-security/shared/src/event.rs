// shared/src/event.rs

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SecurityEvent {
    pub id:         String,
    pub timestamp:  DateTime<Utc>,
    pub event_type: SecurityEventType,
    pub ip_address: String,
    pub method:     String,
    pub path:       String,
    pub user_agent: String,
    pub payload:    Option<String>,
    pub blocked:    bool,
    pub severity:   EventSeverity,
    pub details:    String,
    pub metadata:   serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SecurityEventType {
    SqlInjection,
    Xss,
    PathTraversal,
    CommandInjection,
    Xxe,
    Ssrf,
    RateLimitExceeded,
    BruteForce,
    MaliciousBot,
    SuspiciousHeaders,
    LargePayload,
    IpBlocked,
    CustomRule(String),
    AuthFailure,
    ThreatIntelMatch,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum EventSeverity {
    Critical,
    High,
    Medium,
    Low,
    Info,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CryptoEvent {
    pub id:         String,
    pub timestamp:  DateTime<Utc>,
    pub event_type: CryptoEventType,
    pub key_id:     Option<String>,
    pub algorithm:  String,
    pub success:    bool,
    pub error:      Option<String>,
    pub metadata:   serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CryptoEventType {
    Encrypt,
    Decrypt,
    Sign,
    Verify,
    KeyGenerated,
    KeyRotated,
    KeyDeleted,
    SecretAccessed,
    SecretRotated,
    TokenCreated,
    TokenVerified,
    TokenRevoked,
    PasswordHashed,
    PasswordVerified,
}

impl SecurityEvent {
    pub fn new(
        event_type: SecurityEventType,
        ip_address: impl Into<String>,
        method:     impl Into<String>,
        path:       impl Into<String>,
        user_agent: impl Into<String>,
        blocked:    bool,
        severity:   EventSeverity,
        details:    impl Into<String>,
    ) -> Self {
        Self {
            id:         uuid::Uuid::new_v4().to_string(),
            timestamp:  Utc::now(),
            event_type,
            ip_address: ip_address.into(),
            method:     method.into(),
            path:       path.into(),
            user_agent: user_agent.into(),
            payload:    None,
            blocked,
            severity,
            details:    details.into(),
            metadata:   serde_json::Value::Null,
        }
    }
}

impl CryptoEvent {
    pub fn new(
        event_type: CryptoEventType,
        algorithm:  impl Into<String>,
        success:    bool,
    ) -> Self {
        Self {
            id:         uuid::Uuid::new_v4().to_string(),
            timestamp:  Utc::now(),
            event_type,
            key_id:     None,
            algorithm:  algorithm.into(),
            success,
            error:      None,
            metadata:   serde_json::Value::Null,
        }
    }
}
