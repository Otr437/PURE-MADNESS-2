// crypto-service/src/rsa_impl.rs
use rsa::{
    pkcs8::{DecodePrivateKey, DecodePublicKey, EncodePrivateKey, EncodePublicKey, LineEnding},
    Oaep, RsaPrivateKey, RsaPublicKey,
};
use sha2::Sha256;

pub fn gen_rsa_keypair() -> anyhow::Result<(String, String)> {
    let mut rng = rand::thread_rng();
    let priv_key = RsaPrivateKey::new(&mut rng, 4096)?;
    let pub_key  = RsaPublicKey::from(&priv_key);
    Ok((
        priv_key.to_pkcs8_pem(LineEnding::LF)?.to_string(),
        pub_key.to_public_key_pem(LineEnding::LF)?,
    ))
}

pub fn rsa_encrypt(data: &[u8], pub_pem: &str) -> anyhow::Result<Vec<u8>> {
    let key = RsaPublicKey::from_public_key_pem(pub_pem)?;
    let mut rng = rand::thread_rng();
    Ok(key.encrypt(&mut rng, Oaep::new::<Sha256>(), data)?)
}

pub fn rsa_decrypt(ct: &[u8], priv_pem: &str) -> anyhow::Result<Vec<u8>> {
    let key = RsaPrivateKey::from_pkcs8_pem(priv_pem)?;
    Ok(key.decrypt(Oaep::new::<Sha256>(), ct)?)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn roundtrip() {
        let (priv_pem, pub_pem) = gen_rsa_keypair().unwrap();
        let data = b"rsa test";
        let ct   = rsa_encrypt(data, &pub_pem).unwrap();
        assert_eq!(rsa_decrypt(&ct, &priv_pem).unwrap(), data);
    }
}
