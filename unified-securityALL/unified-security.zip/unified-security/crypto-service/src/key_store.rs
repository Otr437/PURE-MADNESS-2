// crypto-service/src/key_store.rs
use std::{collections::HashMap, sync::Arc};
use async_trait::async_trait;
use tokio::sync::RwLock;
use uuid::Uuid;
use serde_json::{json, Value};
use shared::plugin::{KeyStoreBackend, PluginCapability, PluginMeta};
use shared::error::PluginError;

// ─── Key record stored in memory ─────────────────────────────────────────────

#[derive(Clone)]
struct KeyRecord {
    id:         String,
    kind:       String,   // "aes", "rsa", "ed25519"
    data:       Vec<u8>,  // raw key bytes (private key for asymmetric)
    pair_data:  Option<Vec<u8>>, // public key bytes when asymmetric
    created_at: String,
}

// ─── In-memory key store ──────────────────────────────────────────────────────

#[derive(Clone)]
pub struct InMemoryKeyStore {
    inner: Arc<RwLock<HashMap<String, KeyRecord>>>,
}

impl InMemoryKeyStore {
    pub fn new() -> Self {
        Self { inner: Arc::new(RwLock::new(HashMap::new())) }
    }

    /// Store a symmetric key and return its generated ID.
    pub fn store(&self, kind: &str, data: &[u8]) -> String {
        let id = Uuid::new_v4().to_string();
        let rec = KeyRecord {
            id:        id.clone(),
            kind:      kind.to_string(),
            data:      data.to_vec(),
            pair_data: None,
            created_at: chrono::Utc::now().to_rfc3339(),
        };
        // Block on write — called from sync context (handler setup)
        let store = Arc::clone(&self.inner);
        tokio::task::block_in_place(|| {
            tokio::runtime::Handle::current().block_on(async {
                store.write().await.insert(id.clone(), rec);
            })
        });
        id
    }

    /// Store an asymmetric key pair; `data` = private key bytes.
    pub fn store_pair(&self, kind: &str, private_bytes: &[u8]) -> String {
        let id = Uuid::new_v4().to_string();
        let rec = KeyRecord {
            id:        id.clone(),
            kind:      kind.to_string(),
            data:      private_bytes.to_vec(),
            pair_data: None,
            created_at: chrono::Utc::now().to_rfc3339(),
        };
        let store = Arc::clone(&self.inner);
        tokio::task::block_in_place(|| {
            tokio::runtime::Handle::current().block_on(async {
                store.write().await.insert(id.clone(), rec);
            })
        });
        id
    }

    /// Retrieve a key record as JSON.
    pub fn get(&self, id: &str) -> Option<Value> {
        let store = Arc::clone(&self.inner);
        tokio::task::block_in_place(|| {
            tokio::runtime::Handle::current().block_on(async {
                store.read().await.get(id).map(|r| json!({
                    "id":         r.id,
                    "kind":       r.kind,
                    "key":        base64::encode(&r.data),
                    "created_at": r.created_at,
                }))
            })
        })
    }

    /// List all key IDs and metadata (no key material).
    pub fn list(&self) -> Vec<Value> {
        let store = Arc::clone(&self.inner);
        tokio::task::block_in_place(|| {
            tokio::runtime::Handle::current().block_on(async {
                store.read().await.values().map(|r| json!({
                    "id":         r.id,
                    "kind":       r.kind,
                    "created_at": r.created_at,
                })).collect()
            })
        })
    }

    /// Delete a key by ID.
    pub fn delete(&self, id: &str) {
        let store = Arc::clone(&self.inner);
        tokio::task::block_in_place(|| {
            tokio::runtime::Handle::current().block_on(async {
                store.write().await.remove(id);
            })
        });
    }

    /// Return a clone that also satisfies the KeyStoreBackend trait.
    pub fn clone_as_backend(&self) -> KeyStoreBackendAdapter {
        KeyStoreBackendAdapter { inner: Arc::clone(&self.inner) }
    }
}

// ─── Trait adapter for the plugin registry ───────────────────────────────────

pub struct KeyStoreBackendAdapter {
    inner: Arc<RwLock<HashMap<String, KeyRecord>>>,
}

#[async_trait]
impl KeyStoreBackend for KeyStoreBackendAdapter {
    fn meta(&self) -> &PluginMeta {
        static META: std::sync::OnceLock<PluginMeta> = std::sync::OnceLock::new();
        META.get_or_init(|| PluginMeta {
            id:           "builtin.in_memory_key_store".into(),
            name:         "In-Memory Key Store".into(),
            version:      "2.0.0".into(),
            description:  "Thread-safe in-memory key storage".into(),
            author:       "built-in".into(),
            capabilities: vec![PluginCapability::KeyStoreBackend],
        })
    }

    async fn store_key(&self, id: &str, blob: &[u8]) -> Result<(), PluginError> {
        self.inner.write().await.insert(id.to_string(), KeyRecord {
            id:        id.to_string(),
            kind:      "raw".into(),
            data:      blob.to_vec(),
            pair_data: None,
            created_at: chrono::Utc::now().to_rfc3339(),
        });
        Ok(())
    }

    async fn load_key(&self, id: &str) -> Result<Vec<u8>, PluginError> {
        self.inner.read().await
            .get(id)
            .map(|r| r.data.clone())
            .ok_or_else(|| PluginError::NotFound(format!("key {}", id)))
    }

    async fn delete_key(&self, id: &str) -> Result<(), PluginError> {
        self.inner.write().await.remove(id);
        Ok(())
    }

    async fn list_keys(&self, prefix: &str) -> Result<Vec<String>, PluginError> {
        Ok(self.inner.read().await
            .keys()
            .filter(|k| k.starts_with(prefix))
            .cloned()
            .collect())
    }

    async fn rotate_key(&self, id: &str) -> Result<(), PluginError> {
        // For in-memory store, rotation = generate new bytes for the same ID.
        // A production HSM/Vault plugin would perform real key rotation.
        let mut store = self.inner.write().await;
        if let Some(rec) = store.get_mut(id) {
            use rand::RngCore;
            let mut new_bytes = vec![0u8; rec.data.len()];
            rand::thread_rng().fill_bytes(&mut new_bytes);
            rec.data = new_bytes;
            rec.created_at = chrono::Utc::now().to_rfc3339();
            Ok(())
        } else {
            Err(PluginError::NotFound(format!("key {}", id)))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test]
    async fn store_list_delete() {
        let ks = InMemoryKeyStore::new();
        let id = ks.store("aes", &[0u8; 32]);
        assert!(ks.get(&id).is_some());
        assert_eq!(ks.list().len(), 1);
        ks.delete(&id);
        assert!(ks.get(&id).is_none());
    }

    #[tokio::test]
    async fn backend_trait_roundtrip() {
        let ks = InMemoryKeyStore::new();
        let adapter = ks.clone_as_backend();
        adapter.store_key("test-key", &[1u8; 16]).await.unwrap();
        let loaded = adapter.load_key("test-key").await.unwrap();
        assert_eq!(loaded, vec![1u8; 16]);
        adapter.delete_key("test-key").await.unwrap();
        assert!(adapter.load_key("test-key").await.is_err());
    }
}
