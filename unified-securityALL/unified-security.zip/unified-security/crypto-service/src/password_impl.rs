// crypto-service/src/password_impl.rs
use argon2::{
    password_hash::{rand_core::OsRng, PasswordHash, PasswordHasher, PasswordVerifier, SaltString},
    Argon2,
};
use scrypt::{
    password_hash::{
        PasswordHash as ScryptHash, PasswordHasher as ScryptHasher,
        PasswordVerifier as ScryptVerifier, SaltString as ScryptSalt,
    },
    Scrypt,
};

// ── bcrypt ────────────────────────────────────────────────────────────────────

pub fn pw_bcrypt(password: &str) -> anyhow::Result<String> {
    Ok(bcrypt::hash(password, bcrypt::DEFAULT_COST)?)
}

pub fn pw_verify_bcrypt(password: &str, hash: &str) -> anyhow::Result<bool> {
    Ok(bcrypt::verify(password, hash)?)
}

// ── Argon2id ─────────────────────────────────────────────────────────────────

pub fn pw_argon2(password: &str) -> anyhow::Result<String> {
    let salt = SaltString::generate(&mut OsRng);
    Argon2::default()
        .hash_password(password.as_bytes(), &salt)
        .map(|h| h.to_string())
        .map_err(|e| anyhow::anyhow!("argon2: {}", e))
}

pub fn pw_verify_argon2(password: &str, hash: &str) -> anyhow::Result<bool> {
    let parsed = PasswordHash::new(hash)
        .map_err(|e| anyhow::anyhow!("invalid argon2 hash: {}", e))?;
    Ok(Argon2::default()
        .verify_password(password.as_bytes(), &parsed)
        .is_ok())
}

// ── scrypt ────────────────────────────────────────────────────────────────────

pub fn pw_scrypt(password: &str) -> anyhow::Result<String> {
    let salt = ScryptSalt::generate(&mut OsRng);
    Scrypt
        .hash_password(password.as_bytes(), &salt)
        .map(|h| h.to_string())
        .map_err(|e| anyhow::anyhow!("scrypt: {}", e))
}

pub fn pw_verify_scrypt(password: &str, hash: &str) -> anyhow::Result<bool> {
    let parsed = ScryptHash::new(hash)
        .map_err(|e| anyhow::anyhow!("invalid scrypt hash: {}", e))?;
    Ok(Scrypt
        .verify_password(password.as_bytes(), &parsed)
        .is_ok())
}

#[cfg(test)]
mod tests {
    use super::*;
    const PW: &str = "correct_horse_battery_staple";

    #[test]
    fn bcrypt_roundtrip() {
        let h = pw_bcrypt(PW).unwrap();
        assert!(pw_verify_bcrypt(PW, &h).unwrap());
        assert!(!pw_verify_bcrypt("wrong", &h).unwrap());
    }

    #[test]
    fn argon2_roundtrip() {
        let h = pw_argon2(PW).unwrap();
        assert!(pw_verify_argon2(PW, &h).unwrap());
        assert!(!pw_verify_argon2("wrong", &h).unwrap());
    }

    #[test]
    fn scrypt_roundtrip() {
        let h = pw_scrypt(PW).unwrap();
        assert!(pw_verify_scrypt(PW, &h).unwrap());
        assert!(!pw_verify_scrypt("wrong", &h).unwrap());
    }

    #[test]
    fn auto_detect_algorithm() {
        // bcrypt hashes start with $2
        let h = pw_bcrypt(PW).unwrap();
        assert!(h.starts_with("$2"));

        // argon2 hashes start with $argon2
        let h = pw_argon2(PW).unwrap();
        assert!(h.starts_with("$argon2"));

        // scrypt hashes start with $scrypt
        let h = pw_scrypt(PW).unwrap();
        assert!(h.starts_with("$scrypt"));
    }
}
