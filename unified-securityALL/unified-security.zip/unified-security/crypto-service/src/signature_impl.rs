// crypto-service/src/signature_impl.rs
use ed25519_dalek::{Signature, Signer, SigningKey, Verifier, VerifyingKey};
use rand::rngs::OsRng;

pub fn gen_ed25519_pair() -> (SigningKey, VerifyingKey) {
    let sk = SigningKey::generate(&mut OsRng);
    let vk = sk.verifying_key();
    (sk, vk)
}

pub fn ed25519_sign(data: &[u8], private_key: &[u8]) -> anyhow::Result<Vec<u8>> {
    anyhow::ensure!(private_key.len() == 32, "Ed25519 private key must be 32 bytes");
    let sk  = SigningKey::from_bytes(private_key.try_into()?);
    let sig = sk.sign(data);
    Ok(sig.to_bytes().to_vec())
}

pub fn ed25519_verify(data: &[u8], sig_bytes: &[u8], public_key: &[u8]) -> anyhow::Result<bool> {
    anyhow::ensure!(public_key.len() == 32, "Ed25519 public key must be 32 bytes");
    anyhow::ensure!(sig_bytes.len() == 64,  "Ed25519 signature must be 64 bytes");
    let vk  = VerifyingKey::from_bytes(public_key.try_into()?)?;
    let sig = Signature::from_bytes(sig_bytes.try_into()?);
    Ok(vk.verify(data, &sig).is_ok())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn roundtrip() {
        let (sk, vk) = gen_ed25519_pair();
        let msg = b"sign me";
        let sig = ed25519_sign(msg, &sk.to_bytes()).unwrap();
        assert!(ed25519_verify(msg, &sig, vk.as_bytes()).unwrap());
        assert!(!ed25519_verify(b"tampered", &sig, vk.as_bytes()).unwrap());
    }
}
