// crypto-service/src/config.rs
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CryptoConfig {
    pub port:         u16,
    pub log_level:    String,
    pub plugin:       shared::config::PluginConfig,
}

impl CryptoConfig {
    pub fn load() -> anyhow::Result<Self> {
        if let Ok(s) = std::fs::read_to_string("crypto-config.toml") {
            return Ok(toml::from_str(&s)?);
        }
        Ok(Self::default())
    }
}

impl Default for CryptoConfig {
    fn default() -> Self {
        Self {
            port:      8081,
            log_level: "info".into(),
            plugin:    Default::default(),
        }
    }
}
