// crypto-service/src/aes_impl.rs
use aes_gcm::{aead::{Aead, KeyInit, OsRng}, Aes256Gcm, Nonce};
use rand::RngCore;

pub fn gen_aes_key() -> Vec<u8> {
    Aes256Gcm::generate_key(&mut OsRng).to_vec()
}

pub fn aes_encrypt(data: &[u8], key: &[u8]) -> anyhow::Result<(Vec<u8>, Vec<u8>)> {
    anyhow::ensure!(key.len() == 32, "AES-256 requires 32-byte key");
    let cipher = Aes256Gcm::new(key.try_into()?);
    let mut nonce_bytes = [0u8; 12];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let nonce = Nonce::from_slice(&nonce_bytes);
    let ct = cipher.encrypt(nonce, data)
        .map_err(|e| anyhow::anyhow!("AES encrypt: {}", e))?;
    Ok((ct, nonce_bytes.to_vec()))
}

pub fn aes_decrypt(ct: &[u8], key: &[u8], nonce: &[u8]) -> anyhow::Result<Vec<u8>> {
    anyhow::ensure!(key.len() == 32,  "AES-256 requires 32-byte key");
    anyhow::ensure!(nonce.len() == 12, "AES-GCM requires 12-byte nonce");
    let cipher = Aes256Gcm::new(key.try_into()?);
    let nonce = Nonce::from_slice(nonce);
    cipher.decrypt(nonce, ct)
        .map_err(|e| anyhow::anyhow!("AES decrypt: {}", e))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn roundtrip() {
        let key  = gen_aes_key();
        let data = b"hello world";
        let (ct, nonce) = aes_encrypt(data, &key).unwrap();
        assert_eq!(aes_decrypt(&ct, &key, &nonce).unwrap(), data);
    }
}
