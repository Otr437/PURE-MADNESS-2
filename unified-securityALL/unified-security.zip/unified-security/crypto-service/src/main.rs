// crypto-service/src/main.rs
//
// Dynamic entry-point architecture (mirrors the WAF):
//   • PluginRegistry holds SecretManager, KeyStoreBackend, CryptoProvider,
//     AuthProvider, EventSink, MetricsSink.
//   • Built-in software implementations are registered at startup.
//   • External systems (Vault, AWS KMS, HSM, Redis, webhooks …) call
//     register_*() — the service core never imports them directly.

use std::{net::SocketAddr, sync::Arc, time::{SystemTime, UNIX_EPOCH}};

use axum::{
    extract::{Path, State},
    http::StatusCode,
    response::IntoResponse,
    routing::{delete, get, post},
    Json, Router,
};
use serde::{Deserialize, Serialize};
use tower_http::{cors::CorsLayer, trace::TraceLayer};
use tracing::info;

use shared::{
    event::{CryptoEvent, CryptoEventType},
    health::{ComponentHealth, HealthState, HealthStatus},
    plugin::PluginRegistry,
};

mod aes_impl;
mod chacha_impl;
mod rsa_impl;
mod hash_impl;
mod password_impl;
mod signature_impl;
mod jwt_impl;
mod key_store;
mod builtin_crypto_plugin;
mod config;

use aes_impl::*;
use chacha_impl::*;
use rsa_impl::*;
use hash_impl::*;
use password_impl::*;
use signature_impl::*;
use jwt_impl::*;
use key_store::InMemoryKeyStore;
use builtin_crypto_plugin::SoftwareCryptoProvider;
use config::CryptoConfig;

// ─── STATE ───────────────────────────────────────────────────────────────────

#[derive(Clone)]
pub struct AppState {
    pub registry:   Arc<PluginRegistry>,
    pub key_store:  Arc<InMemoryKeyStore>,
    pub config:     Arc<CryptoConfig>,
    pub start_time: u64,
}

// ─── MAIN ────────────────────────────────────────────────────────────────────

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter("crypto_service=debug")
        .json()
        .init();

    info!("Starting Crypto Service v2.0.0");

    let config   = Arc::new(CryptoConfig::load()?);
    let registry = PluginRegistry::new();
    let key_store = Arc::new(InMemoryKeyStore::new());

    // ── Register built-in software crypto provider ────────────────────────────
    registry.register_crypto_provider(
        Arc::new(SoftwareCryptoProvider::new(key_store.clone()))
    ).await;

    // ── Register built-in in-memory key store ─────────────────────────────────
    registry.register_key_store(
        Arc::new(key_store.clone_as_backend())
    ).await;

    // ── External plugins wire in here (never imported by service core) ────────
    //
    // Vault example:
    //   if let Some(url) = &config.plugin.vault_url {
    //       registry.register_secret_manager(Arc::new(VaultPlugin::new(url))).await;
    //       registry.register_key_store(Arc::new(VaultKeyStore::new(url))).await;
    //   }
    //
    // AWS KMS example:
    //   registry.register_crypto_provider(Arc::new(AwsKmsPlugin::new())).await;
    //
    // OIDC auth provider example:
    //   registry.register_auth_provider(Arc::new(OidcPlugin::new(issuer))).await;

    info!("Plugin registry ready ({} plugin(s))",
          registry.list_all_plugins().await.len());

    let state = AppState {
        registry,
        key_store,
        config: config.clone(),
        start_time: now(),
    };

    let app = Router::new()
        // Health & discovery
        .route("/health",      get(health_check))
        .route("/algorithms",  get(list_algorithms))
        .route("/plugins",     get(list_plugins))
        // Symmetric encryption
        .route("/encrypt",     post(encrypt_handler))
        .route("/decrypt",     post(decrypt_handler))
        // Hashing
        .route("/hash",        post(hash_handler))
        .route("/hmac",        post(hmac_handler))
        // Key management
        .route("/keys/generate", post(generate_key_handler))
        .route("/keys",          get(list_keys_handler))
        .route("/keys/:id",      get(get_key_handler).delete(delete_key_handler))
        // Digital signatures
        .route("/sign",   post(sign_handler))
        .route("/verify", post(verify_handler))
        // Password hashing
        .route("/password/hash",   post(password_hash_handler))
        .route("/password/verify", post(password_verify_handler))
        // JWT
        .route("/jwt/create", post(jwt_create_handler))
        .route("/jwt/verify", post(jwt_verify_handler))
        // Secret management (delegated to plugin)
        .route("/secrets/:path",      get(get_secret_handler))
        .route("/secrets/:path",      post(put_secret_handler))
        .route("/secrets/:path",      delete(delete_secret_handler))
        // Token validation (delegated to auth provider plugin)
        .route("/auth/validate", post(validate_token_handler))
        .layer(CorsLayer::permissive())
        .layer(TraceLayer::new_for_http())
        .with_state(state);

    let addr = SocketAddr::from(([0, 0, 0, 0], config.port));
    info!("Crypto service listening on {}", addr);
    let listener = tokio::net::TcpListener::bind(addr).await?;
    axum::serve(listener, app).await?;
    Ok(())
}

fn now() -> u64 { SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs() }

// ─── REQUEST / RESPONSE TYPES ────────────────────────────────────────────────

#[derive(Deserialize)] pub struct EncryptReq { pub data: String, #[serde(default)] pub algorithm: EncAlgo, pub key: Option<String> }
#[derive(Deserialize)] pub struct DecryptReq { pub encrypted: String, pub nonce: Option<String>, pub key: Option<String>, #[serde(default)] pub algorithm: EncAlgo }
#[derive(Deserialize)] pub struct HashReq    { pub data: String, #[serde(default)] pub algorithm: HashAlgo }
#[derive(Deserialize)] pub struct HmacReq    { pub data: String, pub key: String }
#[derive(Deserialize)] pub struct GenKeyReq  { #[serde(default)] pub algorithm: KeyAlgo }
#[derive(Deserialize)] pub struct SignReq     { pub data: String, pub key_id: Option<String>, pub private_key: Option<String> }
#[derive(Deserialize)] pub struct VerifyReq   { pub data: String, pub signature: String, pub key_id: Option<String>, pub public_key: Option<String> }
#[derive(Deserialize)] pub struct PwHashReq   { pub password: String, #[serde(default)] pub algorithm: PwAlgo }
#[derive(Deserialize)] pub struct PwVerifyReq { pub password: String, pub hash: String }
#[derive(Deserialize)] pub struct JwtCreateReq { pub claims: serde_json::Value, pub secret: Option<String>, pub expires_in: Option<i64> }
#[derive(Deserialize)] pub struct JwtVerifyReq { pub token: String, pub secret: Option<String> }
#[derive(Deserialize)] pub struct PutSecretReq { pub value: String }
#[derive(Deserialize)] pub struct ValidateTokenReq { pub token: String }

#[derive(Clone, Deserialize, Default)] #[serde(rename_all = "kebab-case")]
pub enum EncAlgo { #[default] #[serde(rename = "aes-256-gcm")] Aes256Gcm, #[serde(rename = "chacha20-poly1305")] ChaCha20, #[serde(rename = "rsa-4096")] Rsa4096 }

#[derive(Clone, Deserialize, Default)] #[serde(rename_all = "lowercase")]
pub enum HashAlgo { #[default] Sha256, Sha512, Sha3_256, Sha3_512, Blake3 }

#[derive(Clone, Deserialize, Default)] #[serde(rename_all = "kebab-case")]
pub enum KeyAlgo { #[default] #[serde(rename = "aes-256")] Aes256, #[serde(rename = "rsa-4096")] Rsa4096, Ed25519 }

#[derive(Clone, Deserialize, Default)] #[serde(rename_all = "lowercase")]
pub enum PwAlgo { #[default] Bcrypt, Argon2, Scrypt }

// ─── HANDLERS ────────────────────────────────────────────────────────────────

async fn health_check(State(s): State<AppState>) -> impl IntoResponse {
    Json(HealthStatus {
        status:      HealthState::Healthy,
        service:     "crypto-service".into(),
        version:     "2.0.0".into(),
        uptime_secs: now().saturating_sub(s.start_time),
        checks: vec![ComponentHealth {
            name: "crypto_provider".into(), status: HealthState::Healthy,
            latency_ms: None, message: None,
        }],
    })
}

async fn list_algorithms() -> impl IntoResponse {
    Json(serde_json::json!({
        "encryption":  ["aes-256-gcm", "chacha20-poly1305", "rsa-4096"],
        "hashing":     ["sha256", "sha512", "sha3_256", "sha3_512", "blake3"],
        "password":    ["bcrypt", "argon2", "scrypt"],
        "signing":     ["ed25519", "rsa-4096"],
        "key_types":   ["aes-256", "rsa-4096", "ed25519"],
    }))
}

async fn list_plugins(State(s): State<AppState>) -> impl IntoResponse {
    Json(s.registry.list_all_plugins().await)
}

async fn encrypt_handler(
    State(s): State<AppState>,
    Json(req): Json<EncryptReq>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let result = match req.algorithm {
        EncAlgo::Aes256Gcm => {
            let key = decode_or_gen_aes(req.key)?;
            let (enc, nonce) = aes_encrypt(req.data.as_bytes(), &key)
                .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
            serde_json::json!({
                "encrypted": base64::encode(&enc),
                "nonce":     base64::encode(&nonce),
                "key":       base64::encode(&key),
                "algorithm": "aes-256-gcm",
            })
        }
        EncAlgo::ChaCha20 => {
            let key = decode_or_gen_chacha(req.key)?;
            let (enc, nonce) = chacha_encrypt(req.data.as_bytes(), &key)
                .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
            serde_json::json!({
                "encrypted": base64::encode(&enc),
                "nonce":     base64::encode(&nonce),
                "key":       base64::encode(&key),
                "algorithm": "chacha20-poly1305",
            })
        }
        EncAlgo::Rsa4096 => {
            let pem = req.key.ok_or((StatusCode::BAD_REQUEST, "public key required".into()))?;
            let enc = rsa_encrypt(req.data.as_bytes(), &pem)
                .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
            serde_json::json!({
                "encrypted": base64::encode(&enc),
                "algorithm": "rsa-4096",
            })
        }
    };

    s.registry.emit_crypto_event(CryptoEvent::new(CryptoEventType::Encrypt, "symmetric", true)).await;
    Ok(Json(result))
}

async fn decrypt_handler(
    State(s): State<AppState>,
    Json(req): Json<DecryptReq>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let enc = b64decode(&req.encrypted)?;

    let data = match req.algorithm {
        EncAlgo::Aes256Gcm => {
            let key   = b64decode(&req.key.ok_or((StatusCode::BAD_REQUEST, "key required".into()))?)?;
            let nonce = b64decode(&req.nonce.ok_or((StatusCode::BAD_REQUEST, "nonce required".into()))?)?;
            aes_decrypt(&enc, &key, &nonce).map_err(|e| (StatusCode::UNPROCESSABLE_ENTITY, e.to_string()))?
        }
        EncAlgo::ChaCha20 => {
            let key   = b64decode(&req.key.ok_or((StatusCode::BAD_REQUEST, "key required".into()))?)?;
            let nonce = b64decode(&req.nonce.ok_or((StatusCode::BAD_REQUEST, "nonce required".into()))?)?;
            chacha_decrypt(&enc, &key, &nonce).map_err(|e| (StatusCode::UNPROCESSABLE_ENTITY, e.to_string()))?
        }
        EncAlgo::Rsa4096 => {
            let pem = req.key.ok_or((StatusCode::BAD_REQUEST, "private key required".into()))?;
            rsa_decrypt(&enc, &pem).map_err(|e| (StatusCode::UNPROCESSABLE_ENTITY, e.to_string()))?
        }
    };

    let text = String::from_utf8(data).map_err(|e| (StatusCode::UNPROCESSABLE_ENTITY, e.to_string()))?;
    s.registry.emit_crypto_event(CryptoEvent::new(CryptoEventType::Decrypt, "symmetric", true)).await;
    Ok(Json(serde_json::json!({"data": text})))
}

async fn hash_handler(Json(req): Json<HashReq>) -> impl IntoResponse {
    let bytes = req.data.as_bytes();
    let hash = match req.algorithm {
        HashAlgo::Sha256   => sha256(bytes),
        HashAlgo::Sha512   => sha512(bytes),
        HashAlgo::Sha3_256 => sha3_256(bytes),
        HashAlgo::Sha3_512 => sha3_512(bytes),
        HashAlgo::Blake3   => blake3_hash(bytes),
    };
    Json(serde_json::json!({"hash": hex::encode(hash), "algorithm": format!("{:?}", req.algorithm).to_lowercase()}))
}

async fn hmac_handler(Json(req): Json<HmacReq>) -> Result<impl IntoResponse, (StatusCode, String)> {
    let key = b64decode(&req.key)?;
    let mac = hmac_sha256(req.data.as_bytes(), &key);
    Ok(Json(serde_json::json!({"hmac": hex::encode(mac)})))
}

async fn generate_key_handler(
    State(s): State<AppState>,
    Json(req): Json<GenKeyReq>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let result = match req.algorithm {
        KeyAlgo::Aes256 => {
            let key = gen_aes_key();
            let id  = s.key_store.store("aes", &key);
            serde_json::json!({"key_id": id, "key": base64::encode(&key), "algorithm": "aes-256"})
        }
        KeyAlgo::Rsa4096 => {
            let (priv_pem, pub_pem) = gen_rsa_keypair()
                .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
            let id = s.key_store.store_pair("rsa", priv_pem.as_bytes());
            serde_json::json!({"key_id": id, "public_key": pub_pem, "private_key": priv_pem, "algorithm": "rsa-4096"})
        }
        KeyAlgo::Ed25519 => {
            let (signing, verifying) = gen_ed25519_pair();
            let id = s.key_store.store_pair("ed25519", &signing.to_bytes());
            serde_json::json!({
                "key_id":     id,
                "public_key": base64::encode(verifying.as_bytes()),
                "private_key": base64::encode(signing.to_bytes()),
                "algorithm":  "ed25519",
            })
        }
    };
    s.registry.emit_crypto_event(CryptoEvent::new(CryptoEventType::KeyGenerated, "key_gen", true)).await;
    Ok(Json(result))
}

async fn list_keys_handler(State(s): State<AppState>) -> impl IntoResponse {
    Json(s.key_store.list())
}

async fn get_key_handler(
    State(s): State<AppState>, Path(id): Path<String>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    s.key_store.get(&id)
        .map(|k| Json(k).into_response())
        .ok_or((StatusCode::NOT_FOUND, "Key not found".into()))
}

async fn delete_key_handler(
    State(s): State<AppState>, Path(id): Path<String>,
) -> impl IntoResponse {
    s.key_store.delete(&id);
    Json(serde_json::json!({"success": true}))
}

async fn sign_handler(
    State(s): State<AppState>,
    Json(req): Json<SignReq>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let priv_bytes = resolve_private_key(&s, req.key_id, req.private_key).await?;
    let sig = ed25519_sign(req.data.as_bytes(), &priv_bytes)
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    s.registry.emit_crypto_event(CryptoEvent::new(CryptoEventType::Sign, "ed25519", true)).await;
    Ok(Json(serde_json::json!({"signature": base64::encode(sig), "algorithm": "ed25519"})))
}

async fn verify_handler(
    State(s): State<AppState>,
    Json(req): Json<VerifyReq>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let sig = b64decode(&req.signature)?;
    let pub_bytes = resolve_public_key(&s, req.key_id, req.public_key).await?;
    let valid = ed25519_verify(req.data.as_bytes(), &sig, &pub_bytes)
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    s.registry.emit_crypto_event(CryptoEvent::new(CryptoEventType::Verify, "ed25519", true)).await;
    Ok(Json(serde_json::json!({"valid": valid})))
}

async fn password_hash_handler(
    State(s): State<AppState>,
    Json(req): Json<PwHashReq>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let hash = match req.algorithm {
        PwAlgo::Bcrypt => pw_bcrypt(&req.password)
            .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?,
        PwAlgo::Argon2 => pw_argon2(&req.password)
            .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?,
        PwAlgo::Scrypt => pw_scrypt(&req.password)
            .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?,
    };
    s.registry.emit_crypto_event(CryptoEvent::new(CryptoEventType::PasswordHashed, "password", true)).await;
    Ok(Json(serde_json::json!({"hash": hash, "algorithm": format!("{:?}", req.algorithm).to_lowercase()})))
}

async fn password_verify_handler(
    State(s): State<AppState>,
    Json(req): Json<PwVerifyReq>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let valid = if req.hash.starts_with("$2") {
        pw_verify_bcrypt(&req.password, &req.hash)
            .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?
    } else if req.hash.starts_with("$argon2") {
        pw_verify_argon2(&req.password, &req.hash)
            .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?
    } else if req.hash.starts_with("$scrypt") {
        pw_verify_scrypt(&req.password, &req.hash)
            .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?
    } else {
        return Err((StatusCode::BAD_REQUEST, "Unknown hash format".into()));
    };
    s.registry.emit_crypto_event(CryptoEvent::new(CryptoEventType::PasswordVerified, "password", true)).await;
    Ok(Json(serde_json::json!({"valid": valid})))
}

async fn jwt_create_handler(
    State(s): State<AppState>,
    Json(req): Json<JwtCreateReq>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    // Check plugin registry for secret first
    let secret = if let Some(sec) = req.secret {
        sec
    } else if let Some(sec) = s.registry.get_secret("jwt/default_secret").await {
        sec
    } else {
        return Err((StatusCode::BAD_REQUEST, "secret required".into()));
    };

    let token = create_jwt(req.claims, &secret, req.expires_in.unwrap_or(3600))
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    s.registry.emit_crypto_event(CryptoEvent::new(CryptoEventType::TokenCreated, "jwt", true)).await;
    Ok(Json(serde_json::json!({"token": token})))
}

async fn jwt_verify_handler(
    State(s): State<AppState>,
    Json(req): Json<JwtVerifyReq>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let secret = if let Some(sec) = req.secret {
        sec
    } else if let Some(sec) = s.registry.get_secret("jwt/default_secret").await {
        sec
    } else {
        return Err((StatusCode::BAD_REQUEST, "secret required".into()));
    };

    match verify_jwt(&req.token, &secret) {
        Ok(claims) => {
            s.registry.emit_crypto_event(CryptoEvent::new(CryptoEventType::TokenVerified, "jwt", true)).await;
            Ok(Json(serde_json::json!({"valid": true, "claims": claims})))
        }
        Err(_) => Ok(Json(serde_json::json!({"valid": false, "claims": null})))
    }
}

async fn get_secret_handler(
    State(s): State<AppState>, Path(path): Path<String>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    s.registry.get_secret(&path).await
        .map(|v| Json(serde_json::json!({"path": path, "value": v})).into_response())
        .ok_or((StatusCode::NOT_FOUND, "Secret not found".into()))
}

async fn put_secret_handler(
    State(s): State<AppState>,
    Path(path): Path<String>,
    Json(req): Json<PutSecretReq>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let managers = s.registry.secret_managers.read().await;
    if managers.is_empty() {
        return Err((StatusCode::SERVICE_UNAVAILABLE, "No secret manager plugin registered".into()));
    }
    managers[0].put_secret(&path, &req.value).await
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(serde_json::json!({"success": true})))
}

async fn delete_secret_handler(
    State(s): State<AppState>, Path(path): Path<String>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let managers = s.registry.secret_managers.read().await;
    if managers.is_empty() {
        return Err((StatusCode::SERVICE_UNAVAILABLE, "No secret manager plugin registered".into()));
    }
    managers[0].delete_secret(&path).await
        .map_err(|e| (StatusCode::INTERNAL_SERVER_ERROR, e.to_string()))?;
    Ok(Json(serde_json::json!({"success": true})))
}

async fn validate_token_handler(
    State(s): State<AppState>,
    Json(req): Json<ValidateTokenReq>,
) -> Result<impl IntoResponse, (StatusCode, String)> {
    let providers = s.registry.auth_providers.read().await;
    if providers.is_empty() {
        return Err((StatusCode::SERVICE_UNAVAILABLE, "No auth provider plugin registered".into()));
    }
    match providers[0].validate_token(&req.token).await {
        Ok(claims) => Ok(Json(serde_json::json!({
            "valid":       true,
            "subject":     claims.subject,
            "roles":       claims.roles,
            "permissions": claims.permissions,
            "expires_at":  claims.expires_at,
        })).into_response()),
        Err(e) => Ok(Json(serde_json::json!({"valid": false, "error": e.to_string()})).into_response()),
    }
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────

fn b64decode(s: &str) -> Result<Vec<u8>, (StatusCode, String)> {
    base64::decode(s).map_err(|e| (StatusCode::BAD_REQUEST, format!("base64: {}", e)))
}

fn decode_or_gen_aes(k: Option<String>) -> Result<Vec<u8>, (StatusCode, String)> {
    match k {
        Some(s) => b64decode(&s),
        None    => Ok(gen_aes_key()),
    }
}

fn decode_or_gen_chacha(k: Option<String>) -> Result<Vec<u8>, (StatusCode, String)> {
    match k {
        Some(s) => b64decode(&s),
        None    => Ok(gen_chacha_key()),
    }
}

async fn resolve_private_key(
    s: &AppState, key_id: Option<String>, raw: Option<String>,
) -> Result<Vec<u8>, (StatusCode, String)> {
    if let Some(b64) = raw {
        return b64decode(&b64);
    }
    if let Some(id) = key_id {
        return s.registry.load_key(&id).await
            .ok_or((StatusCode::NOT_FOUND, "Key not found".into()));
    }
    Err((StatusCode::BAD_REQUEST, "key_id or private_key required".into()))
}

async fn resolve_public_key(
    s: &AppState, key_id: Option<String>, raw: Option<String>,
) -> Result<Vec<u8>, (StatusCode, String)> {
    if let Some(b64) = raw {
        return b64decode(&b64);
    }
    if let Some(id) = key_id {
        return s.registry.load_key(&id).await
            .ok_or((StatusCode::NOT_FOUND, "Key not found".into()));
    }
    Err((StatusCode::BAD_REQUEST, "key_id or public_key required".into()))
}
