// crypto-service/src/hash_impl.rs
use sha2::{Digest, Sha256, Sha512};
use sha3::{Sha3_256, Sha3_512};
use hmac::{Hmac, Mac};

type HmacSha256 = Hmac<Sha256>;

pub fn sha256(data: &[u8]) -> Vec<u8> {
    let mut h = Sha256::new(); h.update(data); h.finalize().to_vec()
}

pub fn sha512(data: &[u8]) -> Vec<u8> {
    let mut h = Sha512::new(); h.update(data); h.finalize().to_vec()
}

pub fn sha3_256(data: &[u8]) -> Vec<u8> {
    let mut h = Sha3_256::new(); h.update(data); h.finalize().to_vec()
}

pub fn sha3_512(data: &[u8]) -> Vec<u8> {
    let mut h = Sha3_512::new(); h.update(data); h.finalize().to_vec()
}

pub fn blake3_hash(data: &[u8]) -> Vec<u8> {
    let mut h = blake3::Hasher::new(); h.update(data);
    h.finalize().as_bytes().to_vec()
}

pub fn hmac_sha256(data: &[u8], key: &[u8]) -> Vec<u8> {
    let mut mac = HmacSha256::new_from_slice(key)
        .expect("HMAC accepts any key length");
    mac.update(data);
    mac.finalize().into_bytes().to_vec()
}

pub fn hmac_sha256_verify(data: &[u8], key: &[u8], expected: &[u8]) -> bool {
    let computed = hmac_sha256(data, key);
    // constant-time comparison
    use subtle::ConstantTimeEq;
    computed.ct_eq(expected).into()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn sha256_known() {
        // SHA-256("abc")
        let h = sha256(b"abc");
        assert_eq!(
            hex::encode(h),
            "ba7816bf8f01cfea414140de5dae2ec73b00361bbef0469f490e91b0a1fc4bf5"
                .replace("ba7816bf8f01cfea414140de5dae2ec73b00361bbef0469f490e91b0a1fc4bf5",
                         "ba7816bf8f01cfea414140de5dae2ec73b00361bbef0469f490e91b0a1fc4bf5")
        );
    }
    #[test]
    fn hmac_roundtrip() {
        let key  = b"secret";
        let data = b"message";
        let mac  = hmac_sha256(data, key);
        assert!(hmac_sha256_verify(data, key, &mac));
        assert!(!hmac_sha256_verify(b"wrong", key, &mac));
    }
    #[test]
    fn all_algos_produce_output() {
        let d = b"test";
        assert!(!sha256(d).is_empty());
        assert!(!sha512(d).is_empty());
        assert!(!sha3_256(d).is_empty());
        assert!(!sha3_512(d).is_empty());
        assert!(!blake3_hash(d).is_empty());
    }
}
