// crypto-service/src/chacha_impl.rs
use chacha20poly1305::{aead::{Aead, KeyInit, OsRng}, ChaCha20Poly1305, Key, Nonce};
use rand::RngCore;

pub fn gen_chacha_key() -> Vec<u8> {
    ChaCha20Poly1305::generate_key(&mut OsRng).to_vec()
}

pub fn chacha_encrypt(data: &[u8], key: &[u8]) -> anyhow::Result<(Vec<u8>, Vec<u8>)> {
    anyhow::ensure!(key.len() == 32, "ChaCha20 requires 32-byte key");
    let cipher = ChaCha20Poly1305::new(Key::from_slice(key));
    let mut nonce_bytes = [0u8; 12];
    rand::thread_rng().fill_bytes(&mut nonce_bytes);
    let nonce = Nonce::from_slice(&nonce_bytes);
    let ct = cipher.encrypt(nonce, data)
        .map_err(|e| anyhow::anyhow!("ChaCha encrypt: {}", e))?;
    Ok((ct, nonce_bytes.to_vec()))
}

pub fn chacha_decrypt(ct: &[u8], key: &[u8], nonce: &[u8]) -> anyhow::Result<Vec<u8>> {
    anyhow::ensure!(key.len() == 32,   "ChaCha20 requires 32-byte key");
    anyhow::ensure!(nonce.len() == 12, "ChaCha20 requires 12-byte nonce");
    let cipher = ChaCha20Poly1305::new(Key::from_slice(key));
    let nonce  = Nonce::from_slice(nonce);
    cipher.decrypt(nonce, ct)
        .map_err(|e| anyhow::anyhow!("ChaCha decrypt: {}", e))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn roundtrip() {
        let key  = gen_chacha_key();
        let data = b"chacha test";
        let (ct, nonce) = chacha_encrypt(data, &key).unwrap();
        assert_eq!(chacha_decrypt(&ct, &key, &nonce).unwrap(), data);
    }
}
