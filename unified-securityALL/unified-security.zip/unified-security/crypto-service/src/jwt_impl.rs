// crypto-service/src/jwt_impl.rs
use jsonwebtoken::{decode, encode, Algorithm, DecodingKey, EncodingKey, Header, Validation};
use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Debug, Serialize, Deserialize)]
struct Claims {
    #[serde(flatten)]
    custom: Value,
    exp: i64,
    iat: i64,
}

pub fn create_jwt(claims: Value, secret: &str, expires_in: i64) -> anyhow::Result<String> {
    let now = chrono::Utc::now().timestamp();
    let full = Claims { custom: claims, exp: now + expires_in, iat: now };
    Ok(encode(
        &Header::default(),
        &full,
        &EncodingKey::from_secret(secret.as_bytes()),
    )?)
}

pub fn verify_jwt(token: &str, secret: &str) -> anyhow::Result<Value> {
    let mut v = Validation::new(Algorithm::HS256);
    v.validate_exp = true;
    let data = decode::<Claims>(
        token,
        &DecodingKey::from_secret(secret.as_bytes()),
        &v,
    )?;
    Ok(data.claims.custom)
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn roundtrip() {
        let secret = "super_secret_key_32_chars_long!!";
        let claims = json!({"user_id": 42, "role": "admin"});
        let token  = create_jwt(claims.clone(), secret, 3600).unwrap();
        let decoded = verify_jwt(&token, secret).unwrap();
        assert_eq!(decoded["user_id"], 42);
        assert_eq!(decoded["role"], "admin");
    }

    #[test]
    fn wrong_secret_fails() {
        let token = create_jwt(json!({"x": 1}), "good_secret_32_chars_padding!!!", 3600).unwrap();
        assert!(verify_jwt(&token, "wrong_secret_32_chars_padding!!").is_err());
    }
}
